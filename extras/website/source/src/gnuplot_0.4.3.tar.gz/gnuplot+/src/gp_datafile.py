# GP_DATAFILE.PY
# Dominic Ford
# 18/05/2006

import gp_eval
import gp_settings

import os
import re
import gzip

# GP_DATAREAD(): Read a data file, selecting only every nth item from index m, using ....

def gp_dataread(datafile, index, using, every, vars, funcs):
  rows       = 0
  using_list = gp_eval.gp_split(using, ":")
  columns    = len(using_list)
  columns_using = columns
  if (columns == 1): columns=2
  data_used  = {}
  datagrid   =  []
  totalgrid  = [[]] # List of [rows, columns, datagrid]s
  allgrid    =  []

  # Parse using list
  for i in range(len(using_list)):
    test = re.match(r"""^[0-9]*$""",using_list[i])
    if (test != None):
      data_used[int(test.group(0))]='used'
      using_list[i] = "_gp_param"+using_list[i]
    else:
      while 1:
        test = re.search(r"\$([0-9]*)",using_list[i])
        if (test != None):
          using_list[i] = using_list[i][:test.start()] + "_gp_param" + test.group(1) + using_list[i][test.end():]
          data_used[int(test.group(1))]='used'
        else:
          break

  # Open input datafile
  if (re.search(r"\.gz$",datafile) != None): # If filename ends in .gz, open it with gunzip
   f         = gzip.open(os.path.join(gp_settings.cwd, os.path.expanduser(datafile)),"r")
  else:
   f         = open(os.path.join(gp_settings.cwd, os.path.expanduser(datafile)),"r")
  index_no   = 0
  index_datacount = 0
  every_count= 0
  prev_blank = 10 # Skip opening blank lines
  vars_local = vars.copy()

  for line in f.readlines():
    line_clean = line.strip()
    if (len(line_clean) == 0): # Ignore blank lines
      prev_blank = prev_blank + 1
      if (rows > 0):           # Make a new discontinuous line
       totalgrid.append([rows,columns,datagrid])
       rows = 0
       datagrid = []
      if (prev_blank == 2): # Two blank lines means a new index
       index_no = index_no + 1
       index_datacount = 0
       if ((index >= 0) and (index_no > index)): break # No more data
      continue
    if (line_clean[0] == '#'): continue # Ignore comment lines, too
    prev_blank = 0 # Reset blank lines counter

    if ((index >= 0) and (index_no != index)): continue # Still waiting for our index

    if (every_count < 1): # Use only every nth datapoint
      data_item = []
      data_list = line_clean.split()
      if ((columns_using != 1) and (len(data_list) == 1)): # This deals with "using 1:2" when we have a one-column datafile
       for varnum,dummy in data_used.iteritems():
        if   (varnum == 1): vars_local['_gp_param'+str(varnum)] = index_datacount
        elif (varnum == 2): vars_local['_gp_param'+str(varnum)] = float(data_list[0])
        else              : vars_local['_gp_param'+str(varnum)] = 0.0
      else:
       for varnum,dummy in data_used.iteritems(): # This deals with all other datafiles
         if (varnum <= len(data_list)):
           vars_local['_gp_param'+str(varnum)] = float(data_list[varnum-1])
         else:
           vars_local['_gp_param'+str(varnum)] = 0.0

      if (columns_using == 1): data_item.append(index_datacount) # If only one column set in 'using', add x-coordinates from datapoint number within file index
      for i in range(len(using_list)):
        value = gp_eval.gp_eval(using_list[i], vars_local, funcs)
        if ((i > 1) and (value < 0.0)): # Check for negative error bars
          value = 0.0
          print "Warning: Negative Errorbar detected!"
        data_item.append(value)
      datagrid.append(data_item)
      allgrid.append(data_item)
      rows = rows + 1
      every_count = every - 1
    else:
      every_count = every_count - 1 # Count down counter until we take next point
    index_datacount = index_datacount + 1

  f.close()
  if (rows > 0): totalgrid.append([rows,columns,datagrid])
  totalgrid[0] = [rows, columns, allgrid]
  return totalgrid
