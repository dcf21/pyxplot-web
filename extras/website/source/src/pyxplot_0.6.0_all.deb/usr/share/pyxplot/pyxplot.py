# PYXPLOT.PY
# Dominic Ford
# 12/11/2006

exitting = 0

import gp_children
import gp_settings
import gp_eval
import gp_fit
import gp_plot
import gp_postscript
import gp_text
import gp_help
import gp_version
import gp_spline
from gp_autocomplete import *
import gp_parser
import gp_error
from gp_error import *

import os
import sys
import glob
import signal
from math import *
import re

try: import readline
except: READLINE_ABSENT= True
else: READLINE_ABSENT = False

try: import scipy
except: SCIPY_ABSENT = True
else: SCIPY_ABSENT = False

# FLOATPRINT(): Prints a float in floating point or exponential format, as appropriate

def floatprint(x):
  if ((fabs(x) < 1e10) and (fabs(x) > 1e-6)): return "%f"%x
  else:                                       return "%e"%x

# READ_COORD_SYST(): Read screen, graph, first or second modifiers
# Returns modifier and string of unprocessed text

def read_coord_syst(string):
  if  ((string == None) or (len(string) == 0) or
       autocomplete(string, "first", 1)          ): return ['first','']
  elif autocomplete(string, "second", 1)          : return ['second','']
  elif autocomplete(string, "graph", 1)           : return ['graph','']
  elif autocomplete(string, "screen", 1)          : return ['screen','']
  else:
   test = re.match(r"axis(\d\d*)$",string)
   if (test != None): return [string,'']
   return ['first',string]

# ACCESS_AXIS(): Returns axis settings for an axis. If axis doesn't exist, then
# create it.

def access_axis(axisname):
 axis_dir = axisname[0]
 if (len(axisname) == 1): axis_n = 1 # "x" means axis "x1"
 else                   : axis_n = int(axisname[1:])

 if axis_n not in gp_settings.axes[axis_dir]: # Create axis if it doesn't already exist
  gp_settings.axes[axis_dir][axis_n] = gp_settings.default_axis.copy()

 return [ axis_dir, axis_n, gp_settings.axes[axis_dir][axis_n] ]

# COPY_AXIS_INFO_TO_GPPLOT(): This is called at the end of commands such as
# "set xtics". Having set axis settings in gp_settings, we also make any
# necessary changes in gp_plot.axes_this to ensure that the replot command does
# the right thing. This is necessary because the user may have set ranges on
# axes in the plot command, which gp_plot needs to remember.

def copy_axis_info_to_gpplot(axisname, attributes):
 [direction, number, axis_in] = access_axis(axisname)

 if (not number in gp_plot.axes_this[direction]):
  gp_plot.axes_this[direction][number] = {'SETTINGS':axis_in.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None} # Create axis if doesn't exist
 else:
  for attribute in attributes:
   gp_plot.axes_this[direction][number]['SETTINGS'][attribute] = axis_in[attribute]

# Directive Show

def directive_show(dictlist):
  if (len(dictlist) == 0):
    gp_error(gp_text.show)
  else:
    for dict in dictlist:
      word = dict['setting']
      if autocomplete(word, "all",1):
        directive_show([{'setting':"settings"},
                        {'setting':"axes_"},
                        {'setting':"linestyles"},
                        {'setting':"variables"},
                        {'setting':"functions"}])
        continue
      outstring = ""
      if autocomplete(word, "settings", 1) or autocomplete(word, "origin", 1):    outstring += "Plot Offset:  (%f,%f)\n"%(gp_settings.settings['ORIGINX'],gp_settings.settings['ORIGINY'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "multiplot", 1): outstring += "Multiplot:     %s\n"%gp_settings.settings['MULTIPLOT']
      if autocomplete(word, "settings", 1) or autocomplete(word, "display", 1)  : outstring += "Display:       %s\n"%gp_settings.settings['DISPLAY']
      if autocomplete(word, "settings", 1) or autocomplete(word, "title", 1):     outstring += "Plot Title:   '%s' at offset (%f,%f)\n"%(gp_settings.settings['TITLE'],gp_settings.settings['TIT_XOFF'],gp_settings.settings['TIT_YOFF'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "terminal", 1):  outstring += "Terminal type: %s\n"%gp_settings.settings['TERMTYPE']
      if autocomplete(word, "settings", 1) or autocomplete(word, "output", 1):    outstring += "Output fname:  %s\n"%gp_settings.settings['OUTPUT']
      if autocomplete(word, "settings", 1) or autocomplete(word, "backup", 1):    outstring += "File backups:  %s\n"%gp_settings.settings['BACKUP']
      if autocomplete(word, "settings", 1) or autocomplete(word, "terminal", 1):  outstring += "Enhanced eps:  %s\n"%gp_settings.settings['ENHANCED']
      if autocomplete(word, "settings", 1) or autocomplete(word, "terminal", 1):  outstring += "Landscape mode:%s\n"%gp_settings.settings['LANDSCAPE']
      if autocomplete(word, "settings", 1) or autocomplete(word, "terminal", 1):  outstring += "Invert colours:%s (only relevant when output is sent to a bitmap terminal -- gif, jpg or png)\n"%gp_settings.settings['TERMINVERT']
      if autocomplete(word, "settings", 1) or autocomplete(word, "terminal", 1):  outstring += "Transparency:  %s (only relevant when output is sent to gif or png terminals, which support transparency)\n"%gp_settings.settings['TERMTRANSPARENT']
      if autocomplete(word, "settings", 1) or autocomplete(word, "dpi", 1):       outstring += "Output DPI:    %f (only relevant when output is sent to a bitmap terminal -- gif, jpg or png)\n"%gp_settings.settings['DPI']
      if(autocomplete(word, "settings", 1) or autocomplete(word, "width", 1) or
                                               autocomplete(word, "size", 1)):    outstring += "Output width:  %s\n"%floatprint(gp_settings.settings['WIDTH'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "size", 1):
       if (gp_settings.settings['AUTOASPECT'] == "ON"): outstring += "Output aspect: <auto>\n"
       else                                           : outstring += "Output aspect: %f\n"%gp_settings.settings['ASPECT']
      if autocomplete(word, "settings", 1) or autocomplete(word, "papersize", 1): outstring += "Papersize:     %s (%s by %s mm)\n"%(gp_settings.settings['PAPER_NAME'],gp_settings.settings['PAPER_HEIGHT'],gp_settings.settings['PAPER_WIDTH'])
      if(autocomplete(word, "settings", 1) or autocomplete(word, "pointsize", 1) or
                                              autocomplete(word, "ps",2)       ): outstring += "Pointsize:     %f\n"%gp_settings.settings['POINTSIZE']
      if (autocomplete(word, "settings", 1) or
          autocomplete(word, "pointlinewidth",1) or autocomplete(word, "plw",3)): outstring += "Pointlinewidth:%f\n"%gp_settings.settings['POINTLINEWIDTH']
      if autocomplete(word, "settings", 1) or autocomplete(word, "bar",1):        outstring += "Bar width:     %f (the size of the strokes at the end of errorbars, set with 'set bar')\n"%gp_settings.settings['BAR']
      if autocomplete(word, "settings", 1) or autocomplete(word, "fontsize",1):   outstring += "Fontsize:      %d (-4 is smallest, 5 largest)\n"%gp_settings.settings['FONTSIZE']
      if autocomplete(word, "settings", 1) or autocomplete(word, "textcolour",1): outstring += "Text colour:   %s\n"%gp_settings.settings['TEXTCOLOUR']
      if autocomplete(word, "settings", 1) or autocomplete(word, "texthalign",1): outstring += "Text halign:   %s\n"%gp_settings.settings['TEXTHALIGN']
      if autocomplete(word, "settings", 1) or autocomplete(word, "textvalign",1): outstring += "Text valign:   %s\n"%gp_settings.settings['TEXTVALIGN']
      if autocomplete(word, "settings", 1) or autocomplete(word, "axescolour",1): outstring += "Axes colour:   %s\n"%gp_settings.settings['AXESCOLOUR']
      if autocomplete(word, "settings", 1) or autocomplete(word, "gridmajcolour",1): outstring += "Grid major col:%s\n"%gp_settings.settings['GRIDMAJCOLOUR']
      if autocomplete(word, "settings", 1) or autocomplete(word, "gridmincolour",1): outstring += "Grid minor col:%s\n"%gp_settings.settings['GRIDMINCOLOUR']
      if(autocomplete(word, "settings", 1) or autocomplete(word, "linewidth", 1) or
                                              autocomplete(word, "lw",2)       ): outstring += "Linewidth:     %f\n"%gp_settings.settings['LINEWIDTH']
      if(autocomplete(word, "settings", 1) or autocomplete(word, "data", 1) or
                                               autocomplete(word, "style",1)):    outstring += "Data style:    %s (the default plotting style for datafiles, if none is specified)\n"%gp_settings.settings['DATASTYLE']
      if(autocomplete(word, "settings", 1) or autocomplete(word, "function", 1) or
                                               autocomplete(word, "style",1)):    outstring += "Function style:%s (the default plotting style for functions, if none is specified)\n"%gp_settings.settings['FUNCSTYLE']
      if autocomplete(word, "settings", 1) or autocomplete(word, "samples",1):    outstring += "Samples        %d (no of samples used when plotting functions)\n"%gp_settings.settings['SAMPLES']
      if autocomplete(word, "settings", 1) or autocomplete(word, "colour",1):     outstring += "Colour:        %s (when off, all plots will be monochrome)\n"%gp_settings.settings['COLOUR']
      if autocomplete(word, "settings", 1) or autocomplete(word, "key",1):        outstring += "Key:           %s (selects whether a legend appears on plots)\n"%gp_settings.settings['KEY']
      if autocomplete(word, "settings", 1) or autocomplete(word, "keycolumns",1): outstring += "Key columns:   %s\n"%gp_settings.settings['KEYCOLUMNS']
      if autocomplete(word, "settings", 1) or autocomplete(word, "key",1):        outstring += "Key position:  %s, with offset (%f,%f)\n"%(gp_settings.settings['KEYPOS'],gp_settings.settings['KEY_XOFF'],gp_settings.settings['KEY_YOFF'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "grid",1):
        outstring += "Grid:          %s\n"%gp_settings.settings['GRID']
        if (gp_settings.settings['GRID'] == 'ON'):
          outstring += "Grid Axes:     "
          for axis_n in gp_settings.settings['GRIDAXISX']: outstring += "x%d "%axis_n
          for axis_n in gp_settings.settings['GRIDAXISY']: outstring += "y%d "%axis_n
          outstring += "\n"
      if autocomplete(word, "settings", 1) or autocomplete(word, "boxwidth",1):   outstring += "Boxwidth:      %s (the default width of bars on barcharts and histograms; a negative value means automatic widths)\n"%floatprint(gp_settings.settings['BOXWIDTH'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "boxfrom",1):    outstring += "BoxFrom:       %s (the vertical point from which the bars of barcharts and histograms emanate)\n"%floatprint(gp_settings.settings['BOXFROM'])
      if autocomplete(word, "settings", 1) or autocomplete(word, "palette",1):    outstring += "Palette:       %s\n"%gp_settings.colour_list

      if autocomplete(word, "linestyles", 1) or (word=="ls"):
       outstring += "\nLinestyles:\n"
       for i,definition in gp_settings.linestyles.iteritems():
         outstring += "  linestyle %d: %s\n"%(i,definition)

      if autocomplete(word, "arrows",1):
        outstring += "\nArrows:\n"
        for i,definition in gp_settings.arrows.iteritems():
          outstring += "  arrow %d: (%s %s,%s %s) to (%s %s,%s %s) %s\n"%(i, definition[0], floatprint(definition[1]), definition[2], floatprint(definition[3]), definition[4], floatprint(definition[5]), definition[6], floatprint(definition[7]), definition[8])

      if autocomplete(word, "labels",1):
        outstring += "\nText labels:\n"
        for i,definition in gp_settings.labels.iteritems():
          outstring += "  label %d: %s at (%s %s,%s %s)\n"%(i, definition[0], definition[1], floatprint(definition[2]), definition[3], floatprint(definition[4]))

      for [direction , direction_axes] in gp_settings.axes.iteritems():
       for [axis_number, axis] in direction_axes.iteritems():
        axisoutstring = ""
        if autocomplete(word, "axes_",1) or autocomplete(word, "%s%dlabel"%(direction,axis_number),1) or ((axis_number==1)and(autocomplete(word, "%slabel"%direction,1))):
          axisoutstring += "  Label:     %s\n"%axis['LABEL']
        if autocomplete(word, "axes_",1) or autocomplete(word, "%s%drange"%(direction,axis_number),1) or ((axis_number==1)and(autocomplete(word, "%srange"%direction,1))) or autocomplete(word, "autoscale",1):
          if (axis['MIN'] == None): mintxt = "<auto>"
          else                    : mintxt = floatprint(axis['MIN'])
          if (axis['MAX'] == None): maxtxt = "<auto>"
          else                    : maxtxt = floatprint(axis['MAX'])
          axisoutstring += "  Range:    (%s --> %s)\n"%(mintxt,maxtxt)
        if autocomplete(word, "axes_",1) or autocomplete(word, "logscale",1):
          axisoutstring += "  Log:       %s"%axis['LOG']
          if (axis['LOG'] == "ON"): axisoutstring += " (base %d)\n"%axis['LOGBASE']
          else                    : axisoutstring += " (display scientific exponentials to base %d)\n"%axis['LOGBASE']
        if autocomplete(word, "axes_",1) or autocomplete(word, "%s%dtics"%(direction,axis_number),1) or ((axis_number==1)and(autocomplete(word, "%stics"%direction,1))):
          axisoutstring += "  Ticks:     "
          if   (axis['TICKLIST'] != None):
           axisoutstring += "\n"
           for tick in axis['TICKLIST']:
            axisoutstring += "    %16s %s\n"%(tick[0],tick[1])
          elif (axis['TICKSTEP'] != None):
           if   (axis['TICKMIN'] == None): axisoutstring += "from axis minimum, with separation %s.\n"%axis['TICKSTEP']
           elif (axis['TICKMAX']   == None): axisoutstring += "from %s, with separation %s.\n"%(axis['TICKMIN'],axis['TICKSTEP'])
           else                            : axisoutstring += "from %s, with separation %s, to %s.\n"%(axis['TICKMIN'],axis['TICKSTEP'],axis['TICKMAX'])
          else:
           axisoutstring += "automatic\n"
        if autocomplete(word, "axes_",1) or autocomplete(word, "m%s%dtics"%(direction,axis_number),1) or ((axis_number==1)and(autocomplete(word, "m%stics"%direction,1))):
          axisoutstring += "  Minor Tics:"
          if   (axis['MTICKLIST'] != None):
           axisoutstring += "\n"
           for tick in axis['MTICKLIST']:
            axisoutstring += "    %16s %s\n"%(tick[0],tick[1])
          elif (axis['MTICKSTEP'] != None):
           if   (axis['MTICKMIN'] == None): axisoutstring += "from axis minimum, with separation %s.\n"%axis['MTICKSTEP']
           elif (axis['MTICKMAX']   == None): axisoutstring += "from %s, with separation %s.\n"%(axis['MTICKMIN'],axis['MTICKSTEP'])
           else                            : axisoutstring += "from %s, with separation %s, to %s.\n"%(axis['MTICKMIN'],axis['MTICKSTEP'],axis['MTICKMAX'])
          else:
           axisoutstring += "automatic\n"
        if autocomplete(word, "axes_",1) or autocomplete(word, "%s%dticdir"%(direction,axis_number),1) or ((axis_number==1)and(autocomplete(word, "%sticdir"%direction,1))):
          axisoutstring += "  Tick Direction: %s\n"%axis['TICDIR']
        if (len(axisoutstring) > 0): outstring += "\nSettings for %s%s axis:\n"%(direction,axis_number)+axisoutstring

      if autocomplete(word, "variables",1) or (word=="vars"):
        outstring += "\nVariables:\n"
        for x,y in gp_settings.variables.iteritems():
          outstring += "%s = %s\n"%(x,floatprint(y))
        outstring += "\n"

      if autocomplete(word, "functions",1) or (word=="funcs"):
        outstring += "\nUser-Defined Functions:\n"
        for x,y in gp_settings.functions.iteritems():
         for definition in y[1]:
          string = x+"("
          if (y[0] < 0):   # This is a spline
            outstring += string + "x) = spline fit to file %s.\n"%definition[0]
          else:              # This is a regular function
            ranges = " for "
            for i in range(y[0]):
             if (i != 0): string += ","
             string += definition[0][i]
             if   (i != 0) and (i != y[0]-1): ranges += ", "
             elif (i != 0) and (i == y[0]-1): ranges += " and "
             if (definition[1][i] == [None,None]): ranges += "all "+definition[0][i]
             else:
              ranges += "("
              if (definition[1][i][0] == None): ranges += "-inf"
              else                            : ranges += definition[1][i][0]
              ranges += " < "+definition[0][i]+" < "
              if (definition[1][i][1] == None): ranges += "inf"
              else                            : ranges += definition[1][i][1]
              ranges += ")"
            outstring += string+") = "+definition[2]+"\n"
            outstring += ranges+"\n"

      if (len(outstring) == 0):
        if   re.match(r"(x|y|z|X|Y|Z)\d\d*(L|l)((A|a)((B|b)((E|e)((L|l)?)?)?)?)?$",word) != None: gp_error("Error: show command requested to show label on non-existent axis '%s'."%word)
        elif re.match(r"(x|y|z|X|Y|Z)\d\d*(R|r)((A|a)((N|n)((G|g)((E|e)?)?)?)?)?$",word) != None: gp_error("Error: show command requested to show range of non-existent axis '%s'."%word)
        elif re.match(r"(x|y|z|X|Y|Z)\d\d*(T|t)((I|i)((C|c)((D|d)((I|i)((R|r)?)?)?)?)?)?$",word) != None: gp_error("Error: show command requested to show ticdir of non-existent axis '%s'."%word)
        else:
          gp_error("Error: show command passed unrecognised word '%s'."%word)
          gp_error(gp_text.show)
      else:
        gp_report(outstring)
  return

# Directive Set / Unset

def directive_set_unset(userinput,command,line,linelist):

    if   (userinput['set_option'] == 'autoscale'): # set autoscale
     for axis_dict in userinput['axes']:
      axisname = axis_dict['axis']
      [direction,number,axis] = access_axis(axisname)
      axis["AUTOSCALE"] = "ON"
      copy_axis_info_to_gpplot(axisname, ["AUTOSCALE"])

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "bar"): # set bar
     gp_settings.settings['BAR'] = float(userinput['bar_size'])

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "bar"): # unset bar
     gp_settings.settings['BAR'] = gp_settings.settings_default['BAR']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "boxfrom"): # set boxfrom
     gp_settings.settings['BOXFROM'] = userinput['box_from']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "boxfrom"): # unset boxfrom
     gp_settings.settings['BOXFROM'] = gp_settings.settings_default['BOXFROM']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "boxwidth"): # set boxwidth
     gp_settings.settings['BOXWIDTH'] = userinput['box_width']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "boxwidth"): # unset boxwidth
     gp_settings.settings['BOXWIDTH'] = gp_settings.settings_default['BOXWIDTH']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "display"): # set display
     gp_settings.settings['DISPLAY'] = 'ON'

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "display"): # unset display
     gp_settings.settings['DISPLAY'] = gp_settings.settings_default['DISPLAY']
     
    elif (userinput['directive'] == "set") and (userinput['set_option'] == "dpi"): # set dpi
     if (userinput['dpi'] < 1.0):
      gp_error("Error: the set dpi command should be followed by a positive value > 1.")
     else:
      gp_settings.settings['DPI'] = userinput['dpi']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "dpi"): # unset dpi
     gp_settings.settings['DPI'] = gp_settings.settings_default['DPI']
     
    elif (userinput['directive'] == "set") and (userinput['set_option'] == "fontsize"): # set fontsize
     if (userinput['fontsize'] < -4): userinput['fontsize'] = -4
     if (userinput['fontsize'] >  5): userinput['fontsize'] =  5
     gp_settings.settings['FONTSIZE'] = userinput['fontsize']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "fontsize"): # unset fontsize
     gp_settings.settings['FONTSIZE'] = gp_settings.settings_default['FONTSIZE']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "linewidth"): # set linewidth
     gp_settings.settings['LINEWIDTH'] = userinput['linewidth']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "linewidth"): # unset linewidth
     gp_settings.settings['LINEWIDTH'] = gp_settings.settings_default['LINEWIDTH']

    elif (userinput['set_option'] == 'logscale'):         # set logscale
     if 'base' not in userinput: userinput['base'] = 10 # default use base 10
     if (userinput['base'] < 2) or (userinput['base'] > 1024):
      gp_warning("Warning: Attempt to use log axis with base %d. PyXPlot only supports bases in the range 2 - 1024. Defaulting to base 10."%userinput['base'])
      userinput['base'] = 10
     for axis_dict in userinput['axes']:
      axisname = axis_dict['axis']
      [direction,number,axis] = access_axis(axisname)
      axis["LOG"]     = "ON"
      axis["LOGBASE"] = userinput['base']
      copy_axis_info_to_gpplot(axisname, ["LOG","LOGBASE"])

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "multiplot"): # set multiplot
     if (gp_settings.settings['MULTIPLOT'] != "ON"):
      gp_settings.settings['MULTIPLOT'] = 'ON'
      gp_plot.multiplot_plotdesc  = [] # Wipe the plotting canvas
      gp_plot.multiplot_plotorder = []
      gp_plot.multiplot_text      = []
      gp_plot.multiplot_axes      = []

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "multiplot"): # unset multiplot
     if (gp_settings.settings_default['MULTIPLOT'] == "ON"):
      if (gp_settings.settings['MULTIPLOT'] != "ON"):
       gp_settings.settings['MULTIPLOT'] = 'ON'
       gp_plot.multiplot_plotdesc  = [] # Wipe the plotting canvas
       gp_plot.multiplot_plotorder = []
       gp_plot.multiplot_text      = []
       gp_plot.multiplot_axes      = []
     else:
      gp_settings.settings['MULTIPLOT'] = 'OFF'

    elif (userinput['set_option'] == 'nodisplay'): # set nodisplay
     gp_settings.settings['DISPLAY'] = 'OFF'

    elif (userinput['set_option'] == 'nologscale'): # set nologscale
     if 'base' not in userinput: userinput['base'] = 10 # default use base 10
     if (userinput['base'] < 2) or (userinput['base'] > 1024):
      gp_warning("Warning: Attempt to use log axis with base %d. PyXPlot only supports bases in the range 2 - 1024. Defaulting to base 10."%userinput['base'])
      userinput['base'] = 10
     for axis_dict in userinput['axes']:
      axisname = axis_dict['axis']
      [direction,number,axis] = access_axis(axisname)
      axis["LOG"] = "OFF"
      axis["LOGBASE"] = userinput['base']
      copy_axis_info_to_gpplot(axisname, ["LOG","LOGBASE"])

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "nomultiplot"): # set nomultiplot
     gp_settings.settings['MULTIPLOT'] = 'OFF'

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "notics"): # set notics
     [direction,number,axis] = access_axis(userinput['axis'])

     if 'minor' in userinput:
       axis['MTICKLIST'] = None
       axis['MTICKSTEP'] = 0.0
     else:
       axis['TICKLIST'] = None
       axis['TICKSTEP'] = 0.0

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "origin"): # set origin
     gp_settings.settings['ORIGINX'] = userinput['x_origin']
     gp_settings.settings['ORIGINY'] = userinput['y_origin']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "origin"): # unset origin
     gp_settings.settings['ORIGINX'] = gp_settings.settings_default['ORIGINX']
     gp_settings.settings['ORIGINY'] = gp_settings.settings_default['ORIGINY']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "pointlinewidth"): # set pointlinewidth
     gp_settings.settings['POINTLINEWIDTH'] = userinput['pointlinewidth']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "pointlinewidth"): # unset pointlinewidth
     gp_settings.settings['POINTLINEWIDTH'] = gp_settings.settings_default['POINTLINEWIDTH']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "pointsize"): # set pointsize
     gp_settings.settings['POINTSIZE'] = userinput['pointsize']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "pointsize"): # unset pointsize
     gp_settings.settings['POINTSIZE'] = gp_settings.settings_default['POINTSIZE']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "samples"): # set samples
     gp_settings.settings['SAMPLES'] = userinput['samples']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "samples"): # unset samples
     gp_settings.settings['SAMPLES'] = gp_settings.settings_default['SAMPLES']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "size"): # set size | set width
     if 'width'   in userinput: gp_settings.settings['WIDTH']  = userinput['width']
     if 'ratio'   in userinput: gp_settings.settings['AUTOASPECT'] = 'OFF' ; gp_settings.settings['ASPECT'] = userinput['ratio']
     if 'square'  in userinput: gp_settings.settings['AUTOASPECT'] = 'OFF' ; gp_settings.settings['ASPECT'] = 1.0
     if 'noratio' in userinput: gp_settings.settings['AUTOASPECT'] = 'ON'

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "size"): # unset size
     gp_settings.settings['WIDTH']      = gp_settings.settings_default['WIDTH']
     gp_settings.settings['ASPECT']     = gp_settings.settings_default['ASPECT']
     gp_settings.settings['AUTOASPECT'] = gp_settings.settings_default['AUTOASPECT']

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "tics"): # set tics
     [direction,number,axis] = access_axis(userinput['axis'])

     if 'minor' in userinput:
       TICKLIST = 'MTICKLIST' ; TICKMIN ='MTICKMIN' ; TICKSTEP ='MTICKSTEP' ; TICKMAX = 'MTICKMAX'
     else:
       TICKLIST =  'TICKLIST' ; TICKMIN = 'TICKMIN' ; TICKSTEP = 'TICKSTEP' ; TICKMAX =  'TICKMAX'

     if (axis[TICKSTEP] == 0): axis[TICKSTEP] = None # Turn off set noxtics, if this has been done.

     if 'dir' in userinput:
      if (userinput['dir'] == "inward"):  axis['TICDIR'] = "INWARD"
      if (userinput['dir'] == "outward"): axis['TICDIR'] = "OUTWARD"
      if (userinput['dir'] == "both"):    axis['TICDIR'] = "BOTH"

     if 'autofreq' in userinput: # "autofreq" means that we turn off any manually set ticks
      axis[TICKLIST] = None
      axis[TICKMIN]  = None
      axis[TICKSTEP] = None
      axis[TICKMAX]  = None

     if 'tick_list' in userinput: # User has supplied a list of tick points
      ticklist = []
      axis[TICKLIST] = ticklist
      axis[TICKSTEP] = None
      for tick in userinput['tick_list']:
       if 'label' not in tick: tick['label'] = None # User hasn't supplied a label; we make one automatically later
       ticklist.append([tick['x'],tick['label']])

     if 'start' in userinput: # User has supplied a start,step,end series for ticks to follow
      axis[TICKLIST] = None
      if not 'increment' in userinput:
       axis[TICKMIN]  = None
       axis[TICKSTEP] = userinput['start']
       axis[TICKMAX]  = None
      else:
       axis[TICKMIN]  = userinput['start']
       axis[TICKSTEP] = userinput['increment']
       if 'end' in userinput:
        axis[TICKMAX] = max(userinput['end'],userinput['start']) # Don't worry if user gives start and end wrong way around
        axis[TICKMIN] = min(userinput['end'],userinput['start'])
       else:
        axis[TICKMAX] = None

     copy_axis_info_to_gpplot(userinput['axis'], [TICKLIST, TICKMIN, TICKSTEP, TICKMAX, 'TICDIR'] )

    elif (userinput['directive'] == "set") and (userinput['set_option'] == "title"): # set title

     gp_settings.settings['TITLE'] = userinput['title']

     if ('x_offset' in userinput): gp_settings.settings['TIT_XOFF'] = userinput['x_offset']
     else                        : gp_settings.settings['TIT_XOFF'] = 0.0

     if ('y_offset' in userinput): gp_settings.settings['TIT_YOFF'] = userinput['y_offset']
     else                        : gp_settings.settings['TIT_YOFF'] = 0.0

    elif ((userinput['directive'] == "set")   and (userinput['set_option'] == "notitle") or
          (userinput['directive'] == "unset") and (userinput['set_option'] == "title"  ) ):

     gp_settings.settings['TITLE']    = gp_settings.settings_default['TITLE']
     gp_settings.settings['TIT_XOFF'] = gp_settings.settings_default['TIT_XOFF']
     gp_settings.settings['TIT_YOFF'] = gp_settings.settings_default['TIT_YOFF']

    elif (userinput['directive'] == "unset") and (userinput['set_option'] == "width"): # unset width
     gp_settings.settings['WIDTH'] = gp_settings.settings_default['WIDTH']

# -------------------------------------------------------------------------------------------------------

    if ((command == "set") and autocomplete(linelist[1],"papersize",3)): # set papersize
     test = re.match(r"""^\S*\s*\S*\s*([^\s,]*)\s*,\s*([^\s,]*)$""",line)
     if (test != None):
       try:
         h = gp_eval.gp_eval(test.group(1),gp_settings.variables,gp_settings.functions)
         w = gp_eval.gp_eval(test.group(2),gp_settings.variables,gp_settings.functions)
         gp_settings.settings['PAPER_HEIGHT'] = h
         gp_settings.settings['PAPER_WIDTH']  = w
         gp_settings.settings['PAPER_NAME']   = gp_postscript.get_papername(h,w)
       except KeyboardInterrupt: raise
       except:
         gp_error("Error evaluating papersize expressions.")
         gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
     else:
       if (len(linelist) != 3):
         gp_error('set papersize command should be followed by either the name of a recognised papersize, or a height,width pair, both measured in millimetres.')
       else:
         requested = linelist[2].lower()
         if not requested in gp_postscript.papersizes:
           gp_error("Unrecognised papersize name '%s'"%requested)
         else:
           [gp_settings.settings['PAPER_HEIGHT'], gp_settings.settings['PAPER_WIDTH']] = gp_postscript.papersizes[requested]
           gp_settings.settings['PAPER_NAME'] = requested
     return

    if ((command == "unset") and autocomplete(linelist[1],"papersize",3)): # unset papersize
     if (len(linelist) > 2):
      gp_error('Trailing word after "papersize" not expected.')
     gp_settings.settings['PAPER_HEIGHT'] = gp_settings.settings_default['PAPER_HEIGHT']
     gp_settings.settings['PAPER_WIDTH']  = gp_settings.settings_default['PAPER_WIDTH']
     gp_settings.settings['PAPER_NAME']   = gp_settings.settings_default['PAPER_NAME']
     return

    if ((command == "set") and autocomplete(linelist[1],"palette",1)):  # set palette
     error_string = "'set palette' statement should be followed by a comma-separated list of colours to put in new palette."
     test = re.match(r"""^\S*\s*\S*\s*(.*)""",line)
     if (test == None):
      gp_error("Error reading palette.\n%s"%error_string)
     else:
      colours_new = []
      try:
       colours_new = []
       colours_in  = test.group(1).split(',')
       for colour in colours_in:
        if (colour.strip().capitalize() in gp_settings.colours): colours_new.append(colour.strip().capitalize())
        else                                                   : gp_error("Unrecognised colour '%s' in palette; skipping."%colour.strip())
       if (len(colours_new) == 0):
        gp_error(error_string)
       else:
        gp_settings.colour_list = colours_new
      except KeyboardInterrupt: raise
      except:
       gp_error("Internal error whilst reading set palette statment.\n%s"%error_string)
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
     return

    if ((command == "unset") and autocomplete(linelist[1],"palette",1)): # unset palette
     if (len(linelist) > 2):
      gp_error('Trailing word after "palette" not expected.')
     gp_settings.colour_list = gp_settings.colour_list_default
     return

    if ((command == "set") and autocomplete(linelist[1],"textcolour",5)): # set textcolour
      test = re.match(r"""^\S*\s*\S*\s*(.*)""",line)
      if (test == None):
        gp_error("Error reading colour.")
      else:
        test2 = re.match(r"""^\d\d*$""", test.group(1))
        if (test2 != None):
         gp_settings.settings['TEXTCOLOUR'] = gp_settings.colour_list[(int(test.group(1))-1)%len(gp_settings.colour_list)]
        else:
         if (test.group(1).capitalize() in gp_settings.colours): gp_settings.settings['TEXTCOLOUR'] = test.group(1).capitalize()
         else                                                  : gp_error("Unrecognised colour '%s'."%test.group(1))
      return

    if ((command == "unset") and autocomplete(linelist[1],"textcolour",5)):  # unset textcolour
     if (len(linelist) > 2):
      gp_error('Trailing word after "textcolour" not expected.')
     gp_settings.settings['TEXTCOLOUR'] = gp_settings.settings_default['TEXTCOLOUR']
     return

    if ((command == "set") and autocomplete(linelist[1],"texthalign",5)): # set texthalign
      test = re.match(r"""^\S*\s*\S*\s*(.*)""",line)
      if (test == None):
        gp_error("Error reading text horizontal alignment.")
      else:
        errorstr = "Unrecognised horizontal alignment '%s'\nOptions are: 'left', 'centre' or 'right'.\n"%test.group(1)
        if (len(test.group(1).split()) > 1): gp_error(errorstr)
        else:
          if   autocomplete(test.group(1),"left"  ,1): gp_settings.settings['TEXTHALIGN'] = "Left"
          elif autocomplete(test.group(1),"centre",1): gp_settings.settings['TEXTHALIGN'] = "Centre"
          elif autocomplete(test.group(1),"center",1): gp_settings.settings['TEXTHALIGN'] = "Centre"
          elif autocomplete(test.group(1),"right" ,1): gp_settings.settings['TEXTHALIGN'] = "Right"
          else                                       : gp_error(errorstr)
      return

    if ((command == "unset") and autocomplete(linelist[1],"texthalign",5)):  # unset texthalign
     if (len(linelist) > 2):
      gp_error('Trailing word after "texthalign" not expected.')
     gp_settings.settings['TEXTHALIGN'] = gp_settings.settings_default['TEXTHALIGN']
     return

    if ((command == "set") and autocomplete(linelist[1],"textvalign",5)): # set textvalign
      test = re.match(r"""^\S*\s*\S*\s*(.*)""",line)
      if (test == None):
        gp_error("Error reading text vertical alignment.")
      else:
        errorstr = "Unrecognised vrtical alignment '%s'\nOptions are: 'top', 'centre' or 'bottom'.\n"%test.group(1)
        if (len(test.group(1).split()) > 1): gp_error(errorstr)
        else:
          if   autocomplete(test.group(1),"top"   ,1): gp_settings.settings['TEXTVALIGN'] = "Top"
          elif autocomplete(test.group(1),"centre",1): gp_settings.settings['TEXTVALIGN'] = "Centre"
          elif autocomplete(test.group(1),"center",1): gp_settings.settings['TEXTVALIGN'] = "Centre"
          elif autocomplete(test.group(1),"bottom",1): gp_settings.settings['TEXTVALIGN'] = "Bottom"
          else                                       : gp_error(errorstr)
      return

    if ((command == "unset") and autocomplete(linelist[1],"texthalign",5)):  # unset textvalign
     if (len(linelist) > 2):
      gp_error('Trailing word after "textvalign" not expected.')
     gp_settings.settings['TEXTVALIGN'] = gp_settings.settings_default['TEXTVALIGN']
     return

    if ((command == "set") and autocomplete(linelist[1],"axescolour",5)): # set axescolour
      test = re.match(r"""^\S*\s*\S*\s*(\S*)""",line)
      if (test == None):
        gp_error("Error reading colour.")
      else:
        test2 = re.match(r"""^\d\d*$""", test.group(1))
        if (test2 != None):
         gp_settings.settings['AXESCOLOUR'] = gp_settings.colour_list[(int(test.group(1))-1)%len(gp_settings.colour_list)]
        else:
         if (test.group(1).capitalize() in gp_settings.colours): gp_settings.settings['AXESCOLOUR'] = test.group(1).capitalize()
         else                                                  : gp_error("Unrecognised colour '%s'."%test.group(1))
      return

    if ((command == "unset") and autocomplete(linelist[1],"axescolour",5)):  # unset axescolour
     if (len(linelist) > 2):
      gp_error('Trailing word after "axescolour" not expected.')
     gp_settings.settings['AXESCOLOUR'] = gp_settings.settings_default['AXESCOLOUR']
     return

    if ((command == "set") and autocomplete(linelist[1],"gridmajcolour",8)): # set gridmajcolour
      test = re.match(r"""^\S*\s*\S*\s*(\S*)""",line)
      if (test == None):
        gp_error("Error reading colour.")
      else:
        test2 = re.match(r"""^\d\d*$""", test.group(1))
        if (test2 != None):
         gp_settings.settings['GRIDMAJCOLOUR'] = gp_settings.colour_list[(int(test.group(1))-1)%len(gp_settings.colour_list)]
        else:
         if (test.group(1).capitalize() in gp_settings.colours): gp_settings.settings['GRIDMAJCOLOUR'] = test.group(1).capitalize()
         else                                                  : gp_error("Unrecognised colour '%s'."%test.group(1))
      return

    if ((command == "unset") and autocomplete(linelist[1],"gridmajcolour",8)):  # unset gridmajcolour
     if (len(linelist) > 2):
      gp_error('Trailing word after "gridmajcolour" not expected.')
     gp_settings.settings['GRIDMAJCOLOUR'] = gp_settings.settings_default['GRIDMAJCOLOUR']
     return

    if ((command == "set") and autocomplete(linelist[1],"gridmincolour",8)): # set gridmincolour
      test = re.match(r"""^\S*\s*\S*\s*(\S*)""",line)
      if (test == None):
        gp_error("Error reading colour.")
      else:
        test2 = re.match(r"""^\d\d*$""", test.group(1))
        if (test2 != None):
         gp_settings.settings['GRIDMINCOLOUR'] = gp_settings.colour_list[(int(test.group(1))-1)%len(gp_settings.colour_list)]
        else:
         if (test.group(1).capitalize() in gp_settings.colours): gp_settings.settings['GRIDMINCOLOUR'] = test.group(1).capitalize()
         else                                                  : gp_error("Unrecognised colour '%s'."%test.group(1))
      return 

    if ((command == "unset") and autocomplete(linelist[1],"gridmincolour",8)):  # unset gridmincolour
     if (len(linelist) > 2):
      gp_error('Trailing word after "gridmincolour" not expected.')
     gp_settings.settings['GRIDMAJCOLOUR'] = gp_settings.settings_default['GRIDMINCOLOUR']
     return

    if ((command == "set") and autocomplete(linelist[1],"linestyle",1)): # set linestyle
      test = re.match(r"""^\S*\s*\S*\s*([0-9][0-9]*)\s*(.*)""",line)
      if (test == None):
        gp_error("Error reading linestyle. Use format: set linestyle <tag> <linestyle>")
      else:
        try:
          ls_number = int(test.group(1))
        except KeyboardInterrupt: raise
        except:
          gp_error("linestyle number must be specified as an integer")
          return
        try:
          gp_settings.linestyles[ls_number] = test.group(2)
        except KeyboardInterrupt: raise
        except:
          gp_error("Unexpected error whilst writing linestyle %d"%ls_number)
      return

    if (((command == "set") and autocomplete(linelist[1],"nolinestyle",3)) or # set nolinestyle
        ((command == "unset") and autocomplete(linelist[1],"linestyle",1))  ): # unset linestyle
      test = re.match(r"""^\S*\s*\S*\s*([0-9][0-9]*)""",line)
      if (test == None):
        gp_error("Error reading nolinestyle. Use format: 'set nolinestyle <tag>' or 'unset linestyle <tag>'.")
      else:
        try:
          ls_number = int(test.group(1))
        except KeyboardInterrupt: raise
        except:
          gp_error("linestyle number must be specified as an integer.")
          return
        try:
          del gp_settings.linestyles[ls_number] # Delete key from linestyle dictionary
        except KeyboardInterrupt: raise
        except:
          gp_error("Error removing linestyle %d -- no such linestyle."%ls_number)
      return

    if ((command == "set") and autocomplete(linelist[1],"arrow",1)): # set arrow
      errorstring = "Error reading arrow. Use format: set arrow <tag> from (first|second|screen|graph) x, (first|second|screen|graph) y to (first|second|screen|graph) x, (first|second|screen|graph) y (with linestyle.... head|nohead|twoway)"
      try:
        test = re.match(r"^\S*\s\s*\S*\s\s*([0-9][0-9]*)\s\s*f(r(om?)?)?\s\s*(.*)""",line)
        if (test == None): raise SyntaxError
        arrow_number = int(test.group(1))
        restofline   = test.group(4).split(",")
        if (len(restofline) != 3): raise SyntaxError
        test = re.match(r"(.*) to? (.*)", restofline[1])
        test2= re.match(r"(.*) w(i(th?)?)? (.*)", restofline[2])
        if (test == None): raise SyntaxError
        restofline = [ restofline[0], test.group(1), test.group(2), restofline[2] ]
        if (test2 != None):
          restofline[3] = test2.group(1)
          withclause = test2.group(4).strip()
        else:
          withclause = ""
        coordsys = [None, None, None, None]
        x        = [None, None, None, None]
        for i in range(4):
         split       = restofline[i].strip().split(" ",1)
         coord       = read_coord_syst(split[0])
         coordsys[i] = coord[0]
         if (len(split) == 2):
          ordinate = coord[1] + " " + split[1]
         else:
          ordinate = coord[1]
         x[i]     = gp_eval.gp_eval(ordinate, gp_settings.variables, gp_settings.functions, verbose=False)
        if (len(withclause) != 0): arrow_style = withclause.split()
        else                     : arrow_style = []
        gp_settings.arrows[arrow_number] = (coordsys[0], x[0], coordsys[1], x[1], coordsys[2], x[2], coordsys[3], x[3], arrow_style)
      except KeyboardInterrupt: raise
      except:
       gp_error(errorstring)
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      return

    if (((command == "set") and autocomplete(linelist[1],"noarrow",2)) or # set noarrow
        ((command == "unset") and autocomplete(linelist[1],"arrow",1))  ): # unset arrow
      test = re.match(r"""^\S*\s*\S*\s*([0-9]*)""",line)
      if (test == None):
        gp_error("Error reading noarrow. Use format: 'set noarrow <tag>' or 'unset arrow <tag>'.")
      else:
        if (len(test.group(1)) == 0):
          gp_settings.arrows = {}
        else:
          try:
            arrow_number = int(test.group(1))
          except KeyboardInterrupt: raise
          except:
            gp_error("arrow number must be specified as an integer.")
            return
          try:
            del gp_settings.arrows[arrow_number] # Delete key from linestyle dictionary
          except KeyboardInterrupt: raise
          except:
            gp_error("Error removing arrow %d -- no such arrow."%arrow_number)
      return

    if (((command == "set"  ) and autocomplete(linelist[1],"grid",1  )) or # set grid
        ((command == "unset") and autocomplete(linelist[1],"nogrid",3)) ): # unset nogrid
      if (gp_settings.settings['GRID'] != 'ON'):
       gp_settings.settings['GRID']='ON'
       if (len(linelist) == 2):
        gp_settings.settings['GRIDAXISX']=gp_settings.settings_default['GRIDAXISX'][:] # set grid alone puts grid onto default axes
        gp_settings.settings['GRIDAXISY']=gp_settings.settings_default['GRIDAXISY'][:]
       else:
        gp_settings.settings['GRIDAXISX']=[] # set grid <axis> puts a grid only onto specified axis
        gp_settings.settings['GRIDAXISY']=[]
      try:
       test = re.match(r"""\s*\S*\s*\S*\s*(.*)""", line)
       lineleft = test.group(1)
       while ((test != None) and (len(lineleft.strip()) > 0)):
        test = re.match(r"""\s*(x|y)(\d*)(.*)""", lineleft)
        if (test != None):
         if (len(test.group(2)) == 0): axis_n = 1
         else                        : axis_n = int(test.group(2))
         if (axis_n < 1):
          gp_warning("Warning: attempt in set grid command to put a grid on axis number < 1.")
         else:
          if (test.group(1) == 'x'): # Put a grid on an x-axis
           if (axis_n not in gp_settings.settings['GRIDAXISX']):
            gp_settings.settings['GRIDAXISX'].append(axis_n)
           else:
            gp_warning("Warning: attempt to set grid on axis x%d; grid is already set."%axis_n)
          else: # Put a grid on a y-axis
           if (axis_n not in gp_settings.settings['GRIDAXISY']):
            gp_settings.settings['GRIDAXISY'].append(axis_n)
           else:
            gp_warning("Warning: attempt to set grid on axis y%d; grid is already set."%axis_n)
         lineleft = test.group(3)
       if (len(lineleft.strip()) > 0):
        gp_error("Error: grid axes declaration must take the form x<n>y<m> where {n,m}>0.")
        gp_error("       left over string '%s' could not be parsed."%lineleft)
      except KeyboardInterrupt: raise
      except:
       gp_error("Error: internal error in set grid statement.")

      return

    if (((command == "set") and autocomplete(linelist[1],"nogrid",3)) or # set nogrid
        ((command == "unset") and autocomplete(linelist[1],"grid",1)) ): # unset grid
      if (len(linelist) == 2):
       gp_settings.settings['GRID']='OFF'
      else:
       try:
        test = re.match(r"""\s*\S*\s*\S*\s*(.*)""", line)
        lineleft = test.group(1)
        while ((test != None) and (len(lineleft.strip()) > 0)):
         test = re.match(r"""\s*(x|y)(\d*)(.*)""", lineleft)
         if (test != None):
          if (len(test.group(2)) == 0): axis_n = 1
          else                        : axis_n = int(test.group(2))
          if (axis_n < 1):
           gp_warning("Warning: attempt in set nogrid command to put a grid on axis number < 1.")
          else:
           if (test.group(1) == 'x'): # Remove a grid from an x-axis
            if (axis_n in gp_settings.settings['GRIDAXISX']):
             gp_settings.settings['GRIDAXISX'].remove(axis_n)
            else:
             gp_warning("Warning: attempt to set nogrid on axis x%d; no grid on that axis."%axis_n)
           else: # Remove a grid from a y-axis
            if (axis_n in gp_settings.settings['GRIDAXISY']):
             gp_settings.settings['GRIDAXISY'].remove(axis_n)
            else:
             gp_warning("Warning: attempt to set nogrid on axis y%d; no grid on that axis."%axis_n)
          lineleft = test.group(3)
        if (len(lineleft.strip()) > 0):
         gp_error("Error: nogrid axes declaration must take the form x<n>y<m> where {n,m}>0.")
         gp_error("       left over string '%s' could not be parsed."%lineleft)
       except KeyboardInterrupt: raise
       except:
        gp_error("Error: internal error in set nogrid statement.")
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      return

    if autocomplete(linelist[1],"axis",2): # set axis | unset axis
      if (len(linelist) == 2):
       gp_settings.axes = {'x':{1:gp_settings.default_axis.copy()},
                           'y':{1:gp_settings.default_axis.copy()},
                           'z':{1:gp_settings.default_axis.copy()} }
      else:
       try:
        test = re.match(r"""\s*\S*\s*\S*\s*(.*)""", line)
        lineleft = test.group(1)
        while ((test != None) and (len(lineleft.strip()) > 0)):
         test = re.match(r"""\s*(x|y)(\d*)(.*)""", lineleft)
         if (test != None):
          if (len(test.group(2)) == 0): axis_n = 1
          else                        : axis_n = int(test.group(2))
          if (axis_n < 1):
           if (command == "unset"): gp_warning("Warning: attempt in unset axis command to configure axis number < 1.")
           else:                    gp_error  ("Error: attempt to set axis with number < 1.")
          else:
           direction = test.group(1)
           if (command == "unset"):
            if (axis_n in gp_settings.axes[direction]):
             del gp_settings.axes[direction][axis_n]
             if (axis_n in gp_plot.axes_this[direction]): del gp_plot.axes_this[direction][axis_n]
             if (axis_n == 1):
              gp_settings.axes[direction][1]  = gp_settings.default_axis.copy()
              gp_plot.axes_this[direction][1] = gp_settings.default_axis.copy()
            else:
             gp_warning("Warning: attempt to unset axis %s%d; no such axis."%(direction,axis_n))
           else:
            if (not axis_n in gp_settings.axes[direction]):
             gp_settings.axes[direction][axis_n] = gp_settings.default_axis.copy()
             gp_plot.axes_this[direction][axis_n] = {'SETTINGS':gp_settings.axes[direction][axis_n].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
          lineleft = test.group(3)
        if (len(lineleft.strip()) > 0):
         gp_error("Error: unset axis declaration must take the form x<n>y<m> where {n,m}>0.")
         gp_error("       left over string '%s' could not be parsed."%lineleft)
       except KeyboardInterrupt: raise
       except:
        gp_error("Error: internal error in unset axis statement.")
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      return

    if ((command == "set") and autocomplete(linelist[1],"label",2)):  # set label
      errorstring = "Error reading label. Use format: set label <tag> 'text' at (first|second|screen|graph) x, (first|second|screen|graph) y"
      try:
        test = re.match(r"""\S*\s\s*\S*\s\s*([0-9][0-9]*)\s*(('|").*)""",line)
        if (test == None):
          gp_error(errorstring) ; return
        label_number = int(test.group(1))
        [text, aftertext] = gp_eval.gp_getquotedstring(test.group(2))
        test = re.match(r"""\s\s*a?t?\s*(.*)""",aftertext)
        restofline   = test.group(1).split(",")
        coordsys = [None, None]
        x        = [None, None]
        if (len(restofline) != 2):
         gp_error(errorstring)
        else:
         for i in range(2):
          split       = restofline[i].strip().split(" ",1)
          coord       = read_coord_syst(split[0])
          coordsys[i] = coord[0]
          if (len(split) == 2):
           ordinate = coord[1] + " " + split[1]
          else:
           ordinate = coord[1]
          x[i]     = gp_eval.gp_eval(ordinate, gp_settings.variables, gp_settings.functions, verbose=False)
         gp_settings.labels[label_number] = (text, coordsys[0],x[0],coordsys[1],x[1])
      except KeyboardInterrupt: raise
      except:
        gp_error("Error reading label position:")
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      return

    if (((command == "set") and autocomplete(linelist[1],"nolabel",4)) or # set nolabel
        ((command == "unset") and autocomplete(linelist[1],"label",2))   ): # unset label
      test = re.match(r"""^\S*\s*\S*\s*([0-9]*)""",line)
      if (test == None):
        gp_error("Error reading nolabel. Use format: 'set nolabel <tag>' or 'unset label <tag>'.")
      else:
        if (len(test.group(1)) == 0):
          gp_settings.labels = {}
        else: 
          try:
            label_number = int(test.group(1))
          except KeyboardInterrupt: raise
          except:
            gp_error("label number must be specified as an integer.")
            return
          try:
            del gp_settings.labels[label_number] # Delete key from label dictionary
          except KeyboardInterrupt: raise
          except:
            gp_error("Error removing label %d -- no such label."%label_number)
      return

    if ((command == "set") and (len(linelist) > 2) and autocomplete(linelist[2],"style",1)):
      key=""
      if autocomplete(linelist[1],"data",1):
        key = "DATASTYLE" ; name = "data"
      if autocomplete(linelist[1],"function",1):
        key = "FUNCSTYLE" ; name = "function"
      if (len(key) > 0):
        test = re.match(r"""^\S*\s*\S*\s*\S*\s*(.*)""",line)
        if ((test == None) or (len(test.group(1)) == 0)):
          gp_error("Error reading %s style"%name)
          return
        else:
          if autocomplete(test.group(1),"lines",1)       : gp_settings.settings[key] = 'lines'       ; return
          if autocomplete(test.group(1),"points",1)      : gp_settings.settings[key] = 'points'      ; return
          if autocomplete(test.group(1),"lp",2)          : gp_settings.settings[key] = 'linespoints' ; return
          if autocomplete(test.group(1),"linespoints",5) : gp_settings.settings[key] = 'linespoints' ; return
          if autocomplete(test.group(1),"pl",2)          : gp_settings.settings[key] = 'linespoints' ; return
          if autocomplete(test.group(1),"pointslines",5) : gp_settings.settings[key] = 'linespoints' ; return
          if autocomplete(test.group(1),"dots",1)        : gp_settings.settings[key] = 'dots'        ; return
          if autocomplete(test.group(1),"boxes",1)       : gp_settings.settings[key] = 'boxes'       ; return
          if autocomplete(test.group(1),"wboxes",1)      : gp_settings.settings[key] = 'wboxes'      ; return
          if autocomplete(test.group(1),"impulses",1)    : gp_settings.settings[key] = 'impulses'    ; return
          if autocomplete(test.group(1),"steps",1)       : gp_settings.settings[key] = 'steps'       ; return
          if autocomplete(test.group(1),"fsteps",1)      : gp_settings.settings[key] = 'fsteps'      ; return
          if autocomplete(test.group(1),"histeps",1)     : gp_settings.settings[key] = 'histeps'     ; return
          if autocomplete(test.group(1),"errorbars",1)   : gp_settings.settings[key] = 'yerrorbars'  ; return
          if autocomplete(test.group(1),"xerrorbars",2)  : gp_settings.settings[key] = 'xerrorbars'  ; return
          if autocomplete(test.group(1),"yerrorbars",2)  : gp_settings.settings[key] = 'yerrorbars'  ; return
          if autocomplete(test.group(1),"xyerrorbars",2) : gp_settings.settings[key] = 'xyerrorbars' ; return
          if autocomplete(test.group(1),"errorrange",6)  : gp_settings.settings[key] = 'yerrorrange' ; return
          if autocomplete(test.group(1),"xerrorrange",7) : gp_settings.settings[key] = 'xerrorrange' ; return
          if autocomplete(test.group(1),"yerrorrange",7) : gp_settings.settings[key] = 'yerrorrange' ; return
          if autocomplete(test.group(1),"xyerrorrange",8): gp_settings.settings[key] = 'xyerrorrange'; return
          if autocomplete(test.group(1),"arrows_head",3)    : gp_settings.settings[key] = 'arrows_head'   ; return
          if autocomplete(test.group(1),"arrows_nohead",3)  : gp_settings.settings[key] = 'arrows_nohead' ; return
          if autocomplete(test.group(1),"arrows_twoway",3)  : gp_settings.settings[key] = 'arrows_twohead'; return
          if autocomplete(test.group(1),"arrows_twohead",3) : gp_settings.settings[key] = 'arrows_twohead'; return
          if autocomplete(test.group(1),"csplines",3)    : gp_settings.settings[key] = 'csplines'    ; return
          if autocomplete(test.group(1),"acsplines",3)   : gp_settings.settings[key] = 'acsplines'   ; return
          gp_error("Unknown %s style: '%s'"%(name,test.group(1)))
          return

    if ((command == "set") and autocomplete(linelist[1],"output",1)): # set output
      test = re.match(r"""^\S*\s*\S*\s*('|")(.*)('|")""",line)
      if (test == None):
        gp_error("Output filename should be placed in quotes.")
      else:
        gp_settings.settings['OUTPUT']=test.group(2)
      return

    if ((command == "unset") and autocomplete(linelist[1],"output",1)): # unset output
     if (len(linelist) > 2):
      gp_error('Trailing word after "output" not expected.')
     gp_settings.settings['OUTPUT'] = gp_settings.settings_default['OUTPUT']
     return

    if ((command == "set") and autocomplete(linelist[1],"backup",2)): # set backup
     if (len(linelist) > 2):
      gp_error('Trailing word after "set backup" not expected.')
     gp_settings.settings['BACKUP'] = "ON"
     return

    if ((command == "unset") and autocomplete(linelist[1],"backup",2) or # unset backup
       ((command == "set") and autocomplete(linelist[1],"nobackup",4))  ):
     if (len(linelist) > 2):
      gp_error('Trailing word after "backup" not expected.')
     gp_settings.settings['BACKUP'] = "OFF"
     return

    if ((command == "set") and autocomplete(linelist[1],"key",1)): # set key
      gp_settings.settings['KEY']='ON'
      if (len(linelist) > 2):
       gp_settings.settings['KEY_XOFF'] = gp_settings.settings['KEY_YOFF'] = 0.0 # Reset offset if position is specified
      keymode = 0 # First offset is x offset
      for i in range(2,len(linelist),1):
       if (autocomplete(linelist[i],"top"    ,1) or autocomplete(linelist[i],"bottom" ,1) or autocomplete(linelist[i],"ycentre",1) or autocomplete(linelist[i],"left"   ,1) or autocomplete(linelist[i],"right"  ,1) or autocomplete(linelist[i],"xcentre",1)):
        if (len(gp_settings.settings['KEYPOS'].split()) != 2): gp_settings.settings['KEYPOS'] = "TOP RIGHT" # Deal with if previously "below"
        if   autocomplete(linelist[i],"top"    ,1): gp_settings.settings['KEYPOS'] = 'TOP '    + gp_settings.settings['KEYPOS'].split()[1] ; continue
        elif autocomplete(linelist[i],"bottom" ,1): gp_settings.settings['KEYPOS'] = 'BOTTOM ' + gp_settings.settings['KEYPOS'].split()[1] ; continue
        elif autocomplete(linelist[i],"ycentre",1): gp_settings.settings['KEYPOS'] = 'MIDDLE ' + gp_settings.settings['KEYPOS'].split()[1] ; continue
        elif autocomplete(linelist[i],"left"   ,1): gp_settings.settings['KEYPOS'] = gp_settings.settings['KEYPOS'].split()[0] + ' LEFT'   ; continue
        elif autocomplete(linelist[i],"right"  ,1): gp_settings.settings['KEYPOS'] = gp_settings.settings['KEYPOS'].split()[0] + ' RIGHT'  ; continue
        elif autocomplete(linelist[i],"xcentre",1): gp_settings.settings['KEYPOS'] = gp_settings.settings['KEYPOS'].split()[0] + ' MIDDLE' ; continue
       if autocomplete(linelist[i],"below"  ,2): gp_settings.settings['KEYPOS'] = "BELOW"                                               ; continue
       if autocomplete(linelist[i],"outside",1): gp_settings.settings['KEYPOS'] = "OUTSIDE"                                             ; continue
       try:
        offset = gp_eval.gp_eval(linelist[i],gp_settings.variables,gp_settings.functions)
        if (keymode == 0): gp_settings.settings['KEY_XOFF'] = offset
        if (keymode == 1): gp_settings.settings['KEY_YOFF'] = offset
        if (keymode <  2): keymode = keymode + 1
        else             :
         gp_error("Too many key offset expressions specified! Specify one x and one y offset at most.")
         raise ValueError
        continue
       except KeyboardInterrupt: raise
       except: pass
      return

    if ((command == "set") and autocomplete(linelist[1],"nokey",3)): # set nokey
     if (len(linelist) > 2):
      gp_error('Trailing word after "nokey" not expected.')
     gp_settings.settings['KEY']='OFF'
     return

    if ((command == "unset") and autocomplete(linelist[1],"nokey",3)): # unset nokey
     if (len(linelist) > 2):
      gp_error('Trailing word after "nokey" not expected.')
     gp_settings.settings['KEY']='ON'
     return

    if ((command == "unset") and autocomplete(linelist[1],"key",1)): # unset key
     if (len(linelist) > 2):
      gp_error('Trailing word after "key" not expected.')
     gp_settings.settings['KEY']      = gp_settings.settings_default['KEY']
     gp_settings.settings['KEYPOS']   = gp_settings.settings_default['KEYPOS']
     gp_settings.settings['KEY_XOFF'] = gp_settings.settings_default['KEY_XOFF']
     gp_settings.settings['KEY_YOFF'] = gp_settings.settings_default['KEY_YOFF']
     return

    if ((command == "set") and autocomplete(linelist[1],"keycolumns",4)): # set keycolumns
      test = re.match(r"""^\S*\s*\S*\s*(.*)""",line)
      if (test == None):
        gp_error("Error reading number of columns for key.")
      else:
        try:
          keycols = int(test.group(1))
          assert keycols > 0
          gp_settings.settings['KEYCOLUMNS'] = keycols
        except KeyboardInterrupt: raise
        except:
          gp_error("Invalid number of columns for key. Should be an integer value > 0.")
      return

    if ((command == "unset") and autocomplete(linelist[1],"keycolumns",4)): # unset keycolumns
     if (len(linelist) > 2):
      gp_error('Trailing word after "keycolumns" not expected.')
     gp_settings.settings['KEYCOLUMNS'] = gp_settings.settings_default['KEYCOLUMNS']
     return

    if ((command == "set") and autocomplete(linelist[1],"terminal",1)): # set terminal
      for i in range(2,len(linelist),1):
        if autocomplete(linelist[i],"x11_singlewindow",1): gp_settings.settings['TERMTYPE'] = "X11_singlewindow" ; continue
        if autocomplete(linelist[i],"x11_multiwindow" ,1): gp_settings.settings['TERMTYPE'] = "X11_multiwindow"  ; continue
        if autocomplete(linelist[i],"x11_persist"     ,1): gp_settings.settings['TERMTYPE'] = "X11_persist"      ; continue
        if autocomplete(linelist[i],"postscript"      ,1): gp_settings.settings['TERMTYPE'] = "PS"               ; continue
        if autocomplete(linelist[i],"eps"             ,1): gp_settings.settings['TERMTYPE'] = "PS"               ; gp_settings.settings['ENHANCED'] = "ON" ; continue
        if autocomplete(linelist[i],"png"             ,3): gp_settings.settings['TERMTYPE'] = "PNG"              ; continue
        if autocomplete(linelist[i],"gif"             ,3): gp_settings.settings['TERMTYPE'] = "GIF"              ; continue
        if autocomplete(linelist[i],"jpg"             ,3): gp_settings.settings['TERMTYPE'] = "JPG"              ; continue
        if autocomplete(linelist[i],"jpeg"            ,3): gp_settings.settings['TERMTYPE'] = "JPG"              ; continue
        if autocomplete(linelist[i],"color"           ,1): gp_settings.settings['COLOUR']   = "ON"               ; continue
        if autocomplete(linelist[i],"colour"          ,1): gp_settings.settings['COLOUR']   = "ON"               ; continue
        if autocomplete(linelist[i],"monochrome"      ,1): gp_settings.settings['COLOUR']   = "OFF"              ; continue
        if autocomplete(linelist[i],"enhanced"        ,2): gp_settings.settings['ENHANCED'] = "ON"               ; continue
        if autocomplete(linelist[i],"noenhanced"      ,1): gp_settings.settings['ENHANCED'] = "OFF"              ; continue
        if autocomplete(linelist[i],"landscape"       ,1): gp_settings.settings['LANDSCAPE']= "ON"               ; continue
        if autocomplete(linelist[i],"portrait"        ,3): gp_settings.settings['LANDSCAPE']= "OFF"              ; continue
        if autocomplete(linelist[i],"transparent"     ,1): gp_settings.settings['TERMTRANSPARENT']= "ON"         ; continue
        if autocomplete(linelist[i],"solid"           ,1): gp_settings.settings['TERMTRANSPARENT']= "OFF"        ; continue
        if autocomplete(linelist[i],"invert"          ,1): gp_settings.settings['TERMINVERT']= "ON"              ; continue
        if autocomplete(linelist[i],"noinvert"        ,3): gp_settings.settings['TERMINVERT']= "OFF"             ; continue
        gp_error("Unrecognised word: %s"%linelist[i])
      return

    if ((command == "unset") and autocomplete(linelist[1],"terminal",1)): # unset terminal
     if (len(linelist) > 2):
      gp_error('Trailing word after "terminal" not expected.')
     gp_settings.settings['TERMTYPE'] = gp_settings.settings_default['TERMTYPE']
     gp_settings.settings['COLOUR']   = gp_settings.settings_default['COLOUR']
     return

    test = re.match("""^\S*\s*(x|y|z)(\d*)""",line) # set label / unset label
    if (test != None):
     name = test.group(1) + test.group(2)
     if autocomplete(linelist[1],"%slabel"%name,3):
      try:
       direction = test.group(1)
       if (len(test.group(2)) == 0): number = 1
       else                        : number = int(test.group(2))
       if (number < 1): raise ValueError # Don't let user assign axis zero!
      except ValueError:
       gp_error("Illegal axis number in %s %s<n>label statement"%(command,test.group(1)))
       return
      if (command == "unset"):
       if (not number in gp_settings.axes[direction]):
        gp_error('Error: Attempt to unset label on non-existant axis %s%s.'%(direction,number))
        return
       else:
         if (len(linelist) > 2): gp_error('Trailing word after "label" not expected.')
         gp_settings.axes[direction][number]['LABEL']=""
      else:
       if (not number in gp_settings.axes[direction]): gp_settings.axes[direction][number] = gp_settings.default_axis.copy() # Create axis if it doesn't already exist
       test = re.match("""^\S*\s*\S*\s*(('|").*)""",line)
       if (test == None):
        gp_error("Label should be placed in quotes. Defaulting to blank title.")
        gp_settings.axes[direction][number]['LABEL']=""
       else:
        [title, aftertitle] = gp_eval.gp_getquotedstring(test.group(1))
        if (title != None):
          gp_settings.axes[direction][number]['LABEL'] = title
        else:
          gp_error("Error: Mismatched quotes in set %slabel command."%name)
        if (aftertitle != None) and (len(aftertitle.strip()) > 0):
          gp_error("Unexpected values given after set %slabel command."%name)
      if (not number in gp_plot.axes_this[direction]):                  # Modify axes_this is gp_plot, so that replot takes account of changes
       gp_plot.axes_this[direction][number] = {'SETTINGS':gp_settings.axes[direction][number].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
      else:
       gp_plot.axes_this[direction][number]['SETTINGS']['LABEL'] = gp_settings.axes[direction][number]['LABEL']
      return

    test = re.match("""^\S*\s*(x|y|z)(\d*)""",line) # set ticdir / unset ticdir
    if (test != None):
     name = test.group(1) + test.group(2)
     if autocomplete(linelist[1],"%sticdir"%name,6):
      try:
       direction = test.group(1)
       if (len(test.group(2)) == 0): number = 1
       else                        : number = int(test.group(2))
       if (number < 1): raise ValueError # Don't let user assign axis zero!
      except ValueError:
       gp_error("Illegal axis number in %s %s<n>ticdir statement"%(command,test.group(1)))
       return
      if (command == "unset"):
       if (not number in gp_settings.axes[direction]):
        gp_error('Error: Attempt to unset ticdir on non-existant axis %s%s.'%(direction,number))
        return
       else:
        if (len(linelist) > 2): gp_error('Trailing word after "ticdir" not expected.')
        gp_settings.axes[direction][number]['TICDIR']=gp_settings.default_axis['TICDIR']
      else:
       if (not number in gp_settings.axes[direction]): gp_settings.axes[direction][number] = gp_settings.default_axis.copy() # Create axis if it doesn't already exist
       if (len(linelist) < 3):
        gp_error("Error: Need to specify tic direction after 'set ticdir' statement.")
        return
       else:
        if   autocomplete(linelist[2],"inward",1) : gp_settings.axes[direction][number]['TICDIR'] = "INWARD"
        elif autocomplete(linelist[2],"outward",1): gp_settings.axes[direction][number]['TICDIR'] = "OUTWARD"
        elif autocomplete(linelist[2],"both",1)   : gp_settings.axes[direction][number]['TICDIR'] = "BOTH"
        else: gp_error("Error: Unrecognised tic direction '%s'. Should be 'inward', 'outward' or 'both'."%linelist[2])
        if (len(linelist) > 3):
          gp_error('Error: Trailing word after "set ticdir" not expected.')
      if (not number in gp_plot.axes_this[direction]):                  # Modify axes_this is gp_plot, so that replot takes account of changes
       gp_plot.axes_this[direction][number] = {'SETTINGS':gp_settings.axes[direction][number].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
      else:
       gp_plot.axes_this[direction][number]['SETTINGS']['TICDIR'] = gp_settings.axes[direction][number]['TICDIR']
      return

    test = re.match("""^\S*\s*(x|y|z)(\d*)""",line) # set range / unset range
    if (test != None):
     name = test.group(1) + test.group(2)
     if autocomplete(linelist[1],"%srange"%name,3):
      try:
       direction = test.group(1)
       if (len(test.group(2)) == 0): number = 1
       else:                         number = int(test.group(2))
       if (number < 1): raise ValueError # Don't let user assign axis zero!
      except ValueError:
       gp_error("Illegal axis number is set %s<n>range statement"%test.group(1))
       return
      if (command == "unset"):
       if (not number in gp_settings.axes[direction]):
        gp_error('Error: Attempt to unset range on non-existant axis %s%s.'%(direction,number))
        return
       else:
        if (len(linelist) > 2): gp_error('Trailing word after "range" not expected.')
        gp_settings.axes[direction][number]['MIN']       = gp_settings.default_axis['MIN']
        gp_settings.axes[direction][number]['MAX']       = gp_settings.default_axis['MAX']
      else:
       if (not number in gp_settings.axes[direction]): gp_settings.axes[direction][number] = gp_settings.default_axis.copy() # Create axis if it doesn't already exist
       test = re.match("""^\S*\s*\S*\s*restore""",line)
       if (test != None):
        gp_settings.axes[direction][number]['MIN'] = gp_settings.axes[direction][number]['MAX'] = None
       else:
        test = re.match(r"""^\S*\s*\S*\s*\[([^:\]]*)((:)|( *to *))?([^:\]]*)\]""",line)
        if (test == None):
         gp_error("Could not read range. Use format: set xrange [0:1].")
        else:
         try:
          if (len(test.group(1).strip()) != 0):
            gp_settings.axes[direction][number]['MIN'] = gp_eval.gp_eval(test.group(1),gp_settings.variables,gp_settings.functions)
          if (len(test.group(5).strip()) != 0):
            gp_settings.axes[direction][number]['MAX'] = gp_eval.gp_eval(test.group(5),gp_settings.variables,gp_settings.functions)
         except KeyboardInterrupt: raise
         except:
          gp_error("Error reading specified range.")
          gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

      if (not number in gp_plot.axes_this[direction]):                  # Modify axes_this is gp_plot, so that replot takes account of changes
       gp_plot.axes_this[direction][number] = {'SETTINGS':gp_settings.axes[direction][number].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
      else:
       gp_plot.axes_this[direction][number]['SETTINGS']['MIN']       = gp_settings.axes[direction][number]['MIN']
       gp_plot.axes_this[direction][number]['SETTINGS']['MAX']       = gp_settings.axes[direction][number]['MAX']
      return

# Main Directive Processor

line_combiner = ""

def directive(line, toplevel=True, interactive=False):
  global exitting, line_combiner

  if toplevel: gp_settings.cmd_history.append(line)

  gp_children.sigchld_handle()
  if (line.strip() == ""): return(2) # Blank lines do nothing.
  if (line.strip()[0] == "#"): return(2) # Comment lines also do nothing.

  # Check for \ line splitter
  if (line.strip()[-1] == "\\"):
   line_combiner = line_combiner + line.strip()[:-1]
   return
  line = line_combiner + line
  line_combiner = ""

  # Check for `` shell substitute command
  linesplit = gp_eval.gp_split(line, "`")
  linenew   = ""
  if ((len(linesplit)%2) == 0):
   gp_error("Error: mismatched ` in line.")
   return(1)
  for i in range(len(linesplit)):
   if ((i%2) == 1):
    os.chdir(gp_settings.cwd)
    shell_cmd = os.popen(linesplit[i],"r")
    linesplit[i] = shell_cmd.read().replace('\n',' ')
    shell_cmd.close()
    os.chdir(gp_settings.tempdir)
   linenew = linenew + linesplit[i]
  line = linenew

  # Can use ; to pass multiple commands on one line
  if (line.strip()[0] != "!"): # Don't split shell commandlines
   linelist = gp_eval.gp_split(line,';')
  else:
   linelist = [line.strip()]
  if (len(linelist) > 1):
   for i in range(len(linelist)):
    directive(linelist[i], False, interactive)
   return(2) 

  line     = line.strip() # Get rid of leading/trailing spaces
  linelist = line.split()
  if (len(linelist) < 1): return(2)

  # Pass command to parser
  command = gp_parser.parse(line,gp_settings.variables,gp_settings.functions)

  if (command == None): return(1) # Syntax error

  if (command['directive'] == "unrecognised"): # Unrecognised command

    if   (re.match(r'([A-Za-z]\w*)(\([^()]*\))([^=]*)=(.*)',line.strip()) != None): # f(x) = ...
     t =  re.match(r'([A-Za-z]\w*)(\([^()]*\))([^=]*)=(.*)',line.strip())
     try:
      gp_eval.gp_function_declare(line.strip(), gp_settings.functions)
     except KeyboardInterrupt: raise
     except:
      gp_error("Error defining function %s:"%t.group(1))
      gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    elif (   re.match(r'^([A-Za-z]\w*)\s*=(.*)',line) != None):                     # x = ...
      test = re.match(r'^([A-Za-z]\w*)\s*=(.*)',line)
      try:
        if (len(test.group(2).strip()) == 0):
          del gp_settings.variables[test.group(1).strip()]
        else:
          gp_settings.variables[test.group(1).strip()] = gp_eval.gp_eval(test.group(2),gp_settings.variables,gp_settings.functions)
      except KeyboardInterrupt: raise
      except: pass
    else:
      gp_error(gp_text.invalid%line) # invalid cmd
      return(1)

  elif (command['directive'] == "quit"):         # exit / quit
    exitting = 1
    return(0)
  elif (command['directive'] == "pling"):        # the ! command
    os.chdir(gp_settings.cwd)
    os.system(command['cmd']) # Execute command in user's cwd
    os.chdir(gp_settings.tempdir)
  elif (command['directive'] == "cd"):           # the cd command
    for subdict in command['path']:
     new_dir = glob.glob(os.path.join(gp_settings.cwd, subdict['directory']))
     if (len(new_dir) == 0):
      gp_error("Error: Directory '%s' could not be found."%linelist[i])
     else:
      gp_settings.cwd = new_dir[0]
  elif (command['directive'] == "pwd"):          # the pwd command
    gp_report(gp_settings.cwd)
  elif (command['directive'] == "help"):         # help / ?
    gp_help.directive_help(command, interactive)
  elif (command['directive'] == "load"):         # load
    main_loop([command['filename']])
  elif (command['directive'] == "save"):         # save
    try:
     savefile = open(os.path.join(gp_settings.cwd, os.path.expanduser(command['filename'])),"w")
     for line in gp_settings.cmd_history[:-1]: savefile.write(line+"\n")
     savefile.close()
    except KeyboardInterrupt: raise
    except:
     gp_error("Error writing output to file '%s':"%command['filename'])
     gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  elif (command['directive'] == "set_error"):    # set with no set option
    gp_error(gp_text.set_noword)
  elif (command['directive'] == "set"):          # set
    directive_set_unset(command,"set",line,linelist)
  elif (command['directive'] == "unset_error"):  # unset with no set option
    gp_error(gp_text.unset_noword)
  elif (command['directive'] == "unset"):        # unset
    directive_set_unset(command,"unset",line,linelist)
  elif (command['directive'] == "show"):         # show
    directive_show(command['setting_list'])
  elif (command['directive'] == "fit"):          # fit
    if (len(command['operands,'])>0):
     gp_warning("Syntax 'fit f(x)...' is supported by PyXPlot for gnuplot compatibility, but is deprecated. 'fit f() ...' is prefered.")
    try:
     gp_fit.directive_fit(line,gp_settings.variables,gp_settings.functions)
    except KeyboardInterrupt: raise
    except:
     gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  elif (command['directive'] == "spline"):       # spline
    try:
     gp_spline.directive_spline(line,gp_settings.variables,gp_settings.functions)
    except KeyboardInterrupt: raise
    except:
     gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  elif (command['directive'] == "plot"):         # plot
    gp_plot.directive_plot(line,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,
                           gp_settings.axes,gp_settings.labels,gp_settings.arrows,0,interactive)
  elif (command['directive'] == "replot"):       # replot
    gp_plot.directive_plot(line,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,
                           gp_settings.axes,gp_settings.labels,gp_settings.arrows,1,interactive)
  elif (command['directive'] == "text"):         # text
    gp_plot.directive_text(command,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,interactive)
  elif (command['directive'] == "arrow"):        # arrow
    gp_plot.directive_arrow(command,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,interactive)
  elif (command['directive'] == "clear"):        # clear
    gp_plot.multiplot_plotdesc = [] ; gp_plot.multiplot_plotorder = [] ; gp_plot.multiplot_text = [] ; gp_plot.multiplot_arrows = [] ; gp_plot.multiplot_axes = []
    if (gp_children.ghostview_pid != None): os.kill(gp_children.ghostview_pid, signal.SIGKILL) # Kill any X11_singlewindow gv sessions
  elif (command['directive'] == "reset"):        # reset
    gp_settings.settings              = gp_settings.settings_default.copy()
    gp_settings.settings['GRIDAXISX'] = gp_settings.settings_default['GRIDAXISX'][:]
    gp_settings.settings['GRIDAXISY'] = gp_settings.settings_default['GRIDAXISY'][:]
    gp_settings.axes = {'x':{1:gp_settings.default_axis.copy()},
                        'y':{1:gp_settings.default_axis.copy()},
                        'z':{1:gp_settings.default_axis.copy()} }

  elif (command['directive'] == "edit"):         # edit
    if (gp_settings.settings['MULTIPLOT'] != 'ON'):
     gp_error("Error: Can only edit plots when in multiplot mode.")
    else:
     editno = command['editno']
     if   (editno >= len(gp_plot.multiplot_plotorder)) or (editno < 0):
      gp_error("Error: Attempt to edit a multiplot plot with index %d -- no such plot."%editno)
     elif (gp_plot.multiplot_plotorder[editno] != "plot"):
      gp_error("Error: Attempt to edit a multiplot item which is not a plot. The edit command can only act on plots.")
     else:
      edititemno = 0
      for i in range(editno):
        if (gp_plot.multiplot_plotorder[i] == "plot"): edititemno += 1
      editno = edititemno
      gp_plot.replot_focus = editno
      gp_settings.settings = gp_plot.multiplot_plotdesc[editno][2].copy() # Reset all settings to those from this multiplot item
      gp_plot.plotlist     = gp_plot.multiplot_plotdesc[editno][0][:]
      gp_settings.labels   = gp_plot.multiplot_plotdesc[editno][3].copy()
      gp_settings.arrows   = gp_plot.multiplot_plotdesc[editno][4].copy()
      gp_settings.axes     = { 'x':{},'y':{},'z':{} } # Likewise for axis settings
      gp_plot.axes_this    = { 'x':{},'y':{},'z':{} }
      for [direction,axis_list_to] in gp_settings.axes.iteritems():
       for [number,axis] in gp_plot.multiplot_axes[editno][direction].iteritems():
        axis_list_to[number] = axis['SETTINGS'].copy()
        gp_plot.axes_this[direction][number] = {'SETTINGS':axis['SETTINGS'].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}

  elif (command['directive'] == "delete"):       # delete
    if (gp_settings.settings['MULTIPLOT'] != 'ON'):
     gp_error("Error: Can only delete items when in multiplot mode.")
    else:
     deleteno = command['deleteno']
     if (deleteno >= len(gp_plot.multiplot_plotorder)) or (deleteno < 0):
      gp_error("Error: Attempt to delete multiplot item with index %d -- no such item."%deleteno)
     else:
      itemtype = gp_plot.multiplot_plotorder[deleteno]
      deleteitemno = 0
      for i in range(deleteno):
        if (gp_plot.multiplot_plotorder[i] == itemtype): deleteitemno += 1
      if   (itemtype == "plot"):
       if (gp_plot.multiplot_plotdesc[deleteitemno][5] == 'ON'): gp_warning("Warning: Attempt to delete a multiplot plot which is already deleted.")
       else: gp_plot.multiplot_plotdesc[deleteitemno][5] = 'ON' # Set delete flag on a plot
      elif (itemtype == "text"):
       if (gp_plot.multiplot_text[deleteitemno][4] == 'ON'): gp_warning("Warning: Attempt to delete a multiplot text item which is already deleted.")
       else: gp_plot.multiplot_text[deleteitemno][4] = 'ON' # Set delete flag on a text item
      elif (itemtype == "arrow"):
       if (gp_plot.multiplot_arrows[deleteitemno][6] == 'ON'): gp_warning("Warning: Attempt to delete a multiplot arrow which is already deleted.")
       else: gp_plot.multiplot_arrows[deleteitemno][6] = 'ON' # Set delete flag on an arrow
      try:
       if (gp_settings.settings['DISPLAY'] == "ON"):
        gp_plot.multiplot_plot(gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings) # Refresh display
      except KeyboardInterrupt: raise
      except:
       gp_error("Error: Problem encountered whilst refreshing display after delete operation.")
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

  elif (command['directive'] == "undelete"):     # undelete
    if (gp_settings.settings['MULTIPLOT'] != 'ON'):
     gp_error("Error: Can only undelete items when in multiplot mode.")
    else:
     deleteno = command['undeleteno']
     if (deleteno >= len(gp_plot.multiplot_plotorder)) or (deleteno < 0):
      gp_error("Error: Attempt to undelete multiplot item with index %d -- no such item."%deleteno)
     else:
      itemtype = gp_plot.multiplot_plotorder[deleteno]
      deleteitemno = 0
      for i in range(deleteno):
        if (gp_plot.multiplot_plotorder[i] == itemtype): deleteitemno += 1
      if   (itemtype == "plot"):
       if (gp_plot.multiplot_plotdesc[deleteitemno][5] != 'ON'): gp_warning("Warning: Attempt to undelete a multiplot plot which isn't deleted.")
       else: gp_plot.multiplot_plotdesc[deleteitemno][5] = 'OFF' # Unset delete flag on a plot
      elif (itemtype == "text"):
       if (gp_plot.multiplot_text[deleteitemno][4] != 'ON'): gp_warning("Warning: Attempt to undelete a multiplot text item which isn't deleted.")
       else: gp_plot.multiplot_text[deleteitemno][4] = 'OFF' # Unset delete flag on a text item
      elif (itemtype == "arrow"):
       if (gp_plot.multiplot_arrows[deleteitemno][6] != 'ON'): gp_warning("Warning: Attempt to undelete a multiplot arrow which isn't deleted.") 
       else: gp_plot.multiplot_arrows[deleteitemno][6] = 'OFF' # Unset delete flag on an arrow
      try:
       if (gp_settings.settings['DISPLAY'] == "ON"):
        gp_plot.multiplot_plot(gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings) # Refresh display
      except KeyboardInterrupt: raise
      except:
       gp_error("Error: Problem encountered whilst refreshing display after undelete operation.")
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

  elif (command['directive'] == "move"):         # move
    if (gp_settings.settings['MULTIPLOT'] != 'ON'):
     gp_error("Error: Can only move items when in multiplot mode.")
    else:
     moveno = command['moveno']
     if (moveno >= len(gp_plot.multiplot_plotorder)) or (moveno < 0):
      gp_error("Error: Attempt to move a multiplot item with index %d -- no such item."%moveno)
     else:
      itemtype = gp_plot.multiplot_plotorder[moveno]
      moveitemno = 0
      for i in range(moveno):
        if (gp_plot.multiplot_plotorder[i] == itemtype): moveitemno += 1
      if   (itemtype == "plot"):
       gp_plot.multiplot_plotdesc[moveitemno][2]['ORIGINX'] = command['x']
       gp_plot.multiplot_plotdesc[moveitemno][2]['ORIGINY'] = command['y']
      elif (itemtype == "text"):
       gp_plot.multiplot_text[moveitemno][1] = command['x']
       gp_plot.multiplot_text[moveitemno][2] = command['y']
      elif (itemtype == "arrow"):
       gp_plot.multiplot_arrows[moveitemno][0] = command['x']
       gp_plot.multiplot_arrows[moveitemno][1] = command['y']
      try:
       if (gp_settings.settings['DISPLAY'] == "ON"):
        gp_plot.multiplot_plot(gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings) # Refresh display
      except KeyboardInterrupt: raise
      except:
       gp_error("Error: Problem encountered whilst refreshing display after move operation.")
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

  elif (command['directive'] == "refresh"):      # refresh
    try:
      if (gp_settings.settings['DISPLAY'] == "ON"):
        gp_plot.multiplot_plot(gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings) # Refresh display
    except KeyboardInterrupt: raise
    except:
     gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return

  elif (command['directive'] == "print"):        # print
   printstring = ""
   for subdict in command['print_list,']:
    if 'expression' in subdict:
     printstring += "%s "%subdict['expression']
    if 'string' in subdict:
     printstring += "%s "%subdict['string']
   gp_report(printstring)

  else:
    gp_error(gp_text.invalid%linelist[0])        # invalid cmd
    return(1)
  return (0)

def Interactive():   # Interactive PyXPlot terminal
  global exitting,line_combiner,SCIPY_ABSENT
  exitting=0
  if (sys.stdin.isatty() and gp_settings.display_splash): # Only print welcome blurb if running interactively, i.e. not from pipe
    gp_report(gp_text.init)
    if SCIPY_ABSENT:
     gp_warning("Warning: The scipy numerical library for python is not installed. Without this, some features in PyXPlot will be disabled, including the spline and fit commands, and the integration of functions. To enable these features, install scipy and try again.")
     SCIPY_ABSENT = False # Only warn once
  try:
    linenumber=0
    while (exitting==0):
      gp_children.stat_gv_output()
      if (sys.stdin.isatty()):
        try:
          if (line_combiner == ""): prompt = "pyxplot> "
          else                    : prompt = ".......> "
          input_cmd = raw_input(prompt)
          try: directive(input_cmd, interactive=True)
          except KeyboardInterrupt: gp_report("Received SIGINT. Terminating command.")
        except KeyboardInterrupt: gp_report("") # CTRL-C at command-prompt just gives a new command prompt
      else:
        linenumber=linenumber+1
        gp_error_setstreaminfo(linenumber,"input stream")
        directive(raw_input()) # Don't print command prompt when running from a pipe
  except (KeyboardInterrupt,EOFError): pass # EOFError == CTRL-D
  if sys.stdin.isatty():
   if gp_settings.display_splash: gp_report("\nGoodbye. Have a nice day.")
   else                         : gp_report("")
  gp_error_setstreaminfo(-1,"")
  return

# Main loop

recurse_depth = 0

def main_loop(commandparams):
 global recurse_depth 
 recurse_depth = recurse_depth + 1 # Recursive loading protection
 if (recurse_depth > 10):
  gp_warning("Warning: recursive file loading detecting; load command failing")
  return

 if (len(commandparams) > 0): # Input files specified on commandline
  for i in range(0,len(commandparams)):
   if (commandparams[i] == '-'): # A minus on commandline means interactive
    Interactive()
   elif ((commandparams[i] == '-h') or (commandparams[i] == '--help')):
    gp_report(gp_text.help)
   elif ((commandparams[i] == '-v') or (commandparams[i] == '--version')): # NB: -q option implemented below
    gp_report(gp_text.version)
   else:
    infiles = glob.glob(os.path.join(gp_settings.cwd, os.path.expanduser(commandparams[i])))
    if (len(infiles) == 0):
     gp_error("PyXPlot Error: Could not find command file '%s'"%commandparams[i])
     gp_error("Skipping on to next command file")
    else:
     for infile in infiles:
      exitting=0
      try:
       instream = open(infile,"r")
      except KeyboardInterrupt: raise
      except:
       gp_error("PyXPlot Error: Could not open command file '%s'"%commandparams[i])
       gp_error("Skipping on to next command file")
      else:
       firstline=True # This flips to false after we've processed a non-blank line successfully
       linenumber=0
       for line in instream.readlines():
        linenumber=linenumber+1
        gp_error_setstreaminfo(linenumber,"file '%s'"%infile)
        status = directive(line)
        if (firstline and (status == 1)):
         gp_error("Error on first line of commandfile: Is this is valid script?")
         gp_error("Aborting")
         break
        if (status == 0): firstline=False
        if (exitting==1): break
       gp_error_setstreaminfo(-1,"")
 else: # Otherwise enter interactive mode
   Interactive()

# MAIN ENTRY POINT

# Store path to user's cwd ; but put LaTeX's junk in /tmp for tidiness
gp_settings.cwd = os.getcwd()
os.chdir(gp_settings.tempdir)

# Read user's PyXPlot history, if it exists
if not READLINE_ABSENT:
 readline.set_history_length(1000)
 try: readline.read_history_file(os.path.expanduser("~/.pyxplot_history"))
 except: pass

# Turn off splashscreen if requested (commandline option -q)
while '-q' in sys.argv:
 gp_settings.display_splash = False
 sys.argv.remove('-q')
while '--quiet' in sys.argv:
 gp_settings.display_splash = False
 sys.argv.remove('--quiet')

# Turn on splashscreen if requested (commandline option -V)
while '-V' in sys.argv:
 gp_settings.display_splash = False
 sys.argv.remove('-V')
while '--verbose' in sys.argv:
 gp_settings.display_splash = False
 sys.argv.remove('--verbose')

# Turn on syntax highlighting if requested (commandline option -c)
while '-c' in sys.argv:
 gp_error_setcolour()
 sys.argv.remove('-c')
while '--colour' in sys.argv:
 gp_error_setcolour()
 sys.argv.remove('--colour')
while '--color' in sys.argv:
 gp_error_setcolour()
 sys.argv.remove('--color')

# Turn off syntax highlighting if requested (commandline option -m)
while '-m' in sys.argv:
 gp_error_setnocolour()
 sys.argv.remove('-m')
while '--monochrome' in sys.argv:
 gp_error_setnocolour()
 sys.argv.remove('--monochrome')

# Fix default terminal. If running interatively at any point, use X11_singlewindow.
# If we are going to run entirely from script all the way, default is postscript
if (gp_settings.config_lookup_opt('settings','TERMTYPE','default',gp_settings.termtypes ) == 'default'):
 if  (  ((len(sys.argv)>1) and ("-" not in sys.argv))
     or (gp_version.GHOSTVIEW == '/bin/false')
     or ('DISPLAY' not in os.environ.keys())
     or (len(os.environ['DISPLAY']) < 1)
     or (not sys.stdin.isatty())
     ):
  gp_settings.settings['TERMTYPE'] = 'PS'

# Loop over all config files passed to us on the commandline
main_loop(sys.argv[1:])

# Clean up any temporary .eps files which X11 terminal has placed in /tmp
gp_children.massacre_children()
os.chdir("/tmp")
gp_settings.gv_errorfile.close()
os.system("rm -Rf %s"%gp_settings.tempdir)

# Write history file
if not READLINE_ABSENT:
 try: readline.write_history_file(os.path.expanduser("~/.pyxplot_history"))
 except: pass
