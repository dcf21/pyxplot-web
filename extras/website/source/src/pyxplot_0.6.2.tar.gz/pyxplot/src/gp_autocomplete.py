# GP_AUTOCOMPLETE.PY
# Dominic Ford
# 19/01/2007

alphabetic_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

# AUTOCOMPLETE(): Return TRUE if input string first word matches the first few
# letters of test (minimum min letters)

# Returns integer, which is position of first character not matched, plus one.
# We add one so that if min=0, we can return position zero and still have an
# integer value equivalent to TRUE.

def autocomplete(input, test, min):
  alphabetic = True
  for char in test:
   if char not in alphabetic_chars:
    alphabetic = False # Is string we are matching is all letters, it can be terminated with punctuation

  i = 0
  input2 = input.strip() # Strip leading/trailing spaces
  while (i < len(input2)):
    if (i < len(test)):
      if (input2[i].capitalize() != test[i].capitalize()):
        if (input2[i].isspace()) or (alphabetic and input2[i] not in alphabetic_chars): break
        else: return (0 == 1) # We hit a character which isn't in test string
    else:
      if (input2[i].isspace()) or (alphabetic and input2[i] not in alphabetic_chars): return i+1
      else                                                                          : return 0
    i=i+1
  if (i >= min): return i+1 # We read > than minimum number of characters before hitting whitespace
  return 0 # We didn't
