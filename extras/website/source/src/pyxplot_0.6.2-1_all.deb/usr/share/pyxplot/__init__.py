#!/usr/bin/python2.4
try: __import__('pyxplot')
except KeyboardInterrupt: print 'PyXPlot has received SIGINT: Exitting.'
