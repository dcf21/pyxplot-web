# GP_SETTINGS.PY
# Dominic Ford
# 14/06/2006

import os
import sys
import glob
import stat
import ConfigParser
import pyx

import gp_eval
from gp_error import *

#
# CONFIGURATION FILE HANDLING
#

# Check for settings in configuration files .pyxplotrc in c.w.d. or user's homespace
config_list = [".pyxplotrc",  os.path.expanduser("~/.pyxplotrc")]

try:
 config_files = ConfigParser.ConfigParser()
 config_files.read(config_list)
except:
 config_files = None
 gp_warning("Warning: Could not parse configuration file -- missing section heading, perhaps?")

# CONFIG_LOOKUP_FOO(): Check for entry [section,option] in configuration file.
# If not found, return default.

def config_lookup_str(section, option, default):
 try   : return config_files.get(section, option)
 except: return default

def config_lookup_float(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return float(value)
 except:
  gp_warning("Warning: Value '%s' for [%s,%s] in configuration file should be floating point."%(value, section, option))
  return default

def config_lookup_int(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return int(value)
 except:
  gp_warning("Warning: Value '%s' for [%s,%s] in configuration file should be an integer."%(value, section, option))
  return default

def config_lookup_opt(section, option, default, options):
 try   : value = config_files.get(section, option)
 except: return default
 if (value in options): return value
 else:
  gp_warning("Warning: Value '%s' for [%s,%s] in configuration file should be one of options %s."%(value, section, option, options))
  return default

def config_lookup_opt2(section, option, default, options): # As above, but capitalises input
 try   : value = config_files.get(section, option)
 except: return default
 if (value.capitalize() in options): return value.capitalize()
 else:
  gp_warning("Warning: Value '%s' for [%s,%s] in configuration file should be one of options %s."%(value, section, option, options))
  return default

# Make a dictionary of PyX colours called pyx_colours

pyx_colours={
"Greenyellow":pyx.color.cmyk.GreenYellow,
"Yellow":pyx.color.cmyk.Yellow,
"Goldenrod":pyx.color.cmyk.Goldenrod,
"Dandelion":pyx.color.cmyk.Dandelion,
"Apricot":pyx.color.cmyk.Apricot,
"Peach":pyx.color.cmyk.Peach,
"Melon":pyx.color.cmyk.Melon,
"Yelloworange":pyx.color.cmyk.YellowOrange,
"Orange":pyx.color.cmyk.Orange,
"Burntorange":pyx.color.cmyk.BurntOrange,
"Bittersweet":pyx.color.cmyk.Bittersweet,
"Redorange":pyx.color.cmyk.RedOrange,
"Mahogany":pyx.color.cmyk.Mahogany,
"Maroon":pyx.color.cmyk.Maroon,
"Brickred":pyx.color.cmyk.BrickRed,
"Red":pyx.color.cmyk.Red,
"Orangered":pyx.color.cmyk.OrangeRed,
"Rubinered":pyx.color.cmyk.RubineRed,
"Wildstrawberry":pyx.color.cmyk.WildStrawberry,
"Salmon":pyx.color.cmyk.Salmon,
"Carnationpink":pyx.color.cmyk.CarnationPink,
"Magenta":pyx.color.cmyk.Magenta,
"Violetred":pyx.color.cmyk.VioletRed,
"Rhodamine":pyx.color.cmyk.Rhodamine,
"Mulberry":pyx.color.cmyk.Mulberry,
"Redviolet":pyx.color.cmyk.RedViolet,
"Fuchsia":pyx.color.cmyk.Fuchsia,
"Lavender":pyx.color.cmyk.Lavender,
"Thistle":pyx.color.cmyk.Thistle,
"Orchid":pyx.color.cmyk.Orchid,
"Darkorchid":pyx.color.cmyk.DarkOrchid,
"Purple":pyx.color.cmyk.Purple,
"Plum":pyx.color.cmyk.Plum,
"Violet":pyx.color.cmyk.Violet,
"Royalpurple":pyx.color.cmyk.RoyalPurple,
"Blueviolet":pyx.color.cmyk.BlueViolet,
"Periwinkle":pyx.color.cmyk.Periwinkle,
"Cadetblue":pyx.color.cmyk.CadetBlue,
"Cornflowerblue":pyx.color.cmyk.CornflowerBlue,
"Midnightblue":pyx.color.cmyk.MidnightBlue,
"Navyblue":pyx.color.cmyk.NavyBlue,
"Royalblue":pyx.color.cmyk.RoyalBlue,
"Blue":pyx.color.cmyk.Blue,
"Cerulean":pyx.color.cmyk.Cerulean,
"Cyan":pyx.color.cmyk.Cyan,
"Processblue":pyx.color.cmyk.ProcessBlue,
"Skyblue":pyx.color.cmyk.SkyBlue,
"Turquoise":pyx.color.cmyk.Turquoise,
"Tealblue":pyx.color.cmyk.TealBlue,
"Aquamarine":pyx.color.cmyk.Aquamarine,
"Bluegreen":pyx.color.cmyk.BlueGreen,
"Emerald":pyx.color.cmyk.Emerald,
"Junglegreen":pyx.color.cmyk.JungleGreen,
"Seagreen":pyx.color.cmyk.SeaGreen,
"Green":pyx.color.cmyk.Green,
"Forestgreen":pyx.color.cmyk.ForestGreen,
"Pinegreen":pyx.color.cmyk.PineGreen,
"Limegreen":pyx.color.cmyk.LimeGreen,
"Yellowgreen":pyx.color.cmyk.YellowGreen,
"Springgreen":pyx.color.cmyk.SpringGreen,
"Olivegreen":pyx.color.cmyk.OliveGreen,
"Rawsienna":pyx.color.cmyk.RawSienna,
"Sepia":pyx.color.cmyk.Sepia,
"Brown":pyx.color.cmyk.Brown,
"Tan":pyx.color.cmyk.Tan,
"Gray":pyx.color.cmyk.Gray,
"Grey":pyx.color.cmyk.Grey,
"Black":pyx.color.cmyk.Black,
"White":pyx.color.cmyk.White,
"Grey05":pyx.color.gray(0.05),
"Grey10":pyx.color.gray(0.10),
"Grey15":pyx.color.gray(0.15),
"Grey20":pyx.color.gray(0.20),
"Grey25":pyx.color.gray(0.25),
"Grey30":pyx.color.gray(0.30),
"Grey35":pyx.color.gray(0.35),
"Grey40":pyx.color.gray(0.40),
"Grey45":pyx.color.gray(0.45),
"Grey50":pyx.color.gray(0.50),
"Grey55":pyx.color.gray(0.55),
"Grey60":pyx.color.gray(0.60),
"Grey65":pyx.color.gray(0.65),
"Grey70":pyx.color.gray(0.70),
"Grey75":pyx.color.gray(0.75),
"Grey80":pyx.color.gray(0.80),
"Grey85":pyx.color.gray(0.85),
"Grey90":pyx.color.gray(0.90),
"Grey95":pyx.color.gray(0.95),
"Gray05":pyx.color.gray(0.05),
"Gray10":pyx.color.gray(0.10),
"Gray15":pyx.color.gray(0.15),
"Gray20":pyx.color.gray(0.20),
"Gray25":pyx.color.gray(0.25),
"Gray30":pyx.color.gray(0.30),
"Gray35":pyx.color.gray(0.35),
"Gray40":pyx.color.gray(0.40),
"Gray45":pyx.color.gray(0.45),
"Gray50":pyx.color.gray(0.50),
"Gray55":pyx.color.gray(0.55),
"Gray60":pyx.color.gray(0.60),
"Gray65":pyx.color.gray(0.65),
"Gray70":pyx.color.gray(0.70),
"Gray75":pyx.color.gray(0.75),
"Gray80":pyx.color.gray(0.80),
"Gray85":pyx.color.gray(0.85),
"Gray90":pyx.color.gray(0.90),
"Gray95":pyx.color.gray(0.95)
}

# Available options for different data types

datastyles = ['points','lines','linespoint','xerrorbars','yerrorbars','xyerrorbars','xerrorrange','yerrorrange','xyerrorrange','dots','impulses','boxes','wboxes','steps','fsteps','histeps','arrows_head','arrows_nohead','arrows_twohead','csplines','acsplines']
onoff      = ['ON', 'OFF']
termtypes  = ['X11_singlewindow','X11_multiwindow','eps','png','jpg','gif']
keyposes   = ["TOP RIGHT","TOP MIDDLE","TOP LEFT","MIDDLE RIGHT","MIDDLE MIDDLE","MIDDLE LEFT","BOTTOM RIGHT","BOTTOM MIDDLE","BOTTOM LEFT","BELOW","OUTSIDE"]
fontsizes  = [-4, -3, -2, -1, 0, 1, 2, 3, 4, 5]
colours    = pyx_colours.keys()

#
# DEFAULT PALETTE
#

colour_list_default = ['Black', 'Red', 'Blue', 'Magenta', 'Cyan', 'Brown', 'Salmon', 'Gray', 'Green', 'NavyBlue', 'Periwinkle', 'PineGreen', 'SeaGreen', 'GreenYellow', 'Orange', 'CarnationPink', 'Plum' ]
colour_list = colour_list_default

#
# DEFAULT LINESTYLES AND POINTSTYLES
#

symbol_list = [pyx.graph.style.symbol.cross, pyx.graph.style.symbol.plus, pyx.graph.style.symbol.square, pyx.graph.style.symbol.triangle, pyx.graph.style.symbol.circle, pyx.graph.style.symbol.diamond]

linestyle_list = [pyx.style.linestyle.solid, pyx.style.linestyle.dashed, pyx.style.linestyle.dotted, pyx.style.linestyle.dashdotted, pyx.style.dash((3,2,1,1,1,2),0), pyx.style.dash((3,1,1,3,1,1),0), pyx.style.dash((3,1,3,1,3,1),0), pyx.style.dash((4,4),0)]

# Now set default options, using configuration file settings as overide if present

settings_default = {'ORIGINX'        :config_lookup_float('settings','ORIGINX'        ,0.0                          ) ,
                    'ORIGINY'        :config_lookup_float('settings','ORIGINY'        ,0.0                          ) ,
                    'MULTIPLOT'      :config_lookup_opt  ('settings','MULTIPLOT'      ,'OFF'             ,onoff     ) ,
                    'TITLE'          :config_lookup_str  ('settings','TITLE'          ,''                           ) ,
                    'TIT_XOFF'       :config_lookup_float('settings','TIT_XOFF'       ,0.0                          ) , # x offset of title
                    'TIT_YOFF'       :config_lookup_float('settings','TIT_YOFF'       ,0.0                          ) ,
                    'TERMTYPE'       :config_lookup_opt  ('settings','TERMTYPE'       ,'X11_singlewindow',termtypes ) ,
                    'OUTPUT'         :config_lookup_str  ('settings','OUTPUT'         ,''                           ) ,
                    'BACKUP'         :config_lookup_opt  ('settings','BACKUP'         ,'OFF'             ,onoff     ) ,
                    'ENHANCED'       :config_lookup_opt  ('settings','ENHANCED'       ,'ON'              ,onoff     ) , # Enhanced (encapsulated) ps?
                    'LANDSCAPE'      :config_lookup_opt  ('settings','LANDSCAPE'      ,'OFF'             ,onoff     ) , # Landscape noeps postscript?
                    'TERMINVERT'     :config_lookup_opt  ('settings','TERMINVERT'     ,'OFF'             ,onoff     ) , # Inverted colour image output?
                    'TERMTRANSPARENT':config_lookup_opt  ('settings','TERMTRANSPARENT','OFF'             ,onoff     ) , # Image output transparent?
                    'DPI'            :config_lookup_float('settings','DPI'            ,300.0                        ) , # DPI of bitmap graphics output.
                    'WIDTH'          :config_lookup_float('settings','WIDTH'          ,8.0                          ) , # Width of output / cm
                    'ASPECT'         :config_lookup_float('settings','ASPECT'         ,1.0                          ) , # Aspect ratio of plot
                    'AUTOASPECT'     :config_lookup_opt  ('settings','AUTOASPECT'     ,'ON'              ,onoff     ) , # Use PyX default aspect ratio
                    'POINTSIZE'      :config_lookup_float('settings','POINTSIZE'      ,1.0                          ) , # Default pointsize
                    'POINTLINEWIDTH' :config_lookup_float('settings','POINTLINEWIDTH' ,1.0             ) , # Default linewidth used for drawing points
                    'LINEWIDTH'      :config_lookup_float('settings','LINEWIDTH'      ,1.0                          ) , # Default linewidth
                    'FONTSIZE'       :config_lookup_opt  ('settings','FONTSIZE'       ,0                 ,fontsizes ) , # Font size (-4 < i < 5)
                    'TEXTCOLOUR'     :config_lookup_opt2 ('settings','TEXTCOLOUR'     ,'Black'           ,colours   ) ,
                    'AXESCOLOUR'     :config_lookup_opt2 ('settings','AXESCOLOUR'     ,'Black'           ,colours   ) ,
                    'GRIDMAJCOLOUR'  :config_lookup_opt2 ('settings','GRIDMAJCOLOUR'  ,'Grey60'          ,colours   ) ,
                    'GRIDMINCOLOUR'  :config_lookup_opt2 ('settings','GRIDMINCOLOUR'  ,'Grey90'          ,colours   ) ,
                    'DATASTYLE'      :config_lookup_opt  ('settings','DATASTYLE'      ,'points'          ,datastyles) ,
                    'FUNCSTYLE'      :config_lookup_opt  ('settings','FUNCSTYLE'      ,'lines'           ,datastyles) ,
                    'SAMPLES'        :config_lookup_int  ('settings','SAMPLES'        ,250                          ) ,
                    'COLOUR'         :config_lookup_opt  ('settings','COLOUR'         ,'ON'              ,onoff     ) ,
                    'KEY'            :config_lookup_opt  ('settings','KEY'            ,'ON'              ,onoff     ) ,
                    'KEYPOS'         :config_lookup_opt  ('settings','KEYPOS'         ,'TOP RIGHT'       ,keyposes  ) ,
                    'KEY_XOFF'       :config_lookup_float('settings','KEY_XOFF'       ,0.0                          ) ,
                    'KEY_YOFF'       :config_lookup_float('settings','KEY_YOFF'       ,0.0                          ) ,
                    'GRID'           :config_lookup_opt  ('settings','GRID'           ,'OFF'             ,onoff     ) ,
                    'GRIDAXISX'      :[config_lookup_int  ('settings','GRIDAXISX'      ,1                            ) ],
                    'GRIDAXISY'      :[config_lookup_int  ('settings','GRIDAXISY'      ,1                            ) ],
                    'BOXWIDTH'       :config_lookup_float('settings','BOXWIDTH'       ,0.0                          ) ,
                    'BOXFROM'        :config_lookup_float('settings','BOXFROM'        ,0.0                          ) ,
                    }

default_axis = {'LABEL'    :'',
                'MIN'      : None,
                'MAX'      : None,
                'LOG'      :'OFF'}

linestyles = {} # User-defined linestyles
arrows     = {} # Arrows superposed on figure
labels     = {} # Text labels

variables  = {'pi':3.14159265358979} # User-defined variables
functions  = {}                      # User-defined functions

# NOW IMPORT FUNCTIONS FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('functions'):
  try:
    gp_eval.gp_function_declare(preconfigvar[0] + "=" + preconfigvar[1], functions)
  except:
    gp_error("Error importing function %s from configuration file:"%(preconfigvar[0]))
    gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
except:
 pass # Ignore if no functions section 


# NOW IMPORT VARIABLES FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('variables'):
  try:
    variables[preconfigvar[0]] = gp_eval.gp_eval(preconfigvar[1], variables, functions)
  except:
    gp_warning("Warning: Expression '%s' for variable %s in configuration file could not be evaluated."%(preconfigvar[0],preconfigvar[1]))
except:
 pass # Ignore if no variables section 

# NOW IMPORT COLOURS FROM CONFIGURATION FILE

colours_in  = config_lookup_str('colours','PALETTE','')
if (colours_in != ""):
 colours_in  = colours_in.split(',')
 colours_new = []
 for colour in colours_in:
  if (colour.strip().capitalize() in colours): colours_new.append(colour.strip().capitalize())
  else                                       : gp_error("Unrecognised colour '%s' in configuration file pallette; skipping."%colour.strip())
 if (len(colours_new) == 0):
  gp_error("No colours found in configuration file pallette; reverting to default pallette.")
 else:
  colour_list = colours_new

# Now that we have default settings, make copy them into initial settings

settings = settings_default.copy()
settings['GRIDAXISX'] = settings_default['GRIDAXISX'][:]
settings['GRIDAXISY'] = settings_default['GRIDAXISY'][:]

# By default, have one of each kind of axis... x1, y1 and z1
axes = {'x':{1:default_axis.copy()},
        'y':{1:default_axis.copy()},
        'z':{1:default_axis.copy()} }

# STORAGE OF DIRECTORY PATHS

# User's cwd, which we store here before setting cwd to a temporary folder for the duration of our activities
cwd = ""

# Make a directory into which we put temporary files
tempdirnumber = 1
file_paths=['foo']
while (len(file_paths) != 0): # Take care not to overright a pre-existing file in /tmp
 tempdirnumber = tempdirnumber + 1
 tempdir = "/tmp/gp+_" + str(os.getpid()) + "_" + str(tempdirnumber)
 file_paths=glob.glob(tempdir)
os.mkdir(tempdir)
if ((not os.path.isdir(tempdir)) or (not (os.stat(tempdir)[stat.ST_UID] == os.getuid()))):
 gp_error("Fatal Error: Security error whilst trying to create temporary directory")
 sys.exit(0)

