# GP_TEXT.PY
# Dominic Ford
# 27/04/2006

# Contains text messages which gnuplot+ displays

import gp_version # Version and date strings written by installer

VERSION = gp_version.VERSION
DATE    = gp_version.DATE

init = r"""

        G N U P L O T +
        Version """+VERSION+r"""
        """+DATE+r"""

        Copyright (C) 2006
        Dominic Ford

        This is GnuPlot+ version """+VERSION+r""", a plotting package based
        upon the GnuPlot API, but with superior plotting quality
        provided courtesy of PyX.

        This is an beta-testing version, and presently only
        supports a minimal subset of the GnuPlot API.

        Don't type 'help' to access the on-line reference manual.

        Send comments, bug reports, feature requests and coffee
        supplies to:
            <dcf21@mrao.cam.ac.uk>
"""

invalid = r"""
         ^
         invalid command
"""

set = r"""
            ^
         invalid set option.

Set options which GnuPlot+ recognises are: [] = choose one, <> = optional

'arrow', 'autoscale', 'data style', 'function style', 'grid', 'key', 'label',
'linestyle', 'logscale', 'multiplot', 'noarrow', 'nogrid', 'nokey', 'nolabel',
'nolinestyle', 'nologscale', 'nomultiplot', 'notitle', 'origin', 'pointsize',
'samples', 'size', 'size noratio', 'size square', 'size ratio', 'terminal',
'title', 'width', '[xyz]<n>label', '[xyz]<n>range'

Set options from GnuPlot which GnuPlot+ DOES NOT recognise:

'angles', 'bars', 'border', 'boxwidth', 'clabel', 'clip', 'cntrparam',
'colorbox', 'contour', 'decimalsign', 'dgrid3d', 'dummy', 'encoding', 'format',
'hidden3d', 'historysize', 'isosamples', 'locale', '[blrt]margin', 'mapping',
'mouse', 'offsets', 'palette', 'parametric', 'pm3d', 'polar', 'print',
'[rtuv]range', 'style', 'surface', 'tics', 'ticscale', 'ticslevel',
'timestamp', 'timefmt', 'view', '[xyz]{2}data', '{no}{m}[xyz]{2}tics',
'[xyz]{2}[md]tics', '{[xyz]{2}}zeroaxis', 'zero'
"""

unset = r"""
            ^
         invalid unset option.

Unset options which GnuPlot+ recognises are: [] = choose one, <> = optional

'arrow', 'autoscale', 'grid', 'key', 'label', 'linestyle', 'logscale',
'multiplot', 'origin', 'pointsize', 'samples', 'size', 'terminal', 'title',
'width', '[xyz]<n>label', '[xyz]<n>range'
"""

show = r"""
             ^
Valid 'show' options are:

      'all', 'axes', 'settings', 'plotting', 'linestyle', 'var(iable)s'
"""
