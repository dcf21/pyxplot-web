# GP_FIT.PY
# Dominic Ford
# 18/08/2006

import gp_eval
import gp_datafile
import gp_plot
from gp_autocomplete import *
from gp_error import *

import sys
import re
from math import *
import scipy
from scipy.optimize import fmin
from scipy import linalg

pass_function = ''
no_arguments  = 0
len_vialist   = 0
pass_ranges   = []
pass_vialist  = []
pass_vars     = {}
pass_funcs    = {}
pass_dataset  = []
x_bestfit     = []

yerrors = 0

# FIT_RESIDUAL(): Evaluates the residual between function and dataset

#         x = List of values of via parameters
#      yerr = If True, then errorbars are contained in the n+1 th column of
#             pass_dataset. If False then not.
# yerr_subs = The error bar to assume in the event that data does not have
#             errorbars given.

# The best fitting via parameters are actually independent of the magnitude of
# error bars if all datapoints have a common error, and so the value of
# yerr_subs will not affect the best fit values found, but *does* affect the
# Hessian matrix and consequently the uncertainty in the best fit parameters
# found. Consequently, it is used in hessian_get() above.

def fit_residual(x, yerr=None, yerr_subs=1.0):
  global pass_function, no_arguments, pass_range, pass_vialist, pass_xname, pass_vars, pass_funcs, pass_dataset
  global yerrors

  if (yerr == None): yerr = yerrors

  local_vars  = pass_vars
  for i in range(len(pass_vialist)): # Set via variable values
    local_vars[pass_vialist[i]] = x[i]

  accumulator = 0.0 # Add up sum of square residuals
  for datapoint in pass_dataset:
    eval_string = pass_function+"("
    for i in range(no_arguments):
      eval_string += str(datapoint[i])
      if (i != (no_arguments-1)): eval_string += ","
    eval_string += ")"
    residual    = datapoint[no_arguments] - gp_eval.gp_eval(eval_string,local_vars,pass_funcs)
    if yerr:
      residual = residual / (sqrt(2)*datapoint[no_arguments+1]) # If yerr=True, divide each residual by (sqrt(2)*sigma)
    else:
      residual = residual / (sqrt(2)*yerr_subs                ) # If yerr=False, substitute yerr_subs for standard error
    accumulator = accumulator + pow(residual, 2.0)

  return accumulator # This is the negative of the log probability distribution over x

# HESSIAN_GET(): Function for evaluating the hessian matrix of the probability
# distribution of the via parameters

# x_bestfit = List of values of best fitting via parameters.
#      yerr = If True, then errorbars are contained in the n+1 th column of
#             pass_dataset. If False then not.
# yerr_subs = The error bar to assume in the event that data does not have
#             errorbars given.
#       i,j = The desired component of the Hessian matrix.

def hessian_get(x_bestfit, yerr, yerr_subs, i, j):
  epsilon_i = max(1e-50, abs(x_bestfit[i]/1e-6)) # Stepsize to use in numerical differentiation
  epsilon_j = max(1e-50, abs(x_bestfit[j]/1e-6))
  x_local   = x_bestfit.copy()
  d2L       = 0.0

  # What follows is numerical second differentiation, to find d2L / d[x_i]d[x_j]

  x_local[i] += epsilon_i/2 ; x_local[j] += epsilon_j/2 ; d2L += fit_residual(x_local, yerr, yerr_subs)
  x_local[i] -= epsilon_i                               ; d2L -= fit_residual(x_local, yerr, yerr_subs)
  x_local[j] -= epsilon_j                               ; d2L += fit_residual(x_local, yerr, yerr_subs)
  x_local[i] += epsilon_i                               ; d2L -= fit_residual(x_local, yerr, yerr_subs)
  d2L = d2L / epsilon_i / epsilon_j
  return -d2L # Take negative here because fit_residual returns negative of log P

# SIGMA_LOGP(): This function is minimised whilst we are searching for the
# optimum uncertainty in the supplied data. Effectively, we are trying to
# maximise P(sigma_data) = P(datafile|sigma)*P(sigma) = Evidence*Prior. This is
# marginalised over all of the parameters which we've fitted to the data.
#
# As integrating over all our fitted parameters is computationally intensive,
# we approximate this (see MacKay, D.J.C.M., Neural Computation, 4, 415-447
# (1992)) as P(sigma_data) = P(datafile|x,sigma) * Occam Factor, where the left
# term is the likelihood for the best fit case.
#
# It can be shown that the Occam Factor is proportional to one over the square
# root of the determinant of the Hessian matrix.

def sigma_logP(sigma):
  global x_bestfit, len_vialist, pass_dataset

  if (sigma[0] < 0.0): return float('nan') # Negative errorbars are silly

  # Term1 is the likelihood for the best-fit parameters, without Gaussian normalisation factor
  term1   = -fit_residual(x_bestfit, False, sigma[0])

  # Term2 is the Gaussian normalisation factor
  term2   =  len(pass_dataset) * log( 1.0 / (sqrt(2*pi)*sigma[0]))

  # Term3 is the Occam Factor
  hessian =  scipy.mat([[hessian_get(x_bestfit, yerrors, sigma[0], i, j) for i in range(len_vialist)] for j in range(len_vialist)])
  hessian_det = linalg.det(-hessian)
  assert (hessian_det>=0.0), "Negative Hessian Matrix has negative determinant. This implies negative error bars. The fitting procedure has probably failed."
  term3   =  log(2*pi/sqrt(hessian_det))

  return -(term1+term2+term3) # Proportional to negative of log probability of sigma

# DIRECTIVE_FIT(): Implements the "fit" directive

def directive_fit(line, vars, funcs):
  global pass_function, no_arguments, len_vialist, pass_ranges, pass_vialist, pass_vars, pass_funcs, pass_dataset
  global yerrors, x_bestfit

  # FIRST OF ALL, WE NEED TO READ THE INPUT PARAMETERS FROM THE COMMANDLINE

  # Ranges comes first...
  errorstring = "Syntax Error: syntax of fit command is:\nfit <[min:max][]...> function(x) 'datafile' <using a:b...> <every c:d:e:f:g> <index h> via i,j"
  test = re.match("\s*[A-Za-z]*\s*(.*)",line)
  if (test == None): gp_error(errorstring) ; return
  line = test.group(1)
  while ((len(line) > 0) and (line[0] == "[")):
    test = re.match("""\[([^:\]]*)((:)|( *to *))([^:\]]*)\]\s*(.*)$""",line)
    if (test == None): gp_error("Could not read range in fit command. Use format: [min:max].") ; return # Error
    try:
      pass_ranges.append([ gp_eval.gp_eval(test.group(1),vars,funcs),
                           gp_eval.gp_eval(test.group(5),vars,funcs) ] )
    except KeyboardInterrupt: raise
    except: return
    line = test.group(6)

  # Then function name
  test = re.match("([A-Za-z]\w*)\s*(\(.*)$",line)
  if (test == None): gp_error(errorstring) ; return
  pass_function = test.group(1)
  if not pass_function in funcs: gp_error("Error: fit command requested to fit function '%s'; no such function."%pass_function) ; return
  no_arguments  = funcs[pass_function][0]
  bracketmatch  = gp_eval.gp_bracketmatch(test.group(2),0)
  if (bracketmatch == None): gp_error(errorstring) ; return
  arguments = test.group(2)[1:bracketmatch[-1]].split(",")
  if ((len(arguments) != no_arguments) and (bracketmatch[-1] != 1)):
    gp_error("Error: fit command requested to fit function '%s' with %d arguments, when it is defined to take %d arguments."%(pass_function,len(arguments),funcs[pass_function][0]))
    return
  if ((bracketmatch[-1]+1) < len(test.group(2))): line = test.group(2)[bracketmatch[-1]+1:]
  else                                          : gp_error(errorstring) ; return

  datafile = ''
  usingrowcol = "col"
  using    = ''
  select_criteria = []
  every    = ''
  index    = -1 # GnuPlot API doesn't have an index value for "plot all indices", so I define it to be -1.
  xmin     = 0 ; xmax = 0 ; xrange = 0 # Reset range variables
  ymin     = 0 ; ymax = 0 ; yrange = 0
  vialist  = []
  state    = 0 # 0 = datafile not yet read ; 1 = after datafile read, last word was not keyword ; 2 = using read ; 3 = every read ; 4 = via read

  linelist = line.split()
  for i in range(len(linelist)):
    item = linelist[i].strip()

    if (state < 2):
      if autocomplete(item, "using", 1): state = 2 ; continue
      if autocomplete(item, "every", 1): state = 3 ; continue
      if autocomplete(item, "index", 1): state = 4 ; continue
      if autocomplete(item, "via"  , 1): state = 9 ; continue
      if autocomplete(item, "select",1): state = 11; continue

    if (state == 2): # read 'using' string
      if   autocomplete(item, "columns",3): usingrowcol="col"
      elif autocomplete(item, "rows"   ,3): usingrowcol="row"
      else:
        using = item
        state = 1
      continue

    if (state == 3): # set 'every' setting
      every = item
      state = 1
      continue

    if (state == 4): # set 'index' setting
      try:
        index = int(item)
      except KeyboardInterrupt: raise
      except:
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
        gp_error("'index' keyword should be followed by an integer")
        return # Error
      state = 1
      continue

    if (state == 9): # read via list
      commasplit = gp_eval.gp_split(item,",")
      for var in commasplit:
        var_clean = var.strip()
        test = re.match(r"""^[A-Za-z]\w*$""",var_clean)
        if (test == None):
          gp_error("Illegal variable name '%s' in via. Must contain only alphanumeric characters."%var_clean)
          return
        vialist.append(var_clean)
      continue

    if (state == 11): # read select criterion
      select_criteria.append(item)
      state = 1
      continue

    if ((state == 0) and (item[0] == "'")):
      test = re.match(r"""^'(.*)'$""",item)
      if (test == None):
        gp_error("""Badly formed datafile name "%s"."""%item)
        return # Error
      datafile = test.group(1)
      state = 1
      continue

    gp_error("Syntax Error: Unrecognised word '%s'"%item)
    return # Error


  if (len(using) == 0): # Make up default using string depending upon the number of parameters that our function takes
   for i in range(no_arguments+1): using += str(i+1)+":"
   using = using[:-1]

  # We have now read all of our commandline parameters, and are ready to start fitting
  gp_plot.parse_enderrors(state,0)

  try:
    (rows,columns,datagrid) = gp_datafile.gp_dataread(datafile, index, usingrowcol, using, select_criteria, every, vars, funcs, "points", firsterror=no_arguments+1)[0]
    datagrid_cpy = []
    for datapoint in datagrid:
     for i in range(columns):
      if ((i < len(pass_ranges)) and ((pass_ranges[i][0] > datapoint[i]) or (pass_ranges[i][1] < datapoint[i]))): break
      if (i == (columns-1)): datagrid_cpy.append(datapoint)
  except KeyboardInterrupt: raise
  except:
    gp_error("Error reading input datafile:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  if   (columns <  (no_arguments+1)):
    gp_error("Error: fit command needs %d columns of input data to fit a %d-parameter function."%(no_arguments+1,no_arguments))
    return # Error
  elif (columns == (no_arguments+1)): yerrors = False
  elif (columns == (no_arguments+2)): yerrors = True
  else:
   yerrors = True
   gp_warning("Warning: Too many columns supplied to fit command. Taking 1=first argument, .... , %d=%s(...), %d=errorbar on function output."%(no_arguments+1,pass_function,no_arguments+2))

  pass_vialist = vialist
  len_vialist  = len(vialist)
  pass_vars    = vars.copy()
  pass_funcs   = funcs
  pass_dataset = datagrid

  # Set up a list containing the values of all of the parameters that we're fitting
  x = []
  for i in range(len_vialist):
    if vialist[i] in pass_vars: x.append(pass_vars[vialist[i]]) # Use default value, if we have one
    else                      : x.append(1.0                  ) # otherwise use 1.0 as our starting value

  # Find best fitting parameter values
  try:
    x = fmin(fit_residual, x, disp=0)
    x_bestfit = x
  except KeyboardInterrupt: raise
  except:
    gp_error("Numerical Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Print best fitting parameter values
  try:
    gp_report("\n# Best fit parameters were:")
    gp_report(  "# -------------------------\n")
    for i in range(len_vialist): # Set via variables
      gp_report("%s = %s"%(vialist[i],floatprint(x[i])))
      vars[vialist[i]] = x[i] # Set variables in global scope
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst display best fit values:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Estimate error magnitude in supplied data, if not supplied (this is critical to error in fitted paramters).
  gp_report("\n# Estimated error in supplied data values (based upon misfit to this function fit, assuming uniform error on all datapoints):")
  if not yerrors:
    try:
     sigma_data = fmin(sigma_logP, [1.0], disp=0)
     gp_report(  "sigma_datafile = %s\n"%floatprint(sigma_data))
    except KeyboardInterrupt: raise
    except:
      gp_error("Error whilst estimating the uncertainties in parameter values.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      sigma_data = 1.0
      # Keep going; we may as well print out the Hessian matrix anyway
  else:
    gp_report("# Not calculated, because datafile already contained errorbars on data values.\n")
    sigma_data = 0.0 # sigma_data is the errorbar on the supplied datapoints

  # Calculate and print the Hessian matrix
  try:
    hessian = scipy.mat([[hessian_get(x, yerrors, sigma_data, i, j) for i in range(len_vialist)] for j in range(len_vialist)])
    matrix_print(hessian, vialist, "Hessian matrix of log-probability distribution", "hessian")

    hessian_negative = True
    for i in range(len_vialist):
     for j in range(len_vialist):
      if (hessian[i,j] > 0.0): hessian_negative = False
    if not hessian_negative: gp_warning("\n# *** WARNING: ***\n# Non-negative components in Hessian matrix. This implies that fitting procedure has failed.\n")
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst evaluating Hessian matrix.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Print the Covariance matrix
  try:
    covar = linalg.inv(-hessian) # Covariance matrix = inverse(-H)
    matrix_print(covar, vialist, "Covariance matrix of probability distribution", "covariance")
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst evaluating covariance matrix.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Get the standard errors on each parameter, which are the squareroots of the leading diagonal terms
  try:
    standard_devs = []
    for i in range(len_vialist):
      assert (covar[i,i] >= 0.0), "Negative terms in leading diagonal of covariance matrix imply negative variances in fitted parameters. The fitting procedure has probably failed."
      standard_devs += [sqrt(covar[i,i])]
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst evaluating uncertainties in best fit parameter values.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Print the Correlation matrix
  try:
    for i in range(len_vialist):
     for j in range(len_vialist):
      covar[i,j] = covar[i,j] / standard_devs[i] / standard_devs[j]
    matrix_print(covar, vialist, "Correlation matrix of probability distribution", "correlation")
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst evaluating correlation matrix.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  # Print the standard errors on variables
  try:
    gp_report("\n# Uncertainties in best fit parameter values are:")
    gp_report(  "# -----------------------------------------------\n")
    for i in range(len_vialist):
      gp_report("sigma_%s = %s"%(vialist[i],floatprint(standard_devs[i])))

    # Print final summary
    gp_report("\n# Summary:")
    gp_report(  "# --------\n#")
    for i in range(len_vialist):
      gp_report("# %s = %s +/- %s"%(vialist[i],floatprint(x[i]),floatprint(standard_devs[i])))
  except KeyboardInterrupt: raise
  except:
    gp_error("Error whilst displaying uncertainties in best fit parameter values.\nError:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  return # Done!!!

# FLOATPRINT(): Prints a float in floating point or exponential format, as appropriate

def floatprint(x):
  if ((fabs(x) < 1e10) and (fabs(x) > 1e-6)): return "%f"%x
  else:                                       return "%e"%x

# MATRIX_PRINT(): Display a matrix, using the strings from vialist as column/row headings

def matrix_print(matrix, vialist, longtitle, shorttitle):

  # Print title at top of matrix
  gp_report("\n# %s is:\n# %s\n"%(longtitle, ''.join(['-' for i in range(4+len(longtitle))])))

  # Print list of column headings along the top
  line = "# %6s%3s   "%("","")
  for j in range(len(vialist)): line += "%6s%s "%(vialist[j][:5],['   ','...'][len(vialist[j])>5])
  gp_report(line)

  # Now print each row of the matrix
  for i in range(len(vialist)):
   line = "# %6s%s ( "%(vialist[i][:5],['   ','...'][len(vialist[i])>5]) # Row headings
   for j in range(len(vialist)):
    line += "%9.2e "%matrix[i,j]
   gp_report(line+" )")

  # Now print again in machine-readable format
  gp_report("\n# %s matrix in Python-readable format:\n# ----------------------------------%s\n\n%s = %s\n"%(shorttitle.capitalize(), ''.join(['-' for i in range(len(shorttitle))]), shorttitle, [[matrix[i,j] for j in range(len(vialist))] for i in range(len(vialist))]))
 
