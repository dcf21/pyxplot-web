VERSION='0.5.7'
DATE='26/08/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
