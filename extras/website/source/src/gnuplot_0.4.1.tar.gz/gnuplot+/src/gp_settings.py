# GP_SETTINGS.PY
# Dominic Ford
# 01/05/2006

import os
import sys
import glob
import stat
import ConfigParser

import gp_eval

# Check for settings in configuration files .gnuplot+rc in c.w.d. or user's homespace
config_list = [".gnuplot+rc",  os.path.expanduser("~/.gnuplot+rc")]
config_files = ConfigParser.ConfigParser()
config_files.read(config_list)

# CONFIG_LOOKUP_FOO(): Check for entry [section,option] in configuration file.
# If not found, return default.

def config_lookup_str(section, option, default):
 try   : return config_files.get(section, option)
 except: return default

def config_lookup_float(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return float(value)
 except:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be floating point."%(value, section, option)
  return default

def config_lookup_int(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return int(value)
 except:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be an integer."%(value, section, option)
  return default

def config_lookup_opt(section, option, default, options):
 try   : value = config_files.get(section, option)
 except: return default
 if (value in options): return value
 else:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be one of options %s."%(value, section, option, options)
  return default

# Available options for different data types

datastyles = ['points','lines','linespoint','xerrorbars','yerrorbars','dots']
onoff      = ['ON', 'OFF']
termtypes  = ['X11_singlewindow','X11_multiwindow','eps','png','jpg','gif']
keyposes   = ["TOP RIGHT","TOP MIDDLE","TOP LEFT","MIDDLE RIGHT","MIDDLE MIDDLE","MIDDLE LEFT","BOTTOM RIGHT","BOTTOM MIDDLE","BOTTOM LEFT","BELOW","OUTSIDE"]

# Now set default options

settings_default = {'ORIGINX'        :config_lookup_float('settings','ORIGINX'        ,0.0                          ) ,
                    'ORIGINY'        :config_lookup_float('settings','ORIGINY'        ,0.0                          ) ,
                    'MULTIPLOT'      :config_lookup_opt  ('settings','MULTIPLOT'      ,'OFF'             ,onoff     ) ,
                    'TITLE'          :config_lookup_str  ('settings','TITLE'          ,''                           ) ,
                    'TIT_XOFF'       :config_lookup_float('settings','TIT_XOFF'       ,0.0                          ) , # x offset of title
                    'TIT_YOFF'       :config_lookup_float('settings','TIT_YOFF'       ,0.0                          ) ,
                    'TERMTYPE'       :config_lookup_opt  ('settings','TERMTYPE'       ,'X11_singlewindow',termtypes ) ,
                    'OUTPUT'         :config_lookup_str  ('settings','OUTPUT'         ,'gnuplot.eps'                ) ,
                    'ENHANCED'       :config_lookup_opt  ('settings','ENHANCED'       ,'OFF'             ,onoff     ) , # Enhanced (encapsulated) ps?
                    'LANDSCAPE'      :config_lookup_opt  ('settings','LANDSCAPE'      ,'OFF'             ,onoff     ) , # Landscape noeps postscript?
                    'TERMINVERT'     :config_lookup_opt  ('settings','TERMINVERT'     ,'OFF'             ,onoff     ) , # Inverted colour image output?
                    'TERMTRANSPARENT':config_lookup_opt  ('settings','TERMTRANSPARENT','OFF'             ,onoff     ) , # Image output transparent?
                    'DPI'            :config_lookup_float('settings','DPI'            ,300.0                        ) , # DPI of bitmap graphics output.
                    'WIDTH'          :config_lookup_float('settings','WIDTH'          ,8.0                          ) , # Width of output / cm
                    'ASPECT'         :config_lookup_float('settings','ASPECT'         ,1.0                          ) , # Aspect ratio of plot
                    'AUTOASPECT'     :config_lookup_opt  ('settings','AUTOASPECT'     ,'ON'              ,onoff     ) , # Use PyX default aspect ratio
                    'POINTSIZE'      :config_lookup_float('settings','POINTSIZE'      ,1.0                          ) , # Default pointsize
                    'POINTLINEWIDTH' :config_lookup_float('settings','POINTLINEWIDTH' ,1.0             ) , # Default linewidth used for drawing points
                    'LINEWIDTH'      :config_lookup_float('settings','LINEWIDTH'      ,1.0                          ) , # Default linewidth
                    'DATASTYLE'      :config_lookup_opt  ('settings','DATASTYLE'      ,'points'          ,datastyles) ,
                    'FUNCSTYLE'      :config_lookup_opt  ('settings','FUNCSTYLE'      ,'lines'           ,datastyles) ,
                    'SAMPLES'        :config_lookup_int  ('settings','SAMPLES'        ,250                          ) ,
                    'COLOUR'         :config_lookup_opt  ('settings','COLOUR'         ,'ON'              ,onoff     ) ,
                    'KEY'            :config_lookup_opt  ('settings','KEY'            ,'ON'              ,onoff     ) ,
                    'KEYPOS'         :config_lookup_opt  ('settings','KEYPOS'         ,'TOP RIGHT'       ,keyposes  ) ,
                    'KEY_XOFF'       :config_lookup_float('settings','KEY_XOFF'       ,0.0                          ) ,
                    'KEY_YOFF'       :config_lookup_float('settings','KEY_YOFF'       ,0.0                          ) ,
                    'GRID'           :config_lookup_opt  ('settings','GRID'           ,'OFF'             ,onoff     ) ,
                    'GRIDAXISX'      :config_lookup_int  ('settings','GRIDAXISX'      ,1                            ) ,
                    'GRIDAXISY'      :config_lookup_int  ('settings','GRIDAXISY'      ,1                            ) ,
                    }

default_axis = {'LABEL'    :'',
                'AUTOSCALE':'ON',
                'MIN'      :-10.0,
                'MAX'      : 10.0,
                'LOG'      :'OFF'}

linestyles = {} # User-defined linestyles
arrows     = {} # Arrows superposed on figure
labels     = {} # Text labels

variables  = {'pi':3.1415928} # User-defined variables
functions  = {}               # User-defined functions

# NOW IMPORT FUNCTIONSS FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('functions'):
  try:
    functions[preconfigvar[0]] = preconfigvar[1]
  except:
    print "Warning: Unexpected error importing function %s from configuration file."%(preconfigvar[0])
except ConfigParser.NoSectionError: pass # Ignore if no variables section 


# NOW IMPORT VARIABLES FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('variables'):
  try:
    variables[preconfigvar[0]] = gp_eval.gp_eval(preconfigvar[1], variables, functions)
  except:
    print "Warning: Expression '%s' for variable %s in configuration file could not be evaluated."%(preconfigvar[0],preconfigvar[1])
except ConfigParser.NoSectionError: pass # Ignore if no variables section 

# Now that we have default settings, make copy them into initial settings

settings = settings_default.copy()

# By default, have one of each kind of axis... x1, y1 and z1
axes = {'x':{1:default_axis.copy()},
        'y':{1:default_axis.copy()},
        'z':{1:default_axis.copy()} }

# STORAGE OF DIRECTORY PATHS

# User's cwd, which we store here before setting cwd to a temporary folder for the duration of our activities
cwd = ""

# Make a directory into which we put temporary files
tempdirnumber = 1
file_paths=['foo']
while (len(file_paths) != 0): # Take care not to overright a pre-existing file in /tmp
 tempdirnumber = tempdirnumber + 1
 tempdir = "/tmp/gp+_" + str(os.getpid()) + "_" + str(tempdirnumber)
 file_paths=glob.glob(tempdir)
os.mkdir(tempdir)
if ((not os.path.isdir(tempdir)) or (not (os.stat(tempdir)[stat.ST_UID] == os.getuid()))):
 print "Fatal Error: Security error whilst trying to create temporary directory"
 sys.exit(0)

