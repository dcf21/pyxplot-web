# GP_SETTINGS.PY
# Dominic Ford
# 30/03/2006

settings = {'TITLE':'',
            'TIT_XOFF':0.0,  # x offset of title
            'TIT_YOFF':0.0,
            'TERMTYPE':'X11',
            'OUTPUT':'gnuplot.eps',
            'WIDTH':8,             # Width of output / cm
            'POINTSIZE':1,
            'DATASTYLE':'points',
            'FUNCSTYLE':'lines',
            'SAMPLES':250,
            'COLOUR':'ON',
            'KEY':'ON',
            'KEYPOS':'TOP RIGHT',
            'GRID':'OFF'}

default_axis = {'LABEL':'',
                'AUTOSCALE':'ON',
                'MIN':-10.0,
                'MAX':10.0,
                'LOG':'OFF'}

# By default, have one of each kind of axis... x1, y1 and z1
axes = {'x':{1:default_axis.copy()},
        'y':{1:default_axis.copy()},
        'z':{1:default_axis.copy()} }

linestyles = {} # User-defined linestyles
arrows     = {} # Arrows superposed on figure
labels     = {} # Text labels

variables  = {'pi':3.1415928} # User-defined variables
functions  = {}               # User-defined functions
