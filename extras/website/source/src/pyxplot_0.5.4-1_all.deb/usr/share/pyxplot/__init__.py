#!/usr/bin/python2.4
__import__('pyxplot')
