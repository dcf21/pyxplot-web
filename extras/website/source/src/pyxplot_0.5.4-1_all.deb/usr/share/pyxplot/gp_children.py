# GP_CHILDREN.PY
# Dominic Ford
# 03/07/2006

# Signal handler for calling wait() to eliminate zombies.
# Doesn't use SIGCHLD as this would break os.popen....
# http://twistedmatrix.com/trac/ticket/733
# http://mail.python.org/pipermail/python-dev/2004-November/049987.html

# We use periodic calls instead

import signal
import os

ghostviews      = []
ghostview_pid   = None # pid of any running gv process launched under X11_singlewindow
ghostview_fname = None

def sigchld_handle():
 global ghostviews, ghostview_pid
 for ghostview in ghostviews:
  output = os.waitpid(ghostview, os.WNOHANG)
  if (output != (0,0)):
   ghostviews.remove(ghostview)
   if (ghostview == ghostview_pid): ghostview_pid = None

def massacre_children():
 global ghostviews, ghostview_pid
 for ghostview in ghostviews:
  os.kill(ghostview, signal.SIGTERM)
 sigchld_handle()

def kill_latest():
 global ghostview_pid
 if (ghostview_pid != None):
  os.kill(ghostview_pid, signal.SIGTERM) # Kill previous gv session
 sigchld_handle()
