# GP_AUTOCOMPLETE.PY
# Dominic Ford
# 14/04/2006

# AUTOCOMPLETE(): Return TRUE if input string first word matches the first few letters of test (minimum min letters)

def autocomplete(input, test, min):
  i = 0
  input2 = input.strip() # Strip leading/trailing spaces
  while (i < len(input2)):
    if (i < len(test)):
      if (input2[i].capitalize() != test[i].capitalize()):
        if (input2[i].isspace()): break
        else:                     return (0 == 1) # We hit a character which isn't in test string
    else:
      if (input2[i].isspace()): return (0 == 0)
      else                    : return (0 == 1)
    i=i+1
  if (i >= min): return(0 == 0) # We read > than minimum number of characters before hitting whitespace
  return (0 == 1) # We didn't
