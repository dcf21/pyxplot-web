# GP_PLOT.PY
# Dominic Ford
# 09/09/2006

# Implementation of plot command

import gp_children
import gp_eval
import gp_datafile
import gp_settings
import gp_spline
from gp_autocomplete import *
from gp_error import *
import gp_math
import gp_version

import os
import sys
from math import *
import glob
import operator
import re
from pyx import *

# Stores the number of lines on our graph. PyX gets unhappy when this is zero.
plot_counter = 0     # Used for X11 terminal, to give each plot output an individual name

# Store list of previously plotted items. Used to replot.
plotlist = []
axes_this = { 'x':{}, 'y':{}, 'z':{} } # This is global so that set xlabel commands can influence replotting

# List of items plotted on our multiplot
multiplot_plotdesc  = []
multiplot_plotorder = []
multiplot_text      = []
multiplot_arrows    = []
multiplot_axes      = []   # List of multiplot axes, used for linking axes
replot_focus        = -1

# Passes line/point styles between plotting functions and "with" parser
stylestr  = ""
pointsize = 0
pointtype = 0
linewidth = 0
pointlinewidth = 0
linestyle = 0
plotcolour= "gp_auto"
plotfillcolour = "gp_auto"
linecount = 1 # Counts how many lines have been plotted; used to cycle line styles.
ptcount   = 1 # As above; used to cycle point styles
colourcnt = 1 # As above; used to cycle colours
withstate = 0 # State parameter used when processing input after the word "with"

# Used to count how many lines have gone onto graph. If zero, be careful.... PyX crashes when producing an empty key
successful_plot_operations = {}

# Used to store the last datafile filename, to make the '' shorthand work for plotting one datafile in several ways
last_datafile_filename = ''

# Only warn user once about the using modifier when plotting functions
using_use_warned = False

# COORD_TRANSFORM(): Transform from "first", "second" coord systems, etc, into canvas coordinates

def coord_transform(g, axes, systx, systy, x0, y0):
  g.dolayout()

  axisx = axisy = None
  testx = re.match(r"axis(\d\d*)$",systx)
  testy = re.match(r"axis(\d\d*)$",systy)
  if (testx != None): axisx = int(testx.group(1))
  if (testy != None): axisy = int(testy.group(1))

  # Transform x coordinate
  if   (systx in ['graph', 'screen']):
   x = g.pos(x=axes['x'][1]['MIN_RANGE'],y=1.0,xaxis=axes['x'][    1]['AXIS'],yaxis=axes['y'][1]['AXIS'])[0] + x0
  elif ((systx == "second") and (2 in axes['x'])):
   x = g.pos(x=                       x0,y=1.0,xaxis=axes['x'][    2]['AXIS'],yaxis=axes['y'][1]['AXIS'])[0]
  elif ((testx != None) and (axisx in axes['x'])):
   x = g.pos(x=                       x0,y=1.0,xaxis=axes['x'][axisx]['AXIS'],yaxis=axes['y'][1]['AXIS'])[0]
  else:
   if  (systx != "first") :
    gp_warning("Warning -- attempt to use x axis '%s' when it doesn't exist... reverting to 'first'."%systx)
   x = g.pos(x=                       x0,y=1.0,xaxis=axes['x'][    1]['AXIS'],yaxis=axes['y'][1]['AXIS'])[0]

  # Transform y coordinate
  if   (systy in ['graph', 'screen']):
   y = g.pos(x=1.0,y=axes['y'][1]['MIN_RANGE'],xaxis=axes['x'][1]['AXIS'],yaxis=axes['y'][    1]['AXIS'])[1] + y0
  elif ((systy == "second") and (2 in axes['y'])):
   y = g.pos(x=1.0,y=                       y0,xaxis=axes['x'][1]['AXIS'],yaxis=axes['y'][    2]['AXIS'])[1]
  elif ((testy != None) and (axisy in axes['y'])):
   y = g.pos(x=1.0,y=                       y0,xaxis=axes['x'][1]['AXIS'],yaxis=axes['y'][axisy]['AXIS'])[1]
  else:
   if  (systy != "first"):
    gp_warning("Warning -- attempt to use y axis '%s' when it doesn't exist... reverting to 'first'."%systy)
   y = g.pos(x=1.0,y=                       y0,xaxis=axes['x'][1]['AXIS'],yaxis=axes['y'][    1]['AXIS'])[1]

  return [x,y]

# DIRECTIVE_TEXT(): Handles the 'text' command

def directive_text(line,linestyles,vars,funcs,settings,interactive):
 global multiplot_plotdesc, multiplot_plotorder, multiplot_text, multiplot_arrows, multiplot_axes

 if (settings['MULTIPLOT'] != 'ON'):
  multiplot_plotdesc  = []
  multiplot_plotorder = []
  multiplot_text      = []
  multiplot_arrows    = []
  multiplot_axes      = []

 try:
  test = re.match(r"""\s*\S*\s*(('|").*)""",line)
  [title, aftertitle] = gp_eval.gp_getquotedstring(test.group(1))
  test = re.match(r"""\s*([^\s,]*)\s*,?\s*([^\s,]*)""",aftertitle)
  x_pos = gp_eval.gp_eval(test.group(1),gp_settings.variables,gp_settings.functions)
  y_pos = gp_eval.gp_eval(test.group(2),gp_settings.variables,gp_settings.functions)
 except KeyboardInterrupt: raise
 except:
  gp_error("""Error: syntax of text command is 'text "this is a label" 0.0 , 0.0'""")
  return

 if interactive and (settings['MULTIPLOT'] == 'ON'): gp_report("Text added to multiplot with reference %d"%len(multiplot_text))
 multiplot_text.append([title,x_pos,y_pos,settings.copy(),'OFF'])
 multiplot_plotorder.insert(0,"text")
 try:
  if (settings['DISPLAY'] == "ON"): multiplot_plot(linestyles,vars,funcs,settings)
 except KeyboardInterrupt: raise
 except:
  gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
 return

# DIRECTIVE_ARROW(): Handles the 'arrow' command

def directive_arrow(line,linestyles,vars,funcs,settings,interactive):
 global multiplot_plotdesc, multiplot_plotorder, multiplot_text, multiplot_arrows, multiplot_axes
 
 if (settings['MULTIPLOT'] != 'ON'):
  multiplot_plotdesc  = []
  multiplot_plotorder = []
  multiplot_text      = []
  multiplot_arrows    = []
  multiplot_axes      = []
 
 try:
  gc=r"([^\s,][^\s,]*)" # get coordinate -- matches, e.g. "2*x"
  test = re.match(r"\s*\S*\s*f(r(om?)?)?\s\s*"+gc+"\s*,\s*"+gc+"\s\s*to?\s\s*"+gc+"\s*,\s*"+gc+"\s*(\S*)\s*(.*)""",line)
  if (test == None):
   gp_error("Error reading arrow. Use format: arrow from x, y to x, y")
   return
  x0   = gp_eval.gp_eval(test.group(3),gp_settings.variables,gp_settings.functions,verbose=False)
  y0   = gp_eval.gp_eval(test.group(4),gp_settings.variables,gp_settings.functions,verbose=False)
  x1   = gp_eval.gp_eval(test.group(5),gp_settings.variables,gp_settings.functions,verbose=False)
  y1   = gp_eval.gp_eval(test.group(6),gp_settings.variables,gp_settings.functions,verbose=False)
 except KeyboardInterrupt: raise
 except:
  gp_error("Error reading arrow position:")
  gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  return

 if autocomplete(test.group(7),"with",1):
  withwords = test.group(8).split()
 elif (test.group(7) != ""):
  gp_error("Word '%s' could not be parsed."%test.group(7))
  return
 else:
  withwords = []
 if interactive and (settings['MULTIPLOT'] == 'ON'): gp_report("Arrow added to multiplot with reference %d"%len(multiplot_arrows))
 multiplot_arrows.append([x0,y0,x1,y1,withwords,settings.copy(),'OFF'])
 multiplot_plotorder.insert(0,"arrow")
 try:
  if (settings['DISPLAY'] == "ON"): multiplot_plot(linestyles,vars,funcs,settings)
 except KeyboardInterrupt: raise
 except:
  gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
 return

# DIRECTIVE_PLOT(): Handles the 'plot' command

def directive_plot(line,linestyles,vars,funcs,settings,axes,labels,arrows,replot_stat,interactive):
  global plotlist, axes_this, replot_focus
  global multiplot_plotdesc, multiplot_plotorder, multiplot_text, multiplot_arrows, multiplot_axes

  x_position = settings['ORIGINX']
  y_position = settings['ORIGINY']

  if (settings['MULTIPLOT'] != 'ON'):
   multiplot_plotdesc  = []
   multiplot_plotorder = []
   multiplot_text      = []
   multiplot_arrows    = []
   multiplot_axes      = []

  if (replot_stat == 0):
   plotlist = [] # If not replotting, wipe plot list
  else:
   if (settings['MULTIPLOT'] == 'ON'): # If replotting a multiplot, wipe last graph
    if (len(multiplot_plotdesc) > 0):
     x_position = multiplot_plotdesc[replot_focus][2]['ORIGINX']
     y_position = multiplot_plotdesc[replot_focus][2]['ORIGINY']

  test = re.match(r"^\s*[A-Za-z]*\s*(.*)$",line) # Strip initial "plot" command
  if (test == None):
    gp_error("Syntax Error -- This Should Not Happen!")
    gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return
  line = test.group(1)

  # Now make a local copy of axes, and store it in multiplot_axes
  # We need a copy, because user may change axis ranges in the plot command, overriding settings
  # in gp_settings lists of axes.
  if (replot_stat == 0) or (not 1 in axes_this['x']): # Latter or statement because default values above aren't so good is user types "replot" before "plot"
   axes_this = { 'x':{},'y':{},'z':{} } # Make a local copy of the list 'axes', NB: replot on same axes second time around
   for [direction,axis_list_to] in axes_this.iteritems():
    for [number,axis] in axes[direction].iteritems():
     axis_list_to[number] = {'SETTINGS':axis.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
     # Nones are min/max range of data plotted on each axis and PyX axis

  # Now read range specifications, modifying local copy of axes as required
  # NB: Any ranges that are set go into ['SETTINGS']['MIN/MAX'], not ['MIN_USED'] or ['MAX_USED']
  state     = 0
  while ((len(line) > 0) and (line[0] == '[')):
    if (line[1] == ']'): # Case [] means all x
     state = state + 1
     line = line[2:].strip()
     continue
    test = re.match("""\[([^:\]]*)((:)|( *to *))([^:\]]*)\]\s*(.*)$""",line)
    if (test == None):
      gp_error("Could not read range. Use format: [min:max].")
      return # Error
    else:
      try:
        if ((state%2) == 0): direction='x'
        else               : direction='y'
        number=int(state/2)+1

        # Create axes if they don't already exist; linear autoscaling axes
        if (not number in axes_this[direction]):
         axes_this[direction][number] = {'SETTINGS':gp_settings.default_axis.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}

        if (len(test.group(1).strip()) != 0):
          axes_this[direction][number]['SETTINGS']['MIN'] = gp_eval.gp_eval(test.group(1),vars,funcs) # Setting ranges in the plot command in GnuPlot is *stupid*
        if (len(test.group(5).strip()) != 0):                                                         # Why does it set range for x1y1 axes,
          axes_this[direction][number]['SETTINGS']['MAX'] = gp_eval.gp_eval(test.group(5),vars,funcs) # even when you're plotting on x1y2?
        state = state + 1 ; line = test.group(6) ; continue
      except KeyboardInterrupt: raise
      except:
        return # Error

  # We leave the setting up of the key until a later date
  key = None

  # Split line into comma-separated things to plot
  for item in gp_eval.gp_split(line,","): plotlist.append(item)

  # Add plot to multiplot list (we do this even when not in multiplot mode, in which case the list has just been wiped, and will only have one member)
  if interactive and (settings['MULTIPLOT'] == 'ON') and ((replot_stat == 0) or (multiplot_plotdesc == [])):
   gp_report("Plot added to multiplot with reference %d"%len(multiplot_plotdesc))

  if ((replot_stat != 0) and (len(multiplot_plotdesc) > 0)): # If replotting a multiplot, wipe last graph
   multiplot_plotdesc[replot_focus] = [plotlist,key,settings.copy(),labels.copy(),arrows.copy(),'OFF']
   multiplot_axes    [replot_focus] = None # Fill in this below
  else:
   multiplot_plotdesc.append([plotlist,key,settings.copy(),labels.copy(),arrows.copy(),'OFF'])
   multiplot_axes.append(None) # Fill in this below
   multiplot_plotorder.insert(0,"plot")
   replot_focus = -1
  multiplot_plotdesc[replot_focus][2]['ORIGINX'] = x_position # Reset origin, bearing in mind that we may be replotting something which had been moved
  multiplot_plotdesc[replot_focus][2]['ORIGINY'] = y_position

  # Make a copy of axes_this and add it to multiplot catalogue of graph axes
  # We do a copy here, because 'set xlabel' will modify axes_this, in case we want to do a replot
  # But we don't want it to poke around with our latest multiplot addition (unless we replot that).
  axes_this_cpy = { 'x':{},'y':{},'z':{} }
  for [direction,axis_list_to] in axes_this_cpy.iteritems():
   for [number,axis] in axes_this[direction].iteritems():
    axis_list_to[number] = {'SETTINGS':axis['SETTINGS'].copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
  multiplot_axes[replot_focus] = axes_this_cpy

  # Go ahead and make a canvas and plot everything!
  try:
   if (settings['DISPLAY'] == "ON"): multiplot_plot(linestyles,vars,funcs,settings)
  except KeyboardInterrupt: raise
  except:
   gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  return

# MULTIPLOT_PLOT(): The main plotting engine. Plots whatever is in the current list "multiplot_plotdesc"

def multiplot_plot(linestyles,vars,funcs,settings):
  global plot_counter
  global multiplot_plotdesc, multiplot_text, multiplot_axes
  global successful_plot_operations

  global stylestr, pointsize, pointtype, linewidth, pointlinewidth, linestyle, plotcolour, plotfillcolour
  global withstate

  successful_plot_operations = {} # Make a list of which plots have anything plotted on them.

  if (len(multiplot_plotdesc) < 1):
   nothing_to_plot = 1
   for [x0,y0,x1,y1,arrow_style,Msettings, deleted] in multiplot_arrows:
    if (deleted != "ON"): nothing_to_plot = 0
   for [t,x0,y0,Msettings, deleted] in multiplot_text:
    if (deleted != "ON"): nothing_to_plot = 0
   if (nothing_to_plot == 1):
    gp_warning("Nothing to plot!")
    return

  # Prepare PyX

  if (1 == 1): # attempt to clean up the mess if text runner broke last time it was used
    text.defaulttexrunner.texruns = 0
    text.defaulttexrunner.dvifile = None    
    text.defaulttexrunner.preamblemode = 1
    text.defaulttexrunner.preambles = []
    text.defaulttexrunner.needdvitextboxes = []
    text.defaulttexrunner.textboxesincluded = 0
    text.reset()
  text.set(mode="latex")
  text.texrunner.waitfortex=20 # seconds

  # We make a canvas on which to put our graph.
  # This serves two purposes: first, we can then put our arrows etc on top of gridlines (by default PyX puts them under)
  # secondly, we use it to overlay multiplot plots
  try:
   multiplot_canvas = canvas.canvas()
  except KeyboardInterrupt: raise
  except:
    gp_error("Failed while creating initial drawing canvas:")
    raise

  # Multiplot all of our multiplot items
  # NB, in the following, we do work out axes even for deleted plots, as they may be linkaxesed to.

  # Step 1: For each plot in our multiplot list, we work out the ranges of the data, to decide how to autoscale.
  #         This is achieved with a dry-run of the plotting process.
  for multiplot_number in range(len(multiplot_plotdesc)):
   [Mplotlist, Mkey, Msettings, Mlabels, Marrows, Mdeleted] = multiplot_plotdesc[multiplot_number]
   Maxes_this                                               = multiplot_axes    [multiplot_number]
   any_autoscaling_axes = 0
   for [direction,axis_list] in Maxes_this.iteritems():
    for [number,axis] in axis_list.iteritems():
     axis['MIN_USED'] = axis['SETTINGS']['MIN']
     axis['MAX_USED'] = axis['SETTINGS']['MAX']
     axis['AXIS']     = None
     axis['LINKINFO'] = {}

     if (axis['SETTINGS']['LOG'] == "ON"):
      if (axis['MIN_USED'] != None) and (axis['MIN_USED'] <= 0.0):
       axis['MIN_USED'] = None
       gp_warning("Warning: Log axis %s%d set with range minimum < 0 -- this is impossible, so autoscaling instead."%(direction,number))
      if (axis['MAX_USED'] != None) and (axis['MAX_USED'] <= 0.0):
       axis['MAX_USED'] = None
       gp_warning("Warning: Log axis %s%d set with range maximum < 0 -- this is impossible, so autoscaling instead."%(direction,number))

     if ((axis['MIN_USED'] == None) or (axis['MIN_USED'] == None)):
      any_autoscaling_axes = 1
   # If we have some autoscaling axes on this plot, we need to check out the range of the data, otherwise not.
   if ((any_autoscaling_axes == 1) and (Mdeleted != 'ON')):
    g = None # We have no graph.... yet
    plot_dataset_toplevel(multiplot_number,g,Mplotlist,Msettings,Maxes_this,linestyles,vars,funcs,False)

  # Step 2: Propagate range information from linked axes to their parent axes.
  # Repeat twice, as if plots B and C both link to A, and plot B causes plot A's scale to change, we want to
  # propagate that to any functions which evaluate on rasters over plot C.
  for dummy in [0,1]:
   for multiplot_number in range(len(multiplot_plotdesc)):
    [Mplotlist, Mkey, Msettings, Mlabels, Marrows, Mdeleted] = multiplot_plotdesc[multiplot_number]
    Maxes_this                                               = multiplot_axes    [multiplot_number]
    plot_dataset_makeaxes_multipropagate(multiplot_number, Msettings, Maxes_this, Mdeleted)

  for multiplot_number in range(len(multiplot_plotdesc)):
   [Mplotlist, Mkey, Msettings, Mlabels, Marrows, Mdeleted] = multiplot_plotdesc[multiplot_number]
   Maxes_this                                               = multiplot_axes    [multiplot_number]

  # Now plot everything in order, using multiplot_plotorder to tell us what to plot in front of what
  multiplot_number       = -1
  multiplot_arrow_number = -1
  multiplot_text_number  = -1
  for multiplot_plotorder_n in range(len(multiplot_plotorder)):

    if (multiplot_plotorder[-1-multiplot_plotorder_n] == "plot"): # PLOT A GRAPH
      multiplot_number = multiplot_number + 1
      [Mplotlist, Mkey, Msettings, Mlabels, Marrows, Mdeleted] = multiplot_plotdesc[multiplot_number]
      Maxes_this                                               = multiplot_axes    [multiplot_number]

      # Set up the plot's key
      if (Msettings['KEY'] == "ON"):
        if   (Msettings['KEYPOS'] == "TOP RIGHT"):     [hpos,vpos,hinside,vinside] = [1.0, 1.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "TOP MIDDLE"):    [hpos,vpos,hinside,vinside] = [0.5, 1.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "TOP LEFT"):      [hpos,vpos,hinside,vinside] = [0.0, 1.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "MIDDLE RIGHT"):  [hpos,vpos,hinside,vinside] = [1.0, 0.5 , 1, 1]
        elif (Msettings['KEYPOS'] == "MIDDLE MIDDLE"): [hpos,vpos,hinside,vinside] = [0.5, 0.5 , 1, 1]
        elif (Msettings['KEYPOS'] == "MIDDLE LEFT"):   [hpos,vpos,hinside,vinside] = [0.0, 0.5 , 1, 1]
        elif (Msettings['KEYPOS'] == "BOTTOM RIGHT"):  [hpos,vpos,hinside,vinside] = [1.0, 0.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "BOTTOM MIDDLE"): [hpos,vpos,hinside,vinside] = [0.5, 0.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "BOTTOM LEFT"):   [hpos,vpos,hinside,vinside] = [0.0, 0.0 , 1, 1]
        elif (Msettings['KEYPOS'] == "BELOW"      ):   [hpos,vpos,hinside,vinside] = [0.5, 0.0 , 1, 0]
        elif (Msettings['KEYPOS'] == "OUTSIDE"    ):   [hpos,vpos,hinside,vinside] = [1.0, 1.0 , 0, 1]
        else:
          gp_error("Internal Error: Cannot work out where key is.... defaulting to top-right")
          [hpos,vpos,hinside,vinside] = [1.0, 1.0, 1, 1]

        # Now deal with horizontal and vertical offsets for the key, which are special in "outside" and "below" cases
        if (Msettings['KEYPOS'] == "BELOW"):
          # Count number of x-axes along top of plot, and shift title to be above them all
          number_bottom_axes = 0
          for [number,xaxis] in Maxes_this['x'].iteritems():
            if ((number % 2) == 1): number_bottom_axes = number_bottom_axes + 1
          vdist = 1.90 * number_bottom_axes - 0.25
          hdist = 0.6*unit.v_cm
        elif (Msettings['KEYPOS'] == "OUTSIDE"):
          number_right_axes = 0
          for [number,xaxis] in Maxes_this['y'].iteritems():
            if ((number % 2) == 0): number_right_axes = number_right_axes + 1
          hdist = 0.6*unit.v_cm + 2.00 * number_right_axes - 0.75*(number_right_axes == 1)
          vdist = 0.6*unit.v_cm
        else:
          hdist = 0.6*unit.v_cm
          vdist = 0.6*unit.v_cm

        Mkey = graph.key.key(pos=None,hpos=hpos+settings['KEY_XOFF'],vpos=vpos+settings['KEY_YOFF'],hdist=hdist,vdist=vdist,hinside=hinside,vinside=vinside,columns=settings['KEYCOLUMNS'],textattrs=[text.size(settings['FONTSIZE']),gp_settings.pyx_colours[settings['TEXTCOLOUR']]])
      else:
        Mkey = None
      multiplot_plotdesc[multiplot_number][1] = Mkey

      # Step 3: Make all of our axes which are not linked axes.
      plot_dataset_makeaxes_makenonlink   (Msettings, Maxes_this)
   
      # Step 4: Make all of our axes which are linked axes, linking them to the ones that we've just created.
      plot_dataset_makeaxes_makelinked    (Msettings, Maxes_this)
   
      # Step 5: Clean up any linked axes which possibly went wrong, making normal axes instead.
      # For example: circularly defined linked axes are quite bad.
      plot_dataset_makeaxes_makenonlink   (Msettings, Maxes_this)
   
      # Step 6: Now at last we plot everything up properly!
      g = plot_dataset_makeaxes_setupplot(multiplot_number,Msettings, Mkey, Maxes_this)
      if (Mdeleted != 'ON'): # Don't plot items which have been deleted -- we do make plot object above, to anchor axes which may be linked.
        if (g == None): continue                                                                            # Ooops... *That* didn't really work....
        plot_dataset_toplevel(multiplot_number,g,Mplotlist,Msettings,Maxes_this,linestyles,vars,funcs,True) # Now do plotting proper.
   
        # We now transfer graph onto our multiplot canvas, and draw arrows/labels on top of it as required
        try:
         multiplot_canvas.insert(g)
        except KeyboardInterrupt: raise
        except:
         gp_error("Failed while adding graph to canvas:")
         raise
   
        # Print title of plot, if we have one
        if (len(Msettings['TITLE']) > 0):
          # Count number of x-axes along top of plot, and shift title to be above them all
          number_top_axes = 0
          for [number,xaxis] in Maxes_this['x'].iteritems():
           if ((number % 2) == 0): number_top_axes = number_top_axes + 1
          vertical_pos = g.height + 0.3 + Msettings['TIT_YOFF'] + Msettings['ORIGINY']
          if (number_top_axes > 0): vertical_pos = vertical_pos + 1.1
          if (number_top_axes > 1): vertical_pos = vertical_pos + 1.85 * (number_top_axes - 1)
          horizontal_pos = g.width/2 + Msettings['TIT_XOFF'] + Msettings['ORIGINX']
          try:
           multiplot_canvas.text(horizontal_pos, vertical_pos, Msettings['TITLE'], [text.halign.center, text.valign.bottom, text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]])
          except KeyboardInterrupt: raise
          except:
           gp_error("Error printing title of plot: Incorrect LaTeX possibly?")
           gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
   
        # Print text labels
        try:
          for dummy,(txt,systx,x,systy,y) in Mlabels.iteritems():
            [x,y] = coord_transform(g, Maxes_this, systx, systy, x, y)
            if   (Msettings['TEXTHALIGN'] == 'Centre'): halign = text.halign.center
            elif (Msettings['TEXTHALIGN'] == 'Right' ): halign = text.halign.right
            else                                      : halign = text.halign.left
            if   (Msettings['TEXTVALIGN'] == 'Top'   ): valign = text.valign.top
            elif (Msettings['TEXTVALIGN'] == 'Centre'): valign = text.valign.middle
            else                                      : valign = text.valign.bottom
            multiplot_canvas.text(x, y, txt, [halign,valign,text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]])
        except KeyboardInterrupt: raise
        except:
          gp_error("Error printing labels:")
          gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
   
        # Print arrows
        try:
          for dummy,(systx0,x0,systy0,y0,systx1,x1,systy1,y1,arrow_style) in Marrows.iteritems():
           linestyle  = 1
           plotcolour = "gp_auto"
           linewidth  = settings['LINEWIDTH']
           withstate  = 0
   
           [x0,y0] = coord_transform(g, Maxes_this, systx0, systy0, x0, y0)
           [x1,y1] = coord_transform(g, Maxes_this, systx1, systy1, x1, y1)
           arrow_style_list = [deco.earrow.normal] # Default style is 'head'
           for word in arrow_style:
            if   ((withstate == 0) and autocomplete(word, 'head'   , 1)): arrow_style_list = [deco.earrow]
            elif ((withstate == 0) and autocomplete(word, 'nohead' , 1)): arrow_style_list = []
            elif ((withstate == 0) and autocomplete(word, 'twoway' , 1)): arrow_style_list = [deco.barrow, deco.earrow]
            elif ((withstate == 0) and autocomplete(word, 'twohead', 1)): arrow_style_list = [deco.barrow, deco.earrow]
            else:
             process_with_word(settings, linestyles, word)
           parse_enderrors(7, withstate)
  
           # Arrows which go nowhere don't have a direction, and cause PyX to become unhappy... so revert to 'nohead' style
           if ((x0 == x1) and (y0 == y1)): arrow_style_list = []
 
           if ((settings['COLOUR'] == 'ON') and (plotcolour != "gp_auto")): # Match colour
            colour = gp_settings.pyx_colours[plotcolour]                    # otherwise used specified colour
           else:
            colour = color.grey.black # If monochrome or no specified colour, then set colour to black

           # Set size of arrow head
           arrow_size = unit.v_pt*6*linewidth
           for i in range(len(arrow_style_list)):
            arrow_style_list[i] = arrow_style_list[i](size=arrow_size)

           arrow_style_list.append(gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)])
           arrow_style_list.append(plot_linewidth(linewidth))
           arrow_style_list.append(colour)
           multiplot_canvas.stroke(path.line(x0,y0,x1,y1),arrow_style_list)
        except KeyboardInterrupt: raise
        except:
          gp_error("Error printing arrows:")
          gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

    if (multiplot_plotorder[-1-multiplot_plotorder_n] == "text"): # PRINT MULTIPLOT TEXT LABELS
      multiplot_text_number = multiplot_text_number + 1
      [textstr,x,y,Msettings,deleted] = multiplot_text[multiplot_text_number]
      if (deleted != 'ON'):
       try:
        if   (Msettings['TEXTHALIGN'] == 'Centre'): halign = text.halign.center
        elif (Msettings['TEXTHALIGN'] == 'Right' ): halign = text.halign.right
        else                                      : halign = text.halign.left
        if   (Msettings['TEXTVALIGN'] == 'Top'   ): valign = text.valign.top
        elif (Msettings['TEXTVALIGN'] == 'Centre'): valign = text.valign.middle
        else                                      : valign = text.valign.bottom
        multiplot_canvas.text(x, y, textstr, [halign,valign,text.size(Msettings['FONTSIZE']), gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]])
       except KeyboardInterrupt: raise
       except:
        gp_error("Error printing text label %d: Incorrect LaTeX possibly?"%multiplot_text_number)

    if (multiplot_plotorder[-1-multiplot_plotorder_n] == "arrow"): # PRINT MULTIPLOT ARROWS
      multiplot_arrow_number = multiplot_arrow_number + 1
      [x0,y0,x1,y1,arrow_style,Msettings,deleted] = multiplot_arrows[multiplot_arrow_number]
      try:
       if (deleted != 'ON'):
        linestyle  = 1
        plotcolour = "gp_auto"
        linewidth  = settings['LINEWIDTH']
        withstate  = 0
        arrow_style_list = [deco.earrow.normal] # Default style is 'head'

        for word in arrow_style:
         if   ((withstate == 0) and autocomplete(word, 'head'   , 1)): arrow_style_list = [deco.earrow]
         elif ((withstate == 0) and autocomplete(word, 'nohead' , 1)): arrow_style_list = []
         elif ((withstate == 0) and autocomplete(word, 'twoway' , 1)): arrow_style_list = [deco.barrow, deco.earrow]
         elif ((withstate == 0) and autocomplete(word, 'twohead', 1)): arrow_style_list = [deco.barrow, deco.earrow]
         else:
          process_with_word(settings, linestyles, word)
        parse_enderrors(7, withstate)

        # Arrows which go nowhere don't have a direction, and cause PyX to become unhappy... so revert to 'nohead' style
        if ((x0 == x1) and (y0 == y1)): arrow_style_list = []

        if ((settings['COLOUR'] == 'ON') and (plotcolour != "gp_auto")): # Match colour
         colour = gp_settings.pyx_colours[plotcolour]                    # otherwise used specified colour
        else:
         colour = color.grey.black # If monochrome or no specified colour, then set colour to black

        # Set size of arrow head
        arrow_size = unit.v_pt*6*linewidth
        for i in range(len(arrow_style_list)):
         arrow_style_list[i] = arrow_style_list[i](size=arrow_size)

        arrow_style_list.append(gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)])
        arrow_style_list.append(plot_linewidth(linewidth))
        arrow_style_list.append(colour)
        multiplot_canvas.stroke(path.line(x0,y0,x1,y1),arrow_style_list)
      except KeyboardInterrupt: raise
      except:
       gp_error("Error printing arrows:")
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

  # Output plot
  try:
   file_paths=['foo']
   while (len(file_paths) != 0): # Take care not to overright a pre-existing file in /tmp
    plot_counter = plot_counter + 1
    fname = "gp+_" + str(os.getpid()) + "_" + str(plot_counter) + ".eps"
    file_paths=glob.glob(fname+"*")
   multiplot_canvas.writeEPSfile(fname)
   if (settings['LANDSCAPE'] == 'ON'): # Use ghostscript to rotate image through 90 degrees in landscape mode
    # Get old bounding box
    os.system("cat %s | grep '%%BoundingBox:' > %s.bbold"%(fname,fname))
    bbox_fix = open("%s.bbold"%(fname),"r")
    bbox_old = bbox_fix.readline()
    bbox_fix.close()
    test = re.match(r"%%BoundingBox:\s*(\S*)\s*(\S*)\s*(\S*)\s*(\S*)",bbox_old)
    bbox_old = [float(test.group(1)),float(test.group(2)),float(test.group(3)),float(test.group(4))]

    rotate_in = open("%s"%(fname),"r")
    rotate_out= open("%s2"%(fname),"w")
    state=0
    for line in rotate_in.readlines():
     if ((state == 0) and (len(line.strip()) > 0) and (line.strip()[0] != '%')):
      rotate_out.write("%d %d translate\n-90 rotate\n"%(-bbox_old[1],bbox_old[2])) # Translate postscript so that origin is in bottom left, then rotate
      state=1
     rotate_out.write(line)
    rotate_in.close() ; rotate_out.close()
    os.system("gs -sDEVICE=bbox -dBATCH -dNOPAUSE -q %s2 &> %s.bbnew"%(fname,fname)) # Now fix bounding box... measure bbox of new postscript
    bbox_fix = open("%s.bbnew"%(fname),"r")
    bbfix_in = open("%s2"%(fname),"r")
    bbfix_out= open("%s3"%(fname),"w")
    for line in bbfix_in.readlines():
     test = re.match("%%BoundingBox:",line)
     test2= re.match("%%HiResBoundingBox:",line)
     if (test == None):
      if (test2 == None): bbfix_out.write(line)
     else:
      bbfix_out.write(bbox_fix.read())
    bbox_fix.close() ; bbfix_in.close() ; bbfix_out.close()
    fname = "%s3"%(fname)
  except KeyboardInterrupt: raise
  except:
   gp_error("Failed while producing eps output:")
   raise

  if (settings['TERMTYPE'][0:3] == "X11"):               # X11_singlewindow / X11_multiwindow
   if ((settings['TERMTYPE'] == "X11_singlewindow") and (gp_children.ghostview_pid != None)): # Use previously existing gv session, if it exists
     os.system("cp -f %s %s"%(fname, gp_children.ghostview_fname))
   else:
    if (gp_version.GHOSTVIEW == '/bin/false'):
     gp_warning("Warning: An attempt is being made to use X11 terminal for output, but the required package 'ghostview' could not be found when PyXPlot was installed, and so this will fail.")
    fork = os.fork()
    if (fork != 0):
     gp_children.ghostviews.append(fork)
     if (settings['TERMTYPE'] == "X11_singlewindow"):
      gp_children.ghostview_pid   = fork
      gp_children.ghostview_fname = fname
    else:
     stderr_new = open("/dev/null","w")
     os.dup2(stderr_new.fileno(), sys.stderr.fileno()) # Stop ghostview from spamming terminal
     os.execlp(gp_version.GHOSTVIEW, gp_version.GHOSTVIEW, '--watch', fname)
     os._exit(0)
  elif (settings['TERMTYPE'] == "PS"):                   # PS output
   fname_out = os.path.expanduser(settings['OUTPUT'])
   if (settings['BACKUP'] == "ON"): backup = " --backup=existing "
   else                           : backup = " --backup=off "
   if (settings['ENHANCED'] == 'OFF'):
    epstops(fname) # If producing printable postscript, do so now
    if (fname_out == ""): fname_out = "pyxplot.ps"
   else:
    if (fname_out == ""): fname_out = "pyxplot.eps"
   os.system("mv %s %s %s"%(backup,fname,os.path.join(gp_settings.cwd, fname_out)))
  elif (settings['TERMTYPE'] == "PNG"):                  # PNG output
   fname_out = os.path.expanduser(settings['OUTPUT'])
   if (settings['BACKUP'] == "ON"): backup = " --backup=existing "
   else                           : backup = " --backup=off "
   if (fname_out == ""): fname_out = "pyxplot.png"
   command = "convert -density %f -quality 100 "%settings['DPI']
   if (settings['TERMINVERT'] == "ON"): command = command + "-negate "
   if (settings['TERMTRANSPARENT'] == "ON"):
    if (settings['TERMINVERT'] == "ON"): command = command + "-transparent black +antialias "
    else                               : command = command + "-transparent white +antialias "
   command = command + "%s %s.png"%(fname,fname)
   os.system(command)
   os.system("mv %s %s.png %s"%(backup,fname,os.path.join(gp_settings.cwd, fname_out)))
  elif (settings['TERMTYPE'] == "GIF"):                  # GIF output
   fname_out = os.path.expanduser(settings['OUTPUT'])
   if (settings['BACKUP'] == "ON"): backup = " --backup=existing "
   else                           : backup = " --backup=off "
   if (fname_out == ""): fname_out = "pyxplot.gif"
   command = "convert -density %f -quality 100 "%settings['DPI']
   if (settings['TERMINVERT'] == "ON"): command = command + "-negate "
   if (settings['TERMTRANSPARENT'] == "ON"): 
    if (settings['TERMINVERT'] == "ON"): command = command + "-transparent black +antialias "
    else                               : command = command + "-transparent white +antialias "
   command = command + "%s %s.gif"%(fname,fname)
   os.system(command)
   os.system("mv %s %s.gif %s"%(backup,fname,os.path.join(gp_settings.cwd, fname_out)))
  elif (settings['TERMTYPE'] == "JPG"):                  # JPG output
   fname_out = os.path.expanduser(settings['OUTPUT'])
   if (settings['BACKUP'] == "ON"): backup = " --backup=existing "
   else                           : backup = " --backup=off "
   if (fname_out == ""): fname_out = "pyxplot.jpg"
   command = "convert -density %f -quality 100 "%settings['DPI']
   if (settings['TERMINVERT'] == "ON"): command = command + "-negate "
   command = command + "%s %s.jpg"%(fname,fname)
   os.system(command)
   os.system("mv %s %s.jpg %s"%(backup,fname,os.path.join(gp_settings.cwd, fname_out)))

# PLOT_DATASET_MAKEAXES__________(): Makes axes for a plot, using the ranges which have been found from 

# PLOT_DATASET_MAKEAXES_MULTIPROPAGATE(): Propagate information from linked axes to parent Re range
def plot_dataset_makeaxes_multipropagate(multiplot_number, Msettings, Maxes_this, Mdeleted):
 for [direction, axis_list] in Maxes_this.iteritems():
  if (direction != 'z'): # 2D plots don't have z axes
   for [number,axis] in axis_list.iteritems():

    # Make some basic information about this axis
    if (number == 1): axisname = direction             # x1 axis is called x in PyX
    else            : axisname = direction+str(number) # but x2 axis is called x2 in PyX

    # PyX 0.9 doesn't like having x5 axis without an x3, so we form a numbering system for PyX
    pyx_number = pyx_oddeven = number%2
    if (pyx_number == 0): pyx_number = 2
    for [n2,a2] in axis_list.iteritems():
      if ((n2 < number) and (n2%2 == pyx_oddeven)): pyx_number = pyx_number + 2
    if (pyx_number == 1): axispyxname = direction
    else                : axispyxname = direction+str(pyx_number)

    linkaxis      = 'OFF'
    linkaxis_plot = None
    linkaxis_no   = None

    # Test to see whether it is a linked axis
    test = re.match(r"""linkaxis\s\s*(\d\d*)(\s*,?\s*)(\d*)""", axis['SETTINGS']['LABEL'])  
    if (test != None):
     if (Msettings['MULTIPLOT'] != 'ON'):
      gp_warning("Warning: apparent attempt to create a linked axis when not in multiplot mode... doomed to fail!")
     else:
      try:
       linkaxis_plot = int(test.group(1))
       if (len(test.group(2)) == 0): linkaxis_no = 1
       else                        : linkaxis_no = int(test.group(3))
       if (linkaxis_plot >= len(multiplot_axes)):
        gp_warning("Warning: attempt to create a linked axis to a non-existant plot: %s"%axis['SETTINGS']['LABEL'])
       elif (linkaxis_plot >= multiplot_number):
        gp_warning("Warning: attempt to create a linked axis from plot %d to plot %d; linked axes must link to an earlier plot."%(multiplot_number, linkaxis_plot))
       elif (not linkaxis_no in multiplot_axes[linkaxis_plot][direction]):
        gp_warning("Warning: attempt to create a linked axis to %s-axis number %d of plot %d, but this plot has no such axis:\n%s"%(direction,linkaxis_no,linkaxis_plot,axis['SETTINGS']['LABEL']))
       else:
        linkaxis = 'ON'
        # Propagate range information from linked axis to parent axis
        # But only if we're not deleted
        if (axis['MIN_USED'] != None) and ((axis['MIN_USED'] < multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MIN_USED']) or (multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MIN_USED'] == None)) and ((multiplot_axes[linkaxis_plot][direction][linkaxis_no]['SETTINGS']['LOG'] != "ON") or (axis['MIN_USED'] > 0.0)):
         if (Mdeleted != 'ON'): multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MIN_USED'] = axis['MIN_USED']
        else:
         axis['MIN_USED'] = multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MIN_USED']
        if (axis['MAX_USED'] != None) and (axis['MAX_USED'] > multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MAX_USED']):
         if (Mdeleted != 'ON'): multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MAX_USED'] = axis['MAX_USED']
        else:
         axis['MAX_USED'] = multiplot_axes[linkaxis_plot][direction][linkaxis_no]['MAX_USED']
      except KeyboardInterrupt: raise
      except:
       gp_error("Error whilst reading linkaxis command: %s"%axis['SETTINGS']['LABEL'])
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")

    # Store information about our linkage status
    axis['LINKINFO']={'LINKED':linkaxis, 'PLOT':linkaxis_plot, 'AXISNO': linkaxis_no, 'AXISNAME':axisname, 'AXISPYXNAME':axispyxname}

# PLOT_DATASET_MAKEAXES_MAKENONLINK(): Make axes which are not linked axes
def plot_dataset_makeaxes_makenonlink(Msettings, Maxes_this):
 for [direction, axis_list] in Maxes_this.iteritems():
  if (direction != 'z'): # 2D plots don't have z axes
   for [number,axis] in axis_list.iteritems():
    if ((axis['LINKINFO']['LINKED'] != 'ON') and (axis["AXIS"] == None)):

     axisname = axis['LINKINFO']['AXISNAME']
     if (axis['SETTINGS']['LOG'] != "ON"): axistype = graph.axis.linear
     else                                : axistype = graph.axis.log

     # If no data on axis, make up a default range
     if (axis['MIN_USED'] == None):
      if (axis['SETTINGS']['LOG'] == 'ON'):
       if (axis['MAX_USED'] != None): axis['MIN_USED'] = axis['MAX_USED'] / 100 # Log axes start from 1
       else                         : axis['MIN_USED'] = 1.0
      else:
       if (axis['MAX_USED'] != None): axis['MIN_USED'] = axis['MAX_USED'] - 20
       else                         : axis['MIN_USED'] = -10.0                  # Lin axes start from -10

     if (axis['MAX_USED'] == None):
      if (axis['SETTINGS']['LOG'] == 'ON'): axis['MAX_USED'] = axis['MIN_USED'] * 100
      else                                : axis['MAX_USED'] = axis['MIN_USED'] + 20

     # If there's no spread of data on the axis, make a spread up
     # We do this even if range is set by user, as it's a stupid thing to do, otherwise.
     if (axis['MAX_USED'] == axis['MIN_USED']):
      axis['MIN_USED'] = axis['MIN_USED'] - 1.0
      axis['MAX_USED'] = axis['MAX_USED'] + 1.0
      if (axis['SETTINGS']['LOG'] == "ON"):
       axis['MIN_USED'] = max(axis['MIN_USED'],1e-300)
       axis['MAX_USED'] = max(axis['MAX_USED'],1e-300)

     # NB: This code may be executed, even if above conditional is not, as MIN_USED and MAX_USED may have been fixed
     # when making raster to plot a function
     if ((axis['SETTINGS']['MIN'] != None) and (axis['SETTINGS']['MIN'] == axis['SETTINGS']['MAX'])):
      gp_warning("Warning: %s-axis set to have minimum and maximum equal; this is probably not sensible."%axisname)
      gp_warning("         Reverting to alternative limits.")

     # Log axes going below zero is *bad* -- protect against it
     if (axis['SETTINGS']['LOG'] == "ON"):
      if (axis['MIN_USED'] <= 0.0):
       axis['MIN_USED'] = 1e-6
       gp_warning("Warning: Log axis %s set with range minimum < 0 -- this is impossible. Reverting to 1e-6 instead."%axisname)
       gp_warning("This should not have happened. Please report as a PyXPlot bug.")
      if (axis['MAX_USED'] <= 0.0):
       axis['MAX_USED'] = 1.0
       gp_warning("Warning: Log axis %s set with range maximum < 0 -- this is impossible. Reverting to 1.0 instead."%axisname)
       gp_warning("This should not have happened. Please report as a PyXPlot bug.")

     # Autoscaled axes scale outwards to nearest round number, which we do now
     axis_min = minprelim = axis['MIN_USED']
     axis_max = maxprelim = axis['MAX_USED']

     if (axis['SETTINGS']['LOG'] == "ON"):
      minprelim = log10(minprelim)
      maxprelim = log10(maxprelim)

     try:
      OoM = pow(10.0, floor(log10(fabs(maxprelim - minprelim))))
      minauto = floor(minprelim / OoM) * OoM
      maxauto = ceil (maxprelim / OoM) * OoM
     except KeyboardInterrupt: raise
     except:
      gp_error("Error whilst working out range of axis %s:"%axisname)
      gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      minauto = 1 ; maxauto = 10 # Do anything we can to rescue the situation!

     if (axis['SETTINGS']['LOG'] == "ON"):
      minauto = max(pow(10.0,minauto),1e-300) # Just in case of numerical roundoff issues
      maxauto = max(pow(10.0,maxauto),1e-300)

     if (axis['SETTINGS']['MIN'] == None): axis_min = minauto # Honour hard-coded ranges, otherwise use autoranges
     if (axis['SETTINGS']['MAX'] == None): axis_max = maxauto

     axis['MIN_RANGE'] = axis_min ; axis['MAX_RANGE'] = axis_max

     if ((Msettings['GRID'] == 'ON') and (number in Msettings['GRIDAXIS%s'%direction.capitalize()])): 
      gridalloc = [attr.changelist([gp_settings.pyx_colours[Msettings['GRIDMAJCOLOUR']],
                                    gp_settings.pyx_colours[Msettings['GRIDMINCOLOUR']] ])] # Make gridlines only on specified x/y axes
     else:
      gridalloc = None

     # Now make axis
     try:
      lab = axis['SETTINGS']['LABEL']
      innerticklength = outerticklength = None
      if (axis['SETTINGS']['TICDIR'] in ['INWARD' ,'BOTH']): innerticklength = graph.axis.painter.ticklength.normal
      if (axis['SETTINGS']['TICDIR'] in ['OUTWARD','BOTH']): outerticklength = graph.axis.painter.ticklength.normal
      if (lab[:8] == "nolabels") and ((len(lab)==8) or (lab[8]==":")):
       axis["AXIS"] = axistype(title=lab[9:],min=axis_min,max=axis_max,painter=graph.axis.painter.regular(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],labelattrs=None,gridattrs=gridalloc))
      elif (lab[:12] == "nolabelstics") and ((len(lab)==12) or (lab[12]==":")):
       axis["AXIS"] = axistype(title=lab[13:],min=axis_min,max=axis_max,painter=graph.axis.painter.regular(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=None,labelattrs=None,gridattrs=gridalloc))
      elif (lab[:9] == "invisible") and ((len(lab)==9) or (lab[9]==":")):
       axis["AXIS"] = axistype(title=lab[10:],min=axis_min,max=axis_max,painter=graph.axis.painter.regular(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=None,tickattrs=None,labelattrs=None,gridattrs=gridalloc))
      else:
       axis["AXIS"] = axistype(title=axis['SETTINGS']['LABEL'],min=axis_min,max=axis_max,painter=graph.axis.painter.regular(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],labelattrs=[text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]],titleattrs=[text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]],gridattrs=gridalloc))
     except KeyboardInterrupt: raise
     except:
      gp_error("Error whilst making axis %s -- probably its range is too big:")
      gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
     else:   continue

     # Do our best to rescue a broken situation... by setting range of axis to 1 -> 10.
     try:
      axis_min = 1 ; axis_max = 10
      axis["AXIS"] = axistype(title=axis['SETTINGS']['LABEL'],min=axis_min,max=axis_max,painter=graph.axis.painter.regular(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],labelattrs=[text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]],titleattrs=[text.size(Msettings['FONTSIZE']),gp_settings.pyx_colours[Msettings['TEXTCOLOUR']]],gridattrs=gridalloc))
     except KeyboardInterrupt: raise
     except:
      gp_error("Attempt to rectify broken axis %s also failed:")
      gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
     continue

# PLOT_DATASET_MAKEAXES_MAKELINKED(): Try to make linked axes
def plot_dataset_makeaxes_makelinked(Msettings, Maxes_this):
 for [direction, axis_list] in Maxes_this.iteritems():
  if (direction != 'z'): # 2D plots don't have z axes
   for [number,axis] in axis_list.iteritems():
    if ((axis["AXIS"] == None) and (axis['LINKINFO']['PLOT'] != None) and (axis['LINKINFO']['AXISNO'] != None)):
     axis['LINKINFO']['LINKED'] = 'OFF' # Unset linked axis flag, in case we encounter a problem and this axis needs cleaning up later
     linkaxis_plot = axis['LINKINFO']['PLOT']
     linkaxis_no   = axis['LINKINFO']['AXISNO']

     if (multiplot_axes[linkaxis_plot][direction][linkaxis_no]["AXIS"] != None):
      if ((Msettings['GRID'] == 'ON') and (number in Msettings['GRIDAXIS%s'%direction.capitalize()])):
       gridalloc = [attr.changelist([gp_settings.pyx_colours[Msettings['GRIDMAJCOLOUR']],
                                     gp_settings.pyx_colours[Msettings['GRIDMINCOLOUR']] ])] # Make gridlines only on specified x/y axes
      else:
       gridalloc = None
      innerticklength = outerticklength = None
      if (axis['SETTINGS']['TICDIR'] in ['INWARD' ,'BOTH']): innerticklength = graph.axis.painter.ticklength.normal
      if (axis['SETTINGS']['TICDIR'] in ['OUTWARD','BOTH']): outerticklength = graph.axis.painter.ticklength.normal
      axis["AXIS"] = graph.axis.linkedaxis(multiplot_axes[linkaxis_plot][direction][linkaxis_no]["AXIS"],painter=graph.axis.painter.linked(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],gridattrs=gridalloc))
      # We make another spare linked axis to use on x2 axis if required (it seems that linked axes cannot be reused...)
      axis["AXIS_SPARE"] = graph.axis.linkedaxis(multiplot_axes[linkaxis_plot][direction][linkaxis_no]["AXIS"],painter=graph.axis.painter.linked(innerticklength=innerticklength,outerticklength=outerticklength,basepathattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],tickattrs=[gp_settings.pyx_colours[Msettings['AXESCOLOUR']]],gridattrs=gridalloc))
      if (axis["AXIS"] != None): axis['LINKINFO']['LINKED'] = 'ON' # Linked axis successfully made, there will be no need to clean up.
     else:
      gp_error("Error: cannot link axis to another link axis!")

# PLOT_DATASET_MAKEAXES_SETUPPLOT(): Make graph object, using all of the axes that we have just assigned
def plot_dataset_makeaxes_setupplot(multiplot_number, Msettings, Mkey, Maxes_this):

 axisassign = "" # String listing all of the axes to put onto our plot

 if (Msettings['AUTOASPECT'] == 'ON'):
  ratioassign=""
 else:
  ratioassign="ratio=%f,"%(1.0/Msettings['ASPECT'])
 if (not multiplot_number in successful_plot_operations): Mkey = None # Don't put a key on a plot with no datasets... PyX crashes!

 for [direction, axis_list] in Maxes_this.iteritems():  # Populate axisassign with a list of all axes
  hadaxistwo = False # If user hasn't made a second axis, we manually make one here; allows us to colour it as we wish
  if (direction != 'z'): # 2D plots don't have z axes 
   for [number,axis] in axis_list.iteritems():
    if (axis['LINKINFO']['AXISPYXNAME'] == direction+"2"): hadaxistwo = True
    axisassign = axisassign + axis['LINKINFO']['AXISPYXNAME'] + "=Maxes_this['"+direction+"']["+str(number)+"]['AXIS'],"
   if not hadaxistwo:
    if (axis_list[1]['LINKINFO']['LINKED'] != "ON"): # If axis 1 is not linked, we need to make a copy of it without labels
     if (axis_list[1]['SETTINGS']['LOG'] != "ON"): axistype = 'graph.axis.linear'
     else                                        : axistype = 'graph.axis.log'
     innerticklength = outerticklength = "None"
     if (axis['SETTINGS']['TICDIR'] in ['INWARD' ,'BOTH']): innerticklength = "graph.axis.painter.ticklength.normal"
     if (axis['SETTINGS']['TICDIR'] in ['OUTWARD','BOTH']): outerticklength = "graph.axis.painter.ticklength.normal"
     axisassign = axisassign + direction+"2=%s(min=%s,max=%s,painter=graph.axis.painter.regular(innerticklength=%s,outerticklength=%s,basepathattrs=[gp_settings.pyx_colours['%s']],tickattrs=[gp_settings.pyx_colours['%s']],labelattrs=None,titleattrs=None)),"%(axistype,axis_list[1]['MIN_RANGE'],axis_list[1]['MAX_RANGE'],innerticklength,outerticklength,Msettings['AXESCOLOUR'],Msettings['AXESCOLOUR'])
    else:
     axisassign = axisassign + direction+"2=Maxes_this['"+direction+"'][1]['AXIS_SPARE']," # If axis 1 is linked, just use the spare linked axis

 exec "g = graph.graphxy(width=Msettings['WIDTH'],"+ratioassign+axisassign+"key=Mkey,xpos=%f,ypos=%f)"%(Msettings['ORIGINX'],Msettings['ORIGINY'])
 if (g == None):
   gp_error("Internal error: Failed to produce graph object in PyX.")
 else:
   for [direction, axis_list] in Maxes_this.iteritems():  # Keep a copy of this axis as specific to this particular plot -- a PyX 0.8.1 thing
    if (direction != 'z'): # 2D plots don't have z axes 
     for [number,axis] in axis_list.iteritems():
      axis["AXIS"] = g.axes[axis['LINKINFO']['AXISPYXNAME']]

 return g

# PLOT_DATASET_TOPLEVEL():

def plot_dataset_toplevel(multiplot_number,g,Mplotlist,Msettings,Maxes_this,linestyles,vars,funcs,plotting):
  global linecount, ptcount, colourcnt

  # Counts number of lines/pointsets plotted, so that we can cycle styles
  verb_errors = plotting
  colourcnt = 1
  linecount = 1
  ptcount   = 1

  # If we plotting, rather than doing a dry-run, just plot everything here and now
  if plotting:
   for plotitem in Mplotlist:
    plotwords = plotitem.strip().split()
    if (len(plotwords) > 0):
     try:
      if (plotwords[0][0] in ["'",'"']):
       plot_datafile(multiplot_number,g,Maxes_this,Msettings,linestyles,plotwords,vars,funcs,plotting,verb_errors)
      else:
       plot_function(multiplot_number,g,Maxes_this,Msettings,linestyles,plotwords,vars,funcs,plotting,verb_errors)
     except KeyboardInterrupt: raise
     except:
      if (verb_errors): gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
   return

  # Plot datafiles first, to get an idea of the range of the x-axis
  for plotitem in Mplotlist:
   plotwords = plotitem.strip().split()
   if ((len(plotwords) > 0) and (    plotwords[0][0] in ["'",'"'])):
    try:
     plot_datafile(multiplot_number,g,Maxes_this,Msettings,linestyles,plotwords,vars,funcs,plotting,verb_errors)
    except KeyboardInterrupt: raise
    except: pass

  # Plot functions second, sampling them over the range that we have now determined
  for plotitem in Mplotlist:
   plotwords = plotitem.strip().split()
   if ((len(plotwords) > 0) and (not plotwords[0][0] in ["'",'"'])):
    try:
     plot_function(multiplot_number,g,Maxes_this,Msettings,linestyles,plotwords,vars,funcs,plotting,verb_errors)
    except KeyboardInterrupt: raise
    except: pass

# PLOT_DATAFILE(): Plot datapoints listed in datafile
def plot_datafile(multiplot_number,g,axes,settings,linestyles,plotwords,vars,funcs,plotting,verb_errors):
  global stylestr, pointsize, pointtype, linewidth, pointlinewidth, linestyle, plotcolour, plotfillcolour
  global withstate, last_datafile_filename

  datafile = ''
  axis_x   = 1
  axis_y   = 1
  using    = ''
  select_criteria = []
  usingrowcol = "col"
  every    = ''
  index    = -1 # GnuPlot API doesn't have an index value for "plot all indices", so I define it to be -1.
  title    = None
  quotetype= ''
  state    = 0
  stylestr = settings['DATASTYLE']
  pointsize= settings['POINTSIZE']
  pointtype  = -1
  linestyle  = -1
  plotcolour = "gp_auto"
  plotfillcolour = "gp_auto"
  linewidth  = settings['LINEWIDTH']
  pointlinewidth = settings['POINTLINEWIDTH']
  withstate  = 0

  autotitle = '' # The title the user will get if he doesn't specify one of his own

  for i in range(len(plotwords)):
   item = plotwords[i].strip()
   repeat = True
   while repeat:
    repeat = False
    if (len(item) == 0): continue # Ignore blank words

    if (state == 0): # Get datafilename
     if (len(datafile) == 0):
      test = re.match(r"""^('|")(.*)$""",item)
      if (test == None):
       if (verb_errors): gp_error("Error: filename must be in quotes")
       return
      quotetype = test.group(1)
      item = test.group(2)
     test = re.match("(.*)%s(.*)$"%quotetype,item)
     if (test == None):
      datafile += item + " "
     else:
      datafile += test.group(1)
      item = test.group(2)
      state = 1
      repeat = True
     continue

    if ((state != 7) and (not autocomplete(item, "with",1))): autotitle = autotitle + item + " " # Do not add filename to autotitle; we do this after globbing.

    if (state < 2):
     if autocomplete(item, "using"  ,1): state = 2 ; continue
     if autocomplete(item, "every"  ,1): state = 3 ; continue
     if autocomplete(item, "index"  ,1): state = 4 ; continue
     if autocomplete(item, "notitle",3): title = ''; continue
     if autocomplete(item, "title"  ,1): state = 5 ; continue # also uses state 6
     if autocomplete(item, "with"   ,1): state = 7 ; continue
     if autocomplete(item, "axes"   ,1): state = 8 ; continue
     if autocomplete(item, "select" ,1): state = 11; continue

    if (state == 4): # set 'index' setting
      try:
        index = int(item)
      except KeyboardInterrupt: raise
      except: 
        gp_error("'index' keyword should be followed by an integer")
        raise
      state = 1
      continue

    if (state == 3): # set 'every' setting
      every = item
      state = 1
      continue

    if (state == 2): # read 'using' string
      if   autocomplete(item, "columns",3): usingrowcol="col"
      elif autocomplete(item, "rows"   ,3): usingrowcol="row"
      else:
        using = item
        state = 1
      continue

    if (state == 5): # read 'title' string
      test = re.match(r"""^(('|").*)$""",item)
      if (test == None): raise SyntaxError, "Title must be in quotes"
      item = test.group(1)
      title = ""
      state = 6
    if (state == 6): # Multiple word titles supported
      title += item + " "
      [text, aftertext] = gp_eval.gp_getquotedstring(title)
      if (text != None):
        title = text
        state = 1 # We have hit a closing quote
        item = aftertext.strip()
        if (len(item) > 0): repeat = True
      continue

    if (state == 7): # read 'with' clauses
      process_with_word(settings, linestyles, item, verb_errors)
      continue

    if (state == 8): # read axes string
      test = re.match(r"""^x(\d\d*)y(\d\d*)$""",item)
      if (test == None): raise SyntaxError, "Axes declaration must take the form x<n>y<m>"
      axis_x = int(test.group(1))
      axis_y = int(test.group(2))
      if ((axis_x < 1) or (axis_y < 1)): raise ValueError, "Axes declaration must take the form x<n>y<m> where {n,m}>0."  # Don't allow user to use axis zero!
      if (not axis_x in axes['x']):
       axes['x'][axis_x] = {'SETTINGS':gp_settings.default_axis.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None} # Create axes if they don't already exist
      if (not axis_y in axes['y']):
       axes['y'][axis_y] = {'SETTINGS':gp_settings.default_axis.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
      state=1
      continue

    if (state == 11): # read select criterion
      select_criteria.append(item)
      state = 1
      continue

    if (verb_errors): gp_error("Syntax Error: Unrecognised word '%s'"%item)
    return # Error

  # We have now read our filename, and operators on the filename
  if (verb_errors): parse_enderrors(state, withstate)

  if (title == None): using_autotitle = 1
  else              : using_autotitle = 0

  if (len(datafile) == 0):
    datafile = last_datafile_filename # '' shorthand for last datafile we used
  else:
    last_datafile_filename = datafile

  datafiles = glob.glob(os.path.join(gp_settings.cwd, os.path.expanduser(datafile)))
  datafiles.sort() # Sort list of globbed input filenames into alphabetical order
  userdatafile = datafile

  if (len(datafiles) == 0):
   raise IOError, "Datafile '%s' could not be found."%datafile

  if (len(datafiles) > 10):
   gp_warning("Plotting %d datafiles... this may take a little while..."%len(datafiles))
  for datafile in datafiles: # Plot each datafile in turn
   try:
    if (using_autotitle == 1):
     title = "'"+globwithuserpath(datafile,userdatafile)+"' "+autotitle
     title    = re.sub(r'[\\]', r'gpzywxqqq', title) # LaTeX does not like backslashs
     title    = re.sub(r'[_]', r'\\_', title) # LaTeX does not like underscores....
     title    = re.sub(r'[&]', r'\\&', title) # LaTeX does not like ampersands....
     title    = re.sub(r'[%]', r'\\%', title) # LaTeX does not like percents....
     title    = re.sub(r'[$]', r'\\$', title) # LaTeX does not like $s....
     title    = re.sub(r'[{]', r'\\{', title) # LaTeX does not like {s....
     title    = re.sub(r'[}]', r'\\}', title) # LaTeX does not like }s....
     title    = re.sub(r'[#]', r'\\#', title) # LaTeX does not like #s....
     title    = re.sub(r'[\^]', r'\\^{}', title) # LaTeX does not like carets....
     title    = re.sub(r'[~]', r'$\\sim$', title) # LaTeX does not like tildas....
     title = re.sub(r'[<]', r'$<$', title) # LaTeX does not like < outside of mathmode....
     title = re.sub(r'[>]', r'$>$', title) # LaTeX does not like > outside of mathmode....
     title    = re.sub(r'gpzywxqqq', r'$\\backslash$', title) # LaTeX does not like backslashs
     quotesearch = re.compile(r"[']")
     title    = quotesearch.sub("`", title, 1) # Do LaTeX smartquotes on filename....

    try:
      datafile_totalgrid = gp_datafile.gp_dataread(datafile, index, usingrowcol, using, select_criteria, every, vars, funcs, stylestr, verb_errors=verb_errors)
    except KeyboardInterrupt: raise
    except:
      if (verb_errors): gp_error("Error reading input datafile %s"%datafile)
      raise
  
    if (len(datafile_totalgrid) < 2): raise IOError, "No datapoints found in file '%s'."%datafile
  
    for data_section in range(1,len(datafile_totalgrid)): # Loop over data sections within index, plotting each as a separate line 
      [rows, columns, datagrid] = datafile_totalgrid[data_section]
 
      # Plot dataset
      if (data_section == 1): repeat = 0 # Are we to use same style as previous lump of data we plotted?
      else                  : repeat = 1
      plot_dataset(multiplot_number,g,axes,axis_x,axis_y,settings,title,datagrid,rows,columns,"datafile '%s'"%datafile,repeat,plotting,verb_errors)
   except:
    if (verb_errors): gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  return

# GLOBWITHUSERPATH(): Takes a glob result, e.g. /home/dcf21/datafile.dat, and the filename which the user supplied,
# perhaps ~dcf21/dat*.dat, and make a result like ~dcf21/datafile.dat.

def globwithuserpath(globform, userform):
  globbits = globform.split("/")
  userbits = userform.split("/")
  i=0
  while (i<len(userbits)):
    i+=1
    if gwup_canmatch(globbits[-i],userbits[-i]): userbits[-i]=globbits[-i]
    else                                       : break
  outstring=""
  for string in userbits: outstring+=string+"/"
  return outstring[:-1]

def gwup_canmatch(globbit, userbit, gpos=0, upos=0):
  while ((upos >= len(userbit)) or (userbit[upos] != "*")):
    if (upos >= len(userbit)): return True # We've reached the end of the user string
    if ((gpos < len(globbit)) and ((userbit[upos] == "?") or (userbit[upos] == globbit[gpos]))):
      gpos+=1
      upos+=1
      continue # This character matched, let's test next one...
    else:
      return False # This character didn't match...
  for i in range(gpos, len(globbit), 1):
    if gwup_canmatch(globbit, userbit, i, upos+1): # Try and match * with however many characters
      return True
  return False

# PLOT_FUNCTION(): Plot a function
def plot_function(multiplot_number,g,axes,settings,linestyles,plotwords,vars,funcs,plotting,verb_errors):
  global stylestr, pointsize, pointtype, linewidth, pointlinewidth, linestyle, plotcolour, plotfillcolour
  global withstate
  global using_use_warned

  function = ''
  axis_x   = 1
  axis_y   = 1
  using    = ''
  select_criteria = []
  xname    = ''
  title    = ''
  titledefault = 1
  quotetype= ''
  state    = 0
  stylestr = settings['FUNCSTYLE']
  pointsize= settings['POINTSIZE']
  pointtype  = -1
  linestyle  = -1
  plotcolour = "gp_auto"
  plotfillcolour = "gp_auto"
  linewidth  = settings['LINEWIDTH']
  pointlinewidth = settings['POINTLINEWIDTH']
  withstate  = 0

  for i in range(len(plotwords)):
   item = plotwords[i].strip()
   repeat = True
   while repeat:
    repeat = False
    if (len(item) == 0): continue # Ignore blank words

    if (state < 2):
     if autocomplete(item, "using"  , 1): state = 2 ; continue
     if autocomplete(item, "notitle", 3): title = ''; continue
     if autocomplete(item, "title"  , 1): state = 5 ; continue # also uses state 6
     if autocomplete(item, "with"   , 1): state = 7 ; continue
     if autocomplete(item, "axes"   , 1): state = 8 ; continue
     if autocomplete(item, "select" , 1): state = 11; continue

    if (state == 2): # read 'using' string
     if not using_use_warned:
       gp_warning("Warning: The use of the 'using' modifier when plotting functions comes with\nsevere caveats, as the range of x coordinates for which the function will be\ncalculated will continue to correspond to that of the graph's x-axis,\nregardless of what is actually plotted on this axis. Its use with autoscaling\nis especially not recommended. See the section 'General Extensions Beyond\nGnuplot' of the PyXPlot Users' Manual for further details.\n")
       using_use_warned = True
     using = item
     state = 1
     continue

    if (state == 5): # read 'title' string
      titledefault = 0
      test = re.match(r"""^(('|").*)$""",item)
      if (test == None): raise SyntaxError, "Title must be in quotes"
      item = test.group(1)
      title = ""
      state = 6
    if (state == 6): # Multiple word titles supported
      title += item + " "
      [text, aftertext] = gp_eval.gp_getquotedstring(title)
      if (text != None):
        title = text
        state = 1 # We have hit a closing quote
        item = aftertext.strip()
        if (len(item) > 0): repeat = True
      continue

    if (state == 7): # read 'with' clauses
      process_with_word(settings, linestyles, item, verb_errors)
      continue

    if (state == 8): # read axes string
      test = re.match(r"""^x(\d\d*)y(\d\d*)$""",item)
      if (test == None): raise SyntaxError, "Axes declaration must take the form x<n>y<m>"
      axis_x = int(test.group(1))
      axis_y = int(test.group(2))
      if ((axis_x < 1) or (axis_y < 1)): raise ValueError, "Axes declaration must take the form x<n>y<m> where {n,m}>0."  # Don't allow user to use axis zero!
      if (not axis_x in axes['x']):
       axes['x'][axis_x] = {'SETTINGS':gp_settings.default_axis.copy(), 'MIN_USED':-10.0, 'MAX_USED':10.0, 'AXIS':None} # Create axes if they don't already exist; linear axis from -10.0 to 10.0
      if (not axis_y in axes['y']):
       axes['y'][axis_y] = {'SETTINGS':gp_settings.default_axis.copy(), 'MIN_USED':None, 'MAX_USED':None, 'AXIS':None}
      state=1
      continue

    if (state == 11): # read select criterion
      select_criteria.append(item)
      state = 1
      continue

    if (state == 0): # Receive function
      function = function + item
      if (titledefault != 0): title = title + item
      xname    = 'x' # We always vary variable x along x axis...
      continue

    if (verb_errors): gp_error("Syntax Error: Unrecognised word '%s'"%item)
    return # Error

  # We have now read our function expression, and operators on it
  if (verb_errors): parse_enderrors(state, withstate)

  # Clean up LaTeX escape characters in autotitles
  if (titledefault != 0):
    title = re.sub(r'[\\]', r'gpzywxqqq', title) # LaTeX does not like backslashs
    title = re.sub(r'[_]', r'\\_', title) # LaTeX does not like underscores....
    title = re.sub(r'[&]', r'\\&', title) # LaTeX does not like ampersands....
    title = re.sub(r'[%]', r'\\%', title) # LaTeX does not like percents....
    title = re.sub(r'[$]', r'\\$', title) # LaTeX does not like $s....
    title = re.sub(r'[{]', r'\\{', title) # LaTeX does not like {s....
    title = re.sub(r'[}]', r'\\}', title) # LaTeX does not like }s....
    title = re.sub(r'[#]', r'\\#', title) # LaTeX does not like #s....
    title = re.sub(r'[\^]', r'\\^{}', title) # LaTeX does not like carets....
    title = re.sub(r'[~]', r'$\\sim$', title) # LaTeX does not like tildas....
    title = re.sub(r'[<]', r'$<$', title) # LaTeX does not like < outside of mathmode....
    title = re.sub(r'[>]', r'$>$', title) # LaTeX does not like > outside of mathmode....
    title = re.sub(r'gpzywxqqq', r'$\\backslash$', title) # LaTeX does not like backslashs

  # Make raster to evaluate function along, between limits of x-axis.
  minimum = axes['x'][axis_x]['MIN_USED']
  maximum = axes['x'][axis_x]['MAX_USED']

  # If no data on axis, make up a default range
  if (minimum == None): 
   if (axes['x'][axis_x]['SETTINGS']['LOG'] == 'ON'):
    if (maximum != None): minimum = maximum / 100 # Log axes start from 1
    else                : minimum = 1.0
   else:
    if (maximum != None): minimum = maximum - 20
    else                : minimum = -10.0         # Lin axes start from -10

  if (maximum == None):
   if (axes['x'][axis_x]['SETTINGS']['LOG'] == 'ON'): maximum = minimum * 100
   else                                             : maximum = minimum + 20

  # For boxes and histeps plot styles, take into account finite width of points
  if ((stylestr == "boxes") or (stylestr == "histeps")):
   if (settings['BOXWIDTH'] > 0.0): boxwidth = settings['BOXWIDTH']
   else                           : boxwidth = abs(maximum-minimum)/(settings['SAMPLES'] + 1)
   maximum2 = max(minimum,maximum) - boxwidth/2
   minimum2 = min(minimum,maximum) + boxwidth/2
   maximum  = maximum2
   minimum  = minimum2 

  # Finally compute raster
  if (axes['x'][axis_x]['SETTINGS']['LOG'] == 'ON'): xrast = gp_math.lograst(minimum, maximum, settings['SAMPLES'])
  else:                                              xrast = gp_math.linrast(minimum, maximum, settings['SAMPLES'])

  # Now evaluate functions
  datagrid   = []
  local_vars = vars.copy()
  functions  = function.split(":")

  for x in xrast:
   local_vars[xname] = x
   datapoint = [x]
   for item in functions:
    try:    val = gp_eval.gp_eval(item,local_vars,funcs,verbose=False)
    except KeyboardInterrupt: raise
    except: pass
    else:   datapoint.append(val)
   if (len(datapoint) == (len(functions)+1)):
    datagrid.append([[x for i in range(len(functions)+1)], x, datapoint])

  if (len(datagrid) == 0): # Nowhere was function evaluatable
   for item in functions:
    try:
     val = gp_eval.gp_eval(item,local_vars,funcs,verbose=False)
    except KeyboardInterrupt: raise
    except:
     if verb_errors: gp_error("Error evaluating expression '%s':"%item)
     raise
   gp_error("Error: PyXPlot has just evaluated an unevaluable function. Please report as a bug.")
   return # shouldn't ever execute this line of code!

  if verb_errors:
    local_vars[xname] = datagrid[-1][1] # Check for any warning messages
    for item in functions: val = gp_eval.gp_eval(item,local_vars,funcs,verbose=True)

  # Parse supplied using statement
  if (using == ''):
    for i in range(len(functions)+1):
      using += str(i+1)
      if (i != len(functions)): using += ":"
  totalgrid = gp_datafile.grid_using_convert([datagrid], "function %s"%function, "x=", using, select_criteria, vars, funcs, stylestr, verb_errors=verb_errors, errcount=0)

  # Plot dataset
  for data_section in range(1,len(totalgrid)): # Loop over data sections within index, plotting each as a separate line 
   [rows, columns, datagrid] = totalgrid[data_section]
   if (data_section == 1): repeat = 0 # Are we to use same style as previous lump of data we plotted?
   else                  : repeat = 1
   plot_dataset(multiplot_number,g,axes,axis_x,axis_y,settings,title,datagrid,rows,columns,"function '%s'"%function,repeat,plotting,verb_errors)

# PARSE_ENDERRORS(): Display a warning if states are not appropriate after processing a plot command.
# i.e. if we are expecting some data to follow the end of the line

def parse_enderrors(state, withstate):
  error = None
  if (state == 2): error = "Error: 'using' keyword should be followed by list of columns to use."
  if (state == 3): error = "Error: 'every' keyword should be followed by an integer."
  if (state == 4): error = "Error: 'index' keyword should be followed by an integer."
  if (state == 5): error = "Error: 'title' keyword should be followed by a title for the dataset."
  if (state == 6): error = "Error: 'title' closing quote could not be found."
  if (state == 8): error = "Error: 'axes' keyword should be followed by a list of axes to use."
  # state 9 is fit command via statement; it is okay to terminate in this state
  if (state ==10): error = "Error: 'smooth' keyword should be following by a smoothing value."
  if (state ==11): error = "Error: 'select' keyword should be following by a data selection criterion."
  if (state == 7):
   if (withstate == 1): error = "Error: 'with linetype' keyword should be followed by an integer."
   if (withstate == 2): error = "Error: 'with linewidth' keyword should be followed by a numerical width."
   if (withstate == 3): error = "Error: 'with pointsize' keyword should be followed by a numerical pointsize."
   if (withstate == 4): error = "Error: 'with pointtype' keyword should be followed by an integer."
   if (withstate == 5): error = "Error: 'with linestyle' keyword should be followed by an integer."
   if (withstate == 6): error = "Error: 'with pointlinewidth' keyword should be followed by a numerical width."
   if (withstate == 7): error = "Error: 'with colour' keyword should be followed by an integer palette index."
   if (withstate == 8): error = "Error: 'with fillcolour' keyword should be followed by an integer palette index."
  if (error != None):
   raise SyntaxError, error
  return

# PROCESS_WITH_WORD(): Process a word after the "with" directive

def process_with_word(settings, linestyles, word, verb_errors = True, iteration=0):
  global stylestr, pointsize, pointtype, linewidth, linestyle, plotcolour, plotfillcolour, pointlinewidth
  global withstate

  if (len(word) == 0): return

  if (withstate == 0):
   if (autocomplete(word,'linetype',5)       or  (word == 'lt')  ): withstate = 1 ; return
   if (autocomplete(word,'linewidth',5)      or  (word == 'lw')  ): withstate = 2 ; return
   if (autocomplete(word,'pointsize',7)      or  (word == 'ps')  ): withstate = 3 ; return
   if (autocomplete(word,'pointtype',6)      or  (word == 'pt')  ): withstate = 4 ; return
   if (autocomplete(word,'linestyle',6)      or  (word == 'ls')  ): withstate = 5 ; return
   if (autocomplete(word,'pointlinewidth',6) or  (word == 'plw') ): withstate = 6 ; return
   
   if (autocomplete(word,"colour",1) or autocomplete(word,"color",1) ): withstate = 7 ; return
   if (autocomplete(word,"fillcolour",2) or autocomplete(word,"fillcolor",2) or (word == 'fc')): withstate = 8 ; return

   if autocomplete(word,"lines",1)       : stylestr = 'lines'       ; return
   if autocomplete(word,"points",1)      : stylestr = 'points'      ; return
   if autocomplete(word,"lp",2)          : stylestr = 'linespoints' ; return
   if autocomplete(word,"linespoints",5) : stylestr = 'linespoints' ; return
   if autocomplete(word,"pl",2)          : stylestr = 'linespoints' ; return
   if autocomplete(word,"pointslines",5) : stylestr = 'linespoints' ; return
   if autocomplete(word,"dots",1)        : stylestr = 'dots'        ; return
   if autocomplete(word,"boxes",1)       : stylestr = 'boxes'       ; return
   if autocomplete(word,"wboxes",1)      : stylestr = 'wboxes'      ; return
   if autocomplete(word,"impulses",1)    : stylestr = 'impulses'    ; return
   if autocomplete(word,"steps",1)       : stylestr = 'steps'       ; return
   if autocomplete(word,"fsteps",1)      : stylestr = 'fsteps'      ; return
   if autocomplete(word,"histeps",1)     : stylestr = 'histeps'     ; return
   if autocomplete(word,"errorbars",1)   : stylestr = 'yerrorbars'  ; return
   if autocomplete(word,"xerrorbars",2)  : stylestr = 'xerrorbars'  ; return
   if autocomplete(word,"yerrorbars",2)  : stylestr = 'yerrorbars'  ; return
   if autocomplete(word,"xyerrorbars",2) : stylestr = 'xyerrorbars' ; return
   if autocomplete(word,"errorrange",6)  : stylestr = 'yerrorrange' ; return
   if autocomplete(word,"xerrorrange",7) : stylestr = 'xerrorrange' ; return
   if autocomplete(word,"yerrorrange",7) : stylestr = 'yerrorrange' ; return
   if autocomplete(word,"xyerrorrange",8): stylestr = 'xyerrorrange'; return
   if autocomplete(word,"arrows_head",3)    : stylestr = 'arrows_head'   ; return
   if autocomplete(word,"arrows_nohead",3)  : stylestr = 'arrows_nohead' ; return
   if autocomplete(word,"arrows_twoway",3)  : stylestr = 'arrows_twohead'; return
   if autocomplete(word,"arrows_twohead",3) : stylestr = 'arrows_twohead'; return
   if autocomplete(word,"csplines",3)    : stylestr = 'csplines'    ; return
   if autocomplete(word,"acsplines",3)   : stylestr = 'acsplines'   ; return

   if autocomplete(word,"smooth",2):
     gp_warning("Plot style 'smooth' is deprecated syntax; use 'csplines' or 'acsplines' instead.")
     gp_warning("The use of the more flexible 'spline' command is strongly recommended.")
     return

  if (withstate == 1):
   try:
    linestyle = int(word) ; withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Error: linetype should be followed by an integer.")
    raise
   return

  if (withstate == 2):
   try:
    linewidth = float(word) ; withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Error: linewidth should be followed by a floating point value.")
    raise
   return

  if (withstate == 3):
   try:
    pointsize = float(word) ; withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Error: pointsize should be followed by a floating point value.")
    raise
   return

  if (withstate == 4):
   try:
    pointtype = int(word) ; withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Error: pointtype should be followed by an integer.")
    raise
   return

  if (withstate == 5):
    try:
     number = int(word) ; withstate = 0
    except KeyboardInterrupt: raise
    except:
     if (verb_errors): gp_error("Error: linestyle should be followed by the number of the desired linestyle.")
     raise

    if (not linestyles.has_key(number)):
     if (verb_errors): gp_error("Error: linestyle %d is not defined."%number)
    else:
     if (iteration > 4):
      if (verb_errors): gp_error("Iteration ceiling hit whilst processing linestyle %d."%number)
     else:
      for word in linestyles[number].split():
        process_with_word(settings,linestyles,word,verb_errors,iteration+1)
    return

  if (withstate == 6):
   try:
    pointlinewidth = float(word) ; withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Error: pointlinewidth should be followed by a floating point value.")
    raise
   return

  if (withstate == 7):
   try:
    test2 = re.match(r"^\d\d*$",word)
    if (test2 != None):
     plotcolour = gp_settings.colour_list[(int(word)-1)%len(gp_settings.colour_list)].capitalize()
    elif (word.capitalize() in gp_settings.pyx_colours):
     plotcolour = word.capitalize()
    else:
     if (verb_errors): gp_error("Unrecognised colour '%s'; defaulting to black."%word)
     plotcolour = "Black"
    withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Unexpected error whilst processing colour specifier.")
    raise
   return

  if (withstate == 8):
   try:
    test2 = re.match(r"^\d\d*$",word)
    if (test2 != None):
     plotfillcolour = gp_settings.colour_list[(int(word)-1)%len(gp_settings.colour_list)].capitalize()
    elif (word.capitalize() in gp_settings.pyx_colours):
     plotfillcolour = word.capitalize()
    elif (word.capitalize() == "Auto"):
     plotfillcolour = "auto"
    else:
     if (verb_errors): gp_error("Unrecognised colour '%s'; defaulting to black."%word)
     plotfillcolour = "Black"
    withstate = 0
   except KeyboardInterrupt: raise
   except:
    if (verb_errors): gp_error("Unexpected error whilst processing fillcolour specifier.")
    raise
   return

  if (verb_errors): gp_error("Error: Unrecognised word '%s' in following 'with' keyword."%word)
  return

# PLOT_LINEWIDTH(): Turn a numerical linewidth into a PyX style

def plot_linewidth(width):
  defaultlinewidth = 0.02 * unit.w_cm
  return style.linewidth(defaultlinewidth * width)

# PLOT_DATASET(): Plot a datagrid

def plot_dataset(multiplot_number,g,axes,axis_x,axis_y,settings,title,datagrid,rows,columns,description,repeat,plotting,verb_errors):
  global successful_plot_operations
  global stylestr, pointsize, pointtype, linewidth, pointlinewidth, linestyle, plotcolour, plotfillcolour
  global linecount, ptcount, colourcnt

  # Check that we have a sufficient number of columns of data for this plot style
  columns_req = gp_settings.datastyleinfo[stylestr][1]
  if (columns < columns_req):
   if (verb_errors): gp_error("Need at least %d columns to plot data from %s."%(columns_req,description))
   return  

  if (columns > columns_req):
   if (verb_errors): gp_warning("Warning: Plot style '%s' requires only %d columns, but %d have been specified. Using the first %d."%(stylestr,columns_req,columns,columns_req))

  # If this is a histogram, then check whether it is a stacked barchart or not
  if stylestr in ['boxes', 'wboxes']:
    datagrid.sort(key=operator.itemgetter(0))
    stacked_bars = [[]]
    prev_x       = None # x-coordinate of previous bar; used to test whether we're going to stack more on top of it
    prev_y       = None # Accumulator for adding up height of stacked bar in stacked barcharts
    prev_addons  = []   # Further columns after the height y
    i            = None # The stacking height of the current bar
    for datapoint in datagrid:
     if (datapoint[0] != prev_x): # We have a new x-coordinate, so start stacking a new stacked bar
      for j in range(len(stacked_bars)):
       while (len(stacked_bars[-1]) > len(stacked_bars[j])):
        stacked_bars[j].append([prev_x,prev_y]+prev_addons)
      i      = 0
      prev_x = datapoint[0]
      prev_y = 0.0
      prev_addons = datapoint[2:]
     else: # This point is at the same x-coordinate as previous point, so stack on top of it
      i += 1
     if (i >= len(stacked_bars)): stacked_bars.insert(0, stacked_bars[0][:-1]) # If we have a record stacking height, create a new barchart behind previous highest.
     prev_y += datapoint[1]
     prev_addons = datapoint[2:]
     stacked_bars[-1-i].append([prev_x,prev_y]+prev_addons)
    if (len(stacked_bars) > 1):
     for dataset in stacked_bars:
      plot_dataset(multiplot_number,g,axes,axis_x,axis_y,settings,title,dataset,len(dataset),columns,description,0,plotting,verb_errors)
     return

  try:
    stylelist = []
    dx = None ; dxmin = None ; dxmax = None
    dy = None ; dymin = None ; dymax = None

    if (repeat == 1):
     localtitle = None    # Stops key have multiple references to the same line
    else:
     localtitle = title
     if ((localtitle != None) and (len(localtitle) < 1)): # Don't put blank titles into key
      localtitle = None

    # Determine what colour to use to plot this dataset

    if (settings['COLOUR'] == 'ON'): # Match colour
     if (plotcolour == "gp_auto"):
      if (repeat != 0): colourcnt  = colourcnt -1
      colour = gp_settings.pyx_colours[gp_settings.colour_list[(colourcnt-1)%len(gp_settings.colour_list)]] # If plotcolour not set, automatically increment colour
      colourcnt  = colourcnt + 1
     else:
      colour = gp_settings.pyx_colours[plotcolour] # otherwise used specified colour
    else:
      colour = color.grey.black # If monochrome, then set colour to black

    # Preplot action... if spline linestyle, then make a spline....
    if (stylestr in ['csplines','acsplines']):
      if (stylestr == 'csplines'): smoothing = 0.0
      else:                        smoothing = 1.0
      if (rows < 4) and verb_errors: gp_warning("Attempt to make spline doomed to fail -- need at least four data points to make a cubic spline.")
      try:
        [xmin, xmax, splineobj] = gp_spline.make_spline_object(rows,columns,datagrid,smoothing)
      except KeyboardInterrupt: raise
      except:
        raise "Failed to make spline object."
      datagrid  = []
      if (axes['x'][axis_x]['SETTINGS']['LOG'] == 'ON'): xrast = gp_math.lograst(xmin,xmax,settings['SAMPLES'])
      else:                                              xrast = gp_math.linrast(xmin,xmax,settings['SAMPLES'])
      for x in xrast: datagrid.append([x,gp_spline.spline_evaluate(x, splineobj)])

    # Now determine what linestyle to use, and make a list of style items to plot (in the case of linespoints or error bars, there are more than one)

    if (stylestr in ['lines','linespoints','csplines','acsplines']): # Match lines and linespoints
      if (linestyle < 0):
        if (settings['COLOUR'] == 'ON'):
          linestyle = 1 # Colour lines are automatically all solid
        else:
          if (repeat != 0): linecount = linecount - 1
          linestyle = linecount # Monochrome lines automatically have different linestyles
          linecount = linecount + 1
      stylelist.append(graph.style.line(lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour ]))
    if (stylestr in ['arrows_head','arrows_nohead','arrows_twohead']):
      if (linestyle < 0):
        if (settings['COLOUR'] == 'ON'):
          linestyle = 1 # Colour lines are automatically all solid
        else:
          if (repeat != 0): linecount = linecount - 1
          linestyle = linecount # Monochrome lines automatically have different linestyles
          linecount = linecount + 1
      if ( ((datagrid[0][0] == datagrid[1][0]) and (datagrid[0][1] == datagrid[1][1])) # arrow doesn't go anywhere, which is bad. Put no heads on such arrows.
          or (stylestr == 'arrows_nohead') ):
        stylelist.append(graph.style.line(lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour ]))
      elif (stylestr == 'arrows_head'):
        stylelist.append(graph.style.line(lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour , deco.earrow.normal]))
      else:
        stylelist.append(graph.style.line(lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour , deco.barrow.normal, deco.earrow.normal]))
    if (stylestr in ['points','linespoints']): # Match points and linespoints
      if (pointtype < 0):
        if (repeat != 0): ptcount   = ptcount - 1
        pointtype = ptcount # Both colour and monochrome point types automatically increment
        ptcount   = ptcount + 1
      for symboldata in gp_settings.symbol_list[(pointtype-1)%len(gp_settings.symbol_list)]:
        if symboldata[1]: fillattr = [deco.filled([colour])]
        else            : fillattr = []
        stylelist.append(graph.style.symbol(size=0.1*pointsize, symbol=symboldata[0], symbolattrs=[colour,plot_linewidth(pointlinewidth)]+fillattr))
    if (stylestr == 'dots'): # Match dots
      stylelist.append(graph.style.symbol(size=0.005*pointsize, symbol=graph.style.symbol.circle, symbolattrs=[colour,deco.filled([colour])]))
    if (stylestr in ['boxes', 'wboxes', 'impulses', 'steps', 'fsteps', 'histeps']): # Match boxes
      dx=3 # Widths of boxes are about to be put into a third column
      if (linestyle < 0):
        if (settings['COLOUR'] == 'ON'):
          linestyle = 1 # Colour lines are automatically all solid
        else:
          if (repeat != 0): linecount = linecount - 1
          linestyle = linecount # Monochrome lines automatically have different linestyles
          linecount = linecount + 1
      if (stylestr != 'wboxes'): # Work out widths of boxes
       datagrid_cpy      = []
       ptA = ptB = ptC = None
       for ptlist in datagrid:
        ptA = ptB ; ptB = ptC ; ptC = ptlist
        if (ptB != None):
         if (ptA != None):
          if (stylestr in ['boxes', 'histeps']):
           if (settings['BOXWIDTH'] <= 0.0)    : datagrid_cpy.append([ (ptB[0]+(ptA[0]+ptC[0])/2)/2 , ptB[1] , (ptC[0]-ptA[0])/4      ])
           else                                : datagrid_cpy.append([ ptB[0]                       , ptB[1] , settings['BOXWIDTH']/2 ])
          if (stylestr == 'impulses')          : datagrid_cpy.append([ ptB[0]                       , ptB[1] , 0.0                    ])
          if (stylestr == 'steps')             : datagrid_cpy.append([ (ptA[0]+ptB[0])/2            , ptB[1] , (ptB[0]-ptA[0])/2      ])
          if (stylestr == 'fsteps')            : datagrid_cpy.append([ (ptC[0]+ptB[0])/2            , ptB[1] , (ptC[0]-ptB[0])/2      ])
         else:
          if (stylestr in ['boxes', 'histeps']):
           if (settings['BOXWIDTH'] <= 0.0)    : datagrid_cpy.append([ ptB[0]                       , ptB[1] , (ptC[0]-ptB[0])/2      ])
           else                                : datagrid_cpy.append([ ptB[0]                       , ptB[1] , settings['BOXWIDTH']/2 ])
          if (stylestr == 'impulses')          : datagrid_cpy.append([ ptB[0]                       , ptB[1] , 0.0                    ])
          if (stylestr == 'steps')             : datagrid_cpy.append([ ptB[0]                       , ptB[1] , 0.0                    ])
          if (stylestr == 'fsteps')            : datagrid_cpy.append([ (ptC[0]+ptB[0])/2            , ptB[1] , (ptC[0]-ptB[0])/2      ])
       if (ptB != None):
          if (stylestr in ['boxes', 'histeps']):
           if (settings['BOXWIDTH'] <= 0.0)    : datagrid_cpy.append([ ptC[0]                       , ptC[1] , (ptC[0]-ptB[0])/2      ])
           else                                : datagrid_cpy.append([ ptB[0]                       , ptB[1] , settings['BOXWIDTH']/2 ])
          if (stylestr == 'impulses')          : datagrid_cpy.append([ ptC[0]                       , ptC[1] , 0.0                    ])
          if (stylestr == 'steps')             : datagrid_cpy.append([ (ptC[0]+ptB[0])/2            , ptC[1] , (ptC[0]-ptB[0])/2      ])
          if (stylestr == 'fsteps')            : datagrid_cpy.append([ ptC[0]                       , ptC[1] , 0.0                    ])
       else:
          datagrid_cpy.append([ ptC[0], ptC[1], 0.5 ])
       datagrid = datagrid_cpy
      else: # Work out widths of wboxes
       datagrid_cpy      = []
       for pt in datagrid: datagrid_cpy.append([ pt[0], pt[1], 0.5*pt[2] ])
       datagrid = datagrid_cpy
      if   (stylestr in ['boxes', 'wboxes', 'impulses']):
       if (plotfillcolour == "gp_auto"): # Process fill colour if we're going to fill our boxes
        fillcolset = None
       elif (settings['COLOUR'] != 'ON'):
        fillcolset = deco.filled([colour])
       elif (plotfillcolour == "auto"): # Fill colour auto --> fill box with line colour
        fillcolset = deco.filled([colour])
       else:
        fillcolset = deco.filled([gp_settings.pyx_colours[plotfillcolour]])
       lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour ]
       if (fillcolset != None): lineattrs.append(fillcolset)
       stylelist.append(graph.style.histogram(lineattrs=lineattrs, steps=0, fillable=1, fromvalue=settings['BOXFROM']))
      elif (stylestr in ['steps', 'fsteps', 'histeps']):
       datagrid_cpy      = []
       for pt in datagrid:
        datagrid_cpy.append([pt[0]-pt[2],pt[1]])
        datagrid_cpy.append([pt[0]+pt[2],pt[1]])
       datagrid = datagrid_cpy
       dx=None
       stylelist.append(graph.style.line(lineattrs=[ gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour ]))
    if (re.search('error',stylestr) != None): # Match {x|y|xy}error{bars|range}
      if (linestyle < 0):
        if (settings['COLOUR'] == 'ON'):
          linestyle = 1 # Colour errorbars are automatically all solid
        else:
          if (repeat != 0): linecount = linecount - 1
          linestyle = linecount
          linecount = linecount + 1
      stylelist.append(graph.style.errorbar(size=0.1*pointsize*settings['BAR'], errorbarattrs=[gp_settings.linestyle_list[(linestyle-1)%len(gp_settings.linestyle_list)], plot_linewidth(linewidth), colour]))
      stylelist.append(graph.style.symbol(size=0.1*pointsize, symbol=graph.style.symbol.plus, symbolattrs=[colour,plot_linewidth(linewidth)]))
      if   (stylestr == 'xerrorbars'  ): dx = 3
      elif (stylestr == 'yerrorbars'  ): dy = 3
      elif (stylestr == 'xyerrorbars' ): dx = 3 ; dy = 4
      elif (stylestr == 'xerrorrange' ): dxmin = 3 ; dxmax = 4
      elif (stylestr == 'yerrorrange' ): dymin = 3 ; dymax = 4
      elif (stylestr == 'xyerrorrange'): dxmin = 3 ; dxmax = 4 ; dymin = 5 ; dymax = 6

    # Clean up datagrid, removing any points < 0 which might go on log axis
    datagrid_cpy_list = []
    datagrid_cpy      = []
    for ptlist in datagrid:
      if (((axes['x'][axis_x]['SETTINGS']['LOG'] == 'ON') and (ptlist[0] <= 0.0)) or
          ((axes['y'][axis_y]['SETTINGS']['LOG'] == 'ON') and (ptlist[1] <= 0.0))):
       if (len(datagrid_cpy) != 0):
        datagrid_cpy_list.append(datagrid_cpy)
        datagrid_cpy = [] # Split dataset, not connecting points where it goes to minus infinity
      else:
       datagrid_cpy.append(ptlist)
    if (len(datagrid_cpy) != 0): datagrid_cpy_list.append(datagrid_cpy)
    if (len(datagrid_cpy_list) == 0): return # No data to plot!

    for datagrid_cpy in datagrid_cpy_list:
     if (localtitle != None): successful_plot_operations[multiplot_number] = 'ON' # Only count datasets which will put an entry into the key
     if (not plotting):
      for i in range(len(datagrid_cpy)):
       # First time around, we recalculate data bounding box
       xaxis_min = gp_math.min( axes['x'][axis_x]['SETTINGS']['MIN'] , axes['x'][axis_x]['SETTINGS']['MAX'] )
       xaxis_max = gp_math.max( axes['x'][axis_x]['SETTINGS']['MIN'] , axes['x'][axis_x]['SETTINGS']['MAX'] )
       yaxis_min = gp_math.min( axes['y'][axis_y]['SETTINGS']['MIN'] , axes['y'][axis_y]['SETTINGS']['MAX'] )
       yaxis_max = gp_math.max( axes['y'][axis_y]['SETTINGS']['MIN'] , axes['y'][axis_y]['SETTINGS']['MAX'] )

       xpoints = [datagrid_cpy[i][0]]
       ypoints = [datagrid_cpy[i][1]]
       if   (stylestr == 'xerrorbars'  ): xpoints.extend([datagrid_cpy[i][0]-datagrid_cpy[i][2],datagrid_cpy[i][0]+datagrid_cpy[i][2]])
       elif (stylestr == 'yerrorbars'  ): ypoints.extend([datagrid_cpy[i][1]-datagrid_cpy[i][2],datagrid_cpy[i][1]+datagrid_cpy[i][2]])
       elif (stylestr == 'xerrorrange' ): xpoints.extend([datagrid_cpy[i][2]                   ,datagrid_cpy[i][3]                   ])
       elif (stylestr == 'yerrorrange' ): ypoints.extend([datagrid_cpy[i][2]                   ,datagrid_cpy[i][3]                   ])
       elif (stylestr == 'xyerrorbars' ):
                                          xpoints.extend([datagrid_cpy[i][0]-datagrid_cpy[i][2],datagrid_cpy[i][0]+datagrid_cpy[i][2]])
                                          ypoints.extend([datagrid_cpy[i][1]-datagrid_cpy[i][3],datagrid_cpy[i][1]+datagrid_cpy[i][3]])
       elif (stylestr == 'xyerrorrange'):
                                          xpoints.extend([datagrid_cpy[i][2]                   ,datagrid_cpy[i][3]                   ])
                                          ypoints.extend([datagrid_cpy[i][4]                   ,datagrid_cpy[i][5]                   ])
       elif (stylestr in ['wboxes', 'boxes', 'impulses']):
                                          xpoints.extend([datagrid_cpy[i][0]-datagrid_cpy[i][2],datagrid_cpy[i][0]+datagrid_cpy[i][2]])
                                          ypoints.extend([settings['BOXFROM']                                        ])

       # First the x-bounding-box
       # Is datapoint within range of y-axis? If not, don't use it to recalculate x-bounding-box
       if (((yaxis_min == None) or (ypoints[0] >= yaxis_min)) and
           ((yaxis_max == None) or (ypoints[0] <= yaxis_max))     ):
        for xpoint in xpoints:
         if ((axes['x'][axis_x]['SETTINGS']['LOG'] != 'ON') or (xpoints[0] > 0)): # Don't count negative points on log axes
          if (axes['x'][axis_x]['SETTINGS']['MIN'] == None): # Only modify bounding boxes that we are autoscaling
           if ((axes['x'][axis_x]['MIN_USED'] == None) or (axes['x'][axis_x]['MIN_USED'] > xpoint)): axes['x'][axis_x]['MIN_USED'] = xpoint
          if (axes['x'][axis_x]['SETTINGS']['MAX'] == None): # Only modify bounding boxes that we are autoscaling
           if ((axes['x'][axis_x]['MAX_USED'] == None) or (axes['x'][axis_x]['MAX_USED'] < xpoint)): axes['x'][axis_x]['MAX_USED'] = xpoint

       # Second the y-bounding-box
       # Is datapoint within range of x-axis? If not, don't use it to recalculate y-bounding-box
       if (((xaxis_min == None) or (xpoints[0] >= xaxis_min)) and
           ((xaxis_max == None) or (xpoints[0] <= xaxis_max))     ):
        for ypoint in ypoints:
         if ((axes['y'][axis_y]['SETTINGS']['LOG'] != 'ON') or (ypoints[0] > 0)): # Don't count negative points on log axes
          if (axes['y'][axis_y]['SETTINGS']['MIN'] == None): # Only modify bounding boxes that we are autoscaling
           if ((axes['y'][axis_y]['MIN_USED'] == None) or (axes['y'][axis_y]['MIN_USED'] > ypoint)): axes['y'][axis_y]['MIN_USED'] = ypoint
          if (axes['y'][axis_y]['SETTINGS']['MAX'] == None): # Only modify bounding boxes that we are autoscaling
           if ((axes['y'][axis_y]['MAX_USED'] == None) or (axes['y'][axis_y]['MAX_USED'] < ypoint)): axes['y'][axis_y]['MAX_USED'] = ypoint
     else: # First time around, we quit here and don't actually plot anything
      # Second time around, we actually plot data
      x_axisname = axes['x'][axis_x]['LINKINFO']['AXISPYXNAME']
      y_axisname = axes['y'][axis_y]['LINKINFO']['AXISPYXNAME']
      x_set = x_axisname+"=1,"
      y_set = y_axisname+"=2,"
      if (dx != None): dx_set = "d"+x_axisname+"=dx,"
      else           : dx_set = ""
      if (dy != None): dy_set = "d"+y_axisname+"=dy,"
      else           : dy_set = ""
      if (dxmin != None): dx_set = x_axisname+"min=dxmin,"+x_axisname+"max=dxmax,"
      if (dymin != None): dy_set = y_axisname+"min=dymin,"+y_axisname+"max=dymax,"
      exec "g.plot(graph.data.list(datagrid_cpy,"+x_set+y_set+dx_set+dy_set+"title=localtitle),styles=stylelist)"
      localtitle = None # Only put a title on one dataset
  except KeyboardInterrupt: raise
  except:
    if (verb_errors):
      gp_error("Failed while plotting %s:"%description)
      gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
      return # Error
  return

# EPSTOPS(): Tool to convert eps to ps via latex

epstops_counter=0

def epstops(filename):
 global epstops_counter
 file_paths=['foo']
 while (len(file_paths) != 0): # Take care not to overright a pre-existing file in /tmp 
  epstops_counter = epstops_counter + 1
  fname = "gp+_" + str(os.getpid()) + "_" + str(epstops_counter)
  file_paths=glob.glob("%s*"%fname)
 latex_out = open("%s.tex"%fname,"w")
 latex_text = r"""
  \documentclass[a4paper,onecolumn,11pt]{article}
  \addtolength{\textwidth}{\marginparwidth}
  \addtolength{\textheight}{\topmargin}
  \addtolength{\textheight}{\headheight}
  \addtolength{\textheight}{\headsep}
  \addtolength{\textheight}{\footskip}
  \setlength{\marginparwidth}{0cm}
  \setlength{\topmargin}{0cm}
  \setlength{\headheight}{0cm}
  \setlength{\headsep}{0cm}
  \setlength{\footskip}{0cm}
  \usepackage[dvips]{graphicx}
  \usepackage{lscape}
  \pagestyle{empty}
  \begin{document}
  \centerline{\includegraphics{"""+filename+"""}}
  \end{document}
 """
 latex_out.write(latex_text)
 latex_out.close()
 os.system("echo 'latex %s.tex &> /dev/null' | bash"%(fname))
 os.system("echo 'dvips %s.dvi -o %s.ps &> /dev/null' | bash"%(fname,fname))
 os.system("mv %s.ps %s"%(fname,filename)) # Replace old file with new

