VERSION='0.6.0'
DATE='12/11/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
