# GP_TEXT.PY
# Dominic Ford
# 12/11/2006

# Contains text messages which pyxplot displays

import gp_version # Version and date strings written by installer

VERSION = gp_version.VERSION
DATE    = gp_version.DATE

version = r"""PyXPlot """+VERSION

help = r"""PyXPlot """+VERSION+"""
-------------

Usage: pyxplot <options> <filelist>
  -h, --help:       Display this help.
  -v, --version:    Display version number.
  -q, --quiet:      Turn off initial welcome message.
  -c, --colour:     Use coloured highlighting of output.
  -m, --monochrome: Turn off coloured highlighting."""

init = r"""
 ____       __  ______  _       _      PYXPLOT
|  _ \ _   _\ \/ /  _ \| | ___ | |_    Version """+VERSION+r"""
| |_) | | | |\  /| |_) | |/ _ \| __|   """+DATE+r"""
|  __/| |_| |/  \|  __/| | (_) | |_
|_|    \__, /_/\_\_|   |_|\___/ \__|   Copyright (C) 2006 Dominic Ford
       |___/

With thanks to Joerg Lehmann and Andre Wobst for writing PyX, and to
Ross Church for his many helpful suggestions along the way.

Send comments, bug reports, feature requests and coffee supplies to:
<dcf21@mrao.cam.ac.uk>
"""

invalid = r"""
 %s
/|\
 |
Error: Unrecognised command.
"""

valid_set_options = r"""
'arrow', 'autoscale', 'axescolour', 'axis', 'backup', 'bar', 'boxwidth',
'boxfrom', 'data style', 'display', 'dpi', 'fontsize', 'function style',
'grid', 'gridmajcolour', 'gridmincolour', 'key', 'keycolumns', 'label',
'linestyle', 'linewidth', 'logscale', 'multiplot', 'noarrow', 'nobackup',
'nodisplay', 'nogrid', 'nokey', 'nolabel', 'nolinestyle', 'nologscale',
'nomultiplot', 'notitle', 'origin', 'palette', 'papersize', 'pointlinewidth',
'pointsize', 'samples', 'size', 'size noratio', 'size square', 'size ratio',
'terminal', 'textcolour', 'texthalign', 'textvalign', 'title', 'width',
'[xyz]<n>label', '[xyz]<n>range', '[xyz]<n>ticdir'
"""

valid_show_options = r"""
'autoscale', 'axescolour', 'backup', 'bar', 'boxwidth', 'boxfrom', 'data
style', 'display', 'dpi', 'fontsize', 'function style', 'grid',
'gridmajcolour', 'gridmincolour', 'key', 'keycolumns', 'label', 'linestyle',
'linewidth', 'logscale', 'multiplot', 'origin', 'palette', 'papersize',
'pointlinewidth', 'pointsize', 'samples', 'size', 'terminal', 'textcolour',
'texthalign', 'textvalign', 'title', 'width', '[xyz]<n>label', '[xyz]<n>range',
'[xyz]<n>ticdir'
"""

set_noword = r"""
Set options which PyXPlot recognises are: [] = choose one, <> = optional
"""+valid_set_options+"""
Set options from gnuplot which PyXPlot DOES NOT recognise:

'angles', 'border', 'clabel', 'clip', 'cntrparam', 'colorbox', 'contour',
'decimalsign', 'dgrid3d', 'dummy', 'encoding', 'format', 'hidden3d',
'historysize', 'isosamples', 'locale', '[blrt]margin', 'mapping', 'mouse',
'offsets', 'parametric', 'pm3d', 'polar', 'print', '[rtuv]range', 'style',
'surface', 'tics', 'ticscale', 'ticslevel', 'timestamp', 'timefmt', 'view',
'[xyz]{2}data', '{no}{m}[xyz]{2}tics', '[xyz]{2}[md]tics',
'{[xyz]{2}}zeroaxis', 'zero'
"""

unset_noword = r"""
Unset options which PyXPlot recognises are: [] = choose one, <> = optional

'arrow', 'autoscale', 'axescolour', 'axis', 'backup', 'boxwidth', 'boxfrom',
'display', 'dpi', 'fontsize', 'grid', 'gridmajcolour', 'gridmincolour', 'key',
'keycolumns', 'label', 'linestyle', 'linewidth', 'logscale', 'multiplot',
'nokey', 'nologscale', 'origin', 'papersize', 'pointlinewidth', 'pointsize',
'samples', 'size', 'terminal', 'textcolour', 'texthalign', 'textvalign',
'title', 'width', '[xyz]<n>label', '[xyz]<n>range', '[xyz]<n>ticdir'
"""

set = r"""
Error: Invalid set option '%s'.

"""+set_noword

unset = r"""
Error: Invalid unset option '%s'.

"""+unset_noword

show = r"""
Valid 'show' options are:

'all', 'arrows', 'axes', 'settings', 'labels', 'linestyles', 'variables',
'functions'

or any of the following set options:
"""+valid_show_options
