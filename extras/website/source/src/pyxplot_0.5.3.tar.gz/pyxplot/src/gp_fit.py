# GP_FIT.PY
# Dominic Ford
# 27/06/2006

import gp_eval
import gp_datafile
import gp_plot
from gp_autocomplete import *
from gp_error import *

import sys
import re
from math import *
from scipy.optimize import fmin

pass_function = ''
no_arguments  = 0
pass_ranges   = []
pass_vialist  = []
pass_vars     = {}
pass_funcs    = {}
pass_dataset  = []

yerrors = 0

# FIT_RESIDUAL(): Evaluates the residual between function and dataset

def fit_residual(x):
  global pass_function, no_arguments, pass_range, pass_vialist, pass_xname, pass_vars, pass_funcs, pass_dataset
  global yerrors

  local_vars  = pass_vars
  for i in range(len(pass_vialist)): # Set via variables
    local_vars[pass_vialist[i]] = x[i]

  accumulator = 0.0
  for datapoint in pass_dataset:
    eval_string = pass_function+"("
    for i in range(no_arguments):
      eval_string += str(datapoint[i])
      if (i != (no_arguments-1)): eval_string += ","
    eval_string += ")"
    residual    = datapoint[no_arguments] - gp_eval.gp_eval(eval_string,local_vars,pass_funcs)
    if (yerrors != 0): residual = residual / datapoint[no_arguments+1]
    accumulator = accumulator + pow(residual, 2.0)

  return accumulator

# DIRECTIVE_FIT(): Implements the "fit" directive

def directive_fit(line, vars, funcs):
  global pass_function, no_arguments, pass_ranges, pass_vialist, pass_vars, pass_funcs, pass_dataset
  global yerrors

  # FIRST OF ALL, WE NEED TO READ THE INPUT PARAMETERS FROM THE COMMANDLINE

  # Ranges comes first...
  errorstring = "Syntax Error: syntax of fit command is:\nfit <[min:max][]...> function(x) 'datafile' <using a:b...> <every c:d:e:f:g> <index h> via i,j"
  test = re.match("\s*\S*\s*(.*)",line)
  if (test == None): gp_error(errorstring) ; return
  line = test.group(1)
  while ((len(line) > 0) and (line[1] == "[")):
    test = re.match("""\[([^:\]]*)((:)|( *to *))([^:\]]*)\]\s*(.*)$""",line)
    if (test == None): gp_error("Could not read range in fit command. Use format: [min:max].") ; return # Error
    try:
      pass_ranges.append([ gp_eval.gp_eval(test.group(1),vars,funcs),
                           gp_eval.gp_eval(test.group(5),vars,funcs) ] )
    except: return
    line = test.group(6)

  # Then function name
  test = re.match("([A-Za-z]\w*)\s*(\(.*)$",line)
  if (test == None): gp_error(errorstring) ; return
  pass_function = test.group(1)
  if not pass_function in funcs: gp_error("Error: fit command requested to fit function '%s'; no such function."%pass_function) ; return
  no_arguments  = funcs[pass_function][0]
  bracketmatch  = gp_eval.gp_bracketmatch(test.group(2),0)
  if (bracketmatch == None): gp_error(errorstring) ; return
  arguments = test.group(2)[1:bracketmatch[-1]].split(",")
  if ((len(arguments) != no_arguments) and (bracketmatch[-1] != 1)):
    gp_error("Error: fit command requested to fit function '%s' with %d arguments, when it is defined to take %d arguments."%(pass_function,len(arguments),funcs[pass_function][0]))
    return
  if ((bracketmatch[-1]+1) < len(test.group(2))): line = test.group(2)[bracketmatch[-1]+1:]
  else                                          : gp_error(errorstring) ; return

  datafile = ''
  usingrowcol = "col"
  using    = ''
  every    = ''
  index    = -1 # GnuPlot API doesn't have an index value for "plot all indices", so I define it to be -1.
  xmin     = 0 ; xmax = 0 ; xrange = 0 # Reset range variables
  ymin     = 0 ; ymax = 0 ; yrange = 0
  vialist  = []
  state    = 0 # 0 = datafile not yet read ; 1 = after datafile read, last word was not keyword ; 2 = using read ; 3 = every read ; 4 = via read

  linelist = line.split()
  for i in range(len(linelist)):
    item = linelist[i].strip()

    if (state < 2):
      if autocomplete(item, "using", 1): state = 2 ; continue
      if autocomplete(item, "every", 1): state = 3 ; continue
      if autocomplete(item, "index", 1): state = 4 ; continue
      if autocomplete(item, "via"  , 1): state = 9 ; continue

    if (state == 2): # read 'using' string
      if   autocomplete(item, "columns",3): usingrowcol="col"
      elif autocomplete(item, "rows"   ,3): usingrowcol="row"
      else:
        using = item
        state = 1
      continue

    if (state == 3): # set 'every' setting
      every = item
      state = 1
      continue

    if (state == 4): # set 'index' setting
      try:
        index = int(item)
      except:
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
        gp_error("'index' keyword should be followed by an integer")
        return # Error
      state = 1
      continue

    if (state == 9): # read via list
      commasplit = gp_eval.gp_split(item,",")
      for var in commasplit:
        var_clean = var.strip()
        test = re.match(r"""^[A-Za-z]\w*$""",var_clean)
        if (test == None):
          gp_error("Illegal variable name '%s' in via. Must contain only alphanumeric characters."%var_clean)
          return
        vialist.append(var_clean)
      continue

    if ((state == 0) and (item[0] == "'")):
      test = re.match(r"""^'(.*)'$""",item)
      if (test == None):
        gp_error("""Badly formed datafile name "%s"."""%item)
        return # Error
      datafile = test.group(1)
      state = 1
      continue

    gp_error("Syntax Error: Unrecognised word '%s'"%item)
    return # Error


  if (len(using) == 0): # Make up default using string depending upon the number of parameters that our function takes
   for i in range(no_arguments+1): using += str(i+1)+":"
   using = using[:-1]

  # We have now read all of our commandline parameters, and are ready to start fitting
  gp_plot.parse_enderrors(state,0)

  try:
    (rows,columns,datagrid) = gp_datafile.gp_dataread(datafile, index, usingrowcol, using, every, vars, funcs, "points", firsterror=no_arguments+1)[0]
    datagrid_cpy = []
    for datapoint in datagrid:
     for i in range(columns):
      if ((i < len(pass_ranges)) and ((pass_ranges[i][0] > datapoint[i]) or (pass_ranges[i][1] < datapoint[i]))): break
      if (i == (columns-1)): datagrid_cpy.append(datapoint)

  except:
    gp_error("Error reading input datafile:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  if   (columns <  (no_arguments+1)):
    gp_error("Error: fit command needs %d columns of input data to fit a %d-parameter function."%(no_arguments+1,no_arguments))
    return # Error
  elif (columns == (no_arguments+1)): yerrors = 0
  elif (columns == (no_arguments+2)): yerrors = 1
  else:
   yerrors = 1
   gp_warning("Warning: Too many columns supplied to fit command. Taking 1=first argument, .... , %d=%s(...), %d=errorbar on function output."%(no_arguments+1,pass_function,no_arguments+2))

  pass_vialist = vialist
  pass_vars    = vars.copy()
  pass_funcs   = funcs
  pass_dataset = datagrid

  x = []
  for i in range(len(vialist)):
    if vialist[i] in pass_vars: x.append(pass_vars[vialist[i]]) # Use default value, if we have one
    else                      : x.append(1.0                  )          # otherwise use 1.0 as our starting value

  try:
    x = fmin(fit_residual, x)
  except:
    gp_error("Numerical Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
    return # Error

  print "Best fit parameters were:"
  for i in range(len(vialist)): # Set via variables
    o = x[i]
    if ((fabs(o) < 1e10) and (fabs(o) > 1e-6)): print "%s = %f"%(vialist[i],o)
    else:                                       print "%s = %e"%(vialist[i],o)
    vars[vialist[i]] = x[i]

  return # Done!!!

