# GP_MATH.PY
# Dominic Ford
# 27/06/2006

# Mathematical tools used in pyxplot

from gp_error import *

# RASTER MAKING FUNCTIONS

# LINRAST()
# LOGRAST(): Linear and log rasters, used for evaluating functions

def linrast( xmin, xmax, steps):
    return [ xmin + i* float(xmax-xmin)/steps for i in range(steps+1) ]
    
def lograst ( xmin , xmax , nsteps):
    if (xmin <= 0.0):
     gp_warning("Warning: Minimum end of logarithmic axis range is trying to expand to negative ordinates. Setting new minimum for axis range to 1e-6.")
     xmin = 1e-6
    if (xmax <= 0.0):
     gp_warning("Warning: Maximum end of logarithmic axis range is trying to expand to negative ordinates. Setting new maximum for axis range to 1.0.")
     xmax = 1.0
    return [ xmin * (xmax / xmin ) ** ( float(i)/nsteps ) for i in range(nsteps+1) ]

# MIN / MAX -- Return the largest / smallest of two numbers
# Used for working out range of axes which may possibly be inverted

def min(first, second):
 if ((first == None) or (second == None) or (first < second)): return first
 return second

def max(first, second):
 if ((first == None) or (second == None) or (first < second)): return second
 return first
