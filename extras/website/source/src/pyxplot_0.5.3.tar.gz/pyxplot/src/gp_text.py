# GP_TEXT.PY
# Dominic Ford
# 27/06/2006

# Contains text messages which pyxplot displays

import gp_version # Version and date strings written by installer

VERSION = gp_version.VERSION
DATE    = gp_version.DATE

version = r"""PyXPlot """+VERSION

help = r"""Usage: pyxplot <options> <filelist>
  -h, --help:    Display this help
  -v, --version: Display version number
PyXPlot """+VERSION

init = r"""
 ____       __  ______  _       _      PYXPLOT
|  _ \ _   _\ \/ /  _ \| | ___ | |_    Version """+VERSION+r"""
| |_) | | | |\  /| |_) | |/ _ \| __|   """+DATE+r"""
|  __/| |_| |/  \|  __/| | (_) | |_
|_|    \__, /_/\_\_|   |_|\___/ \__|   Copyright (C) 2006 Dominic Ford
       |___/

With thanks to Joerg Lehmann and Andre Wobst for writing PyX, and to
Ross Church for his many helpful suggestions along the way.

Send comments, bug reports, feature requests and coffee supplies to:
<dcf21@mrao.cam.ac.uk>
"""

invalid = r"""
         ^
         invalid command
"""

valid_set_options = r"""
'arrow', 'autoscale', 'axescolour', 'backup', 'bar', 'boxwidth', 'boxfrom',
'data style', 'dpi', 'fontsize', 'function style', 'grid', 'gridmajcolour',
'gridmincolour', 'key', 'label', 'linestyle', 'logscale', 'multiplot',
'noarrow', 'nogrid', 'nokey', 'nolabel', 'nolinestyle', 'nologscale',
'nomultiplot', 'notitle', 'origin', 'palette', 'pointlinewidth', 'pointsize',
'samples', 'size', 'size noratio', 'size square', 'size ratio', 'terminal',
'textcolour', 'title', 'width', '[xyz]<n>label', '[xyz]<n>range'
"""

valid_show_options = r"""
'autoscale', 'axescolour', 'backup', 'bar', 'boxwidth', 'boxfrom', 'data
style', 'dpi', 'fontsize', 'function style', 'grid', 'gridmajcolour',
'gridmincolour', 'key', 'label', 'linestyle', 'logscale', 'multiplot',
'origin', 'palette', 'pointlinewidth', 'pointsize', 'samples', 'size',
'terminal', 'textcolour', 'title', 'width'
"""

set = r"""
            ^
         invalid set option.

Set options which PyXPlot recognises are: [] = choose one, <> = optional
"""+valid_set_options+"""
Set options from gnuplot which PyXPlot DOES NOT recognise:

'angles', 'border', 'clabel', 'clip', 'cntrparam', 'colorbox', 'contour',
'decimalsign', 'dgrid3d', 'dummy', 'encoding', 'format', 'hidden3d',
'historysize', 'isosamples', 'locale', '[blrt]margin', 'mapping', 'mouse',
'offsets', 'parametric', 'pm3d', 'polar', 'print', '[rtuv]range', 'style',
'surface', 'tics', 'ticscale', 'ticslevel', 'timestamp', 'timefmt', 'view',
'[xyz]{2}data', '{no}{m}[xyz]{2}tics', '[xyz]{2}[md]tics',
'{[xyz]{2}}zeroaxis', 'zero'
"""

unset = r"""
            ^
         invalid unset option.

Unset options which PyXPlot recognises are: [] = choose one, <> = optional

'arrow', 'autoscale', 'axescolour', 'axis', 'boxwidth', 'boxfrom', 'dpi',
'fontsize', 'grid', 'gridmajcolour', 'gridmincolour', 'key', 'label',
'linestyle', 'logscale', 'multiplot', 'nokey', 'nologscale', 'origin',
'pointlinewidth', 'pointsize', 'samples', 'size', 'terminal', 'textcolour',
'title', 'width', '[xyz]<n>label', '[xyz]<n>range'
"""

show = r"""
             ^
Valid 'show' options are:

'all', 'arrows', 'axes', 'settings', 'labels', 'linestyles', 'variables',
'functions'

or any of the following set options:
"""+valid_show_options
