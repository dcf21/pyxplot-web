# manpage.py
# Dominic Ford
# 12/11/2006

import sys

docpath     = sys.argv[1]
author      = open("AUTHORS","r").read()
description = ""

f = open("README","r")
state = 0
for line in f.readlines():
 if   (line[0:2] == "1."): state = 1
 elif (line[0:2] == "2."): state = 2
 elif (state == 1)       : description += line

sys.stdout.write("""
.\" pyxplot.man
.\" Dominic Ford
.\" 12/11/2006

.\" Man page for pyxplot

.TH PYXPLOT 1
.SH NAME
pyxplot \- a commandline plotting package, with interface similar to that of
gnuplot, which produces publication-quality output.
.SH SYNOPSIS
.B pyxplot
[file ...]
.SH DESCRIPTION
%s
Full documentation can be found in:
%s
.SH AUTHOR
%s.
.SH CREDITS
Thanks to Joerg Lehmann and Andre Wobst for writing the PyX graphics library
for python, upon which this software is heavily built, and also to Ross Church
for his many useful comments and suggestions during its development.
.SH "SEE ALSO"
.BR gnuplot (1)
"""%(description,docpath,author))
