VERSION='0.5.8'
DATE='09/09/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
