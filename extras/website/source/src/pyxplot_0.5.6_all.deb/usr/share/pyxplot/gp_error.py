# GP_ERROR.PY
# Dominic Ford
# 18/08/2006

# Error handler

import sys
import traceback

# Print traceback on error?

DEBUG = False

# Colour error messages?
# These options are overwritten in gp_settings

gp_termcol     = False
gp_termcol_err = gp_termcol_wrn = gp_termcol_rep = "Normal"

def gp_error_setnocolour():  global gp_termcol     ; gp_termcol     = False
def gp_error_setcolour():    global gp_termcol     ; gp_termcol     = True
def gp_error_setrepcol(col): global gp_termcol_rep ; gp_termcol_rep = col
def gp_error_setwrncol(col): global gp_termcol_wrn ; gp_termcol_wrn = col
def gp_error_seterrcol(col): global gp_termcol_err ; gp_termcol_err = col

# We import this here, as gp_settings actually uses the above functions, so we need to define them first!
import gp_settings

# A fairly minimal error handler, which sends error messages to stderr
# and report messages to stdout

def gp_error(*text):
  print_item = ""
  for item in text: print_item += str(item)+" "
  if gp_termcol and sys.stderr.isatty():
    print_item = gp_settings.terminal_colours[gp_termcol_err] + print_item + gp_settings.terminal_colours["Normal"]
  sys.stderr.write(print_item+"\n")
  if DEBUG: traceback.print_stack(limit=2)

def gp_warning(*text):
  print_item = ""
  for item in text: print_item += str(item)+" "
  if gp_termcol and sys.stderr.isatty():
    print_item = gp_settings.terminal_colours[gp_termcol_wrn] + print_item + gp_settings.terminal_colours["Normal"]
  sys.stderr.write(print_item+"\n")

def gp_report(*text):
  print_item = ""
  for item in text: print_item += str(item)+" "
  if gp_termcol and sys.stdout.isatty():
    print_item = gp_settings.terminal_colours[gp_termcol_rep] + print_item + gp_settings.terminal_colours["Normal"]
  sys.stdout.write(print_item+"\n")
