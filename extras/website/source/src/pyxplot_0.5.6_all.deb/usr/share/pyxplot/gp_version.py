VERSION='0.5.6'
DATE='18/08/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
