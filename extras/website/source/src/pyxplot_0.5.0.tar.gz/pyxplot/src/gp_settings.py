# GP_SETTINGS.PY
# Dominic Ford
# 27/05/2006

import os
import sys
import glob
import stat
import ConfigParser
import pyx

import gp_eval

#
# CONFIGURATION FILE HANDLING
#

# Check for settings in configuration files .pyxplotrc in c.w.d. or user's homespace
config_list = [".pyxplotrc",  os.path.expanduser("~/.pyxplotrc")]

try:
 config_files = ConfigParser.ConfigParser()
 config_files.read(config_list)
except:
 config_files = None
 print "Warning: Could not parse configuration file -- missing section heading, perhaps?"

# CONFIG_LOOKUP_FOO(): Check for entry [section,option] in configuration file.
# If not found, return default.

def config_lookup_str(section, option, default):
 try   : return config_files.get(section, option)
 except: return default

def config_lookup_float(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return float(value)
 except:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be floating point."%(value, section, option)
  return default

def config_lookup_int(section, option, default):
 try   : value = config_files.get(section, option)
 except: return default
 try   : return int(value)
 except:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be an integer."%(value, section, option)
  return default

def config_lookup_opt(section, option, default, options):
 try   : value = config_files.get(section, option)
 except: return default
 if (value in options): return value
 else:
  print"Warning: Value '%s' for [%s,%s] in configuration file should be one of options %s."%(value, section, option, options)
  return default

# Make a dictionary of PyX colours called pyx_colours

pyx_colours={
"GreenYellow":pyx.color.cmyk.GreenYellow,
"Yellow":pyx.color.cmyk.Yellow,
"Goldenrod":pyx.color.cmyk.Goldenrod,
"Dandelion":pyx.color.cmyk.Dandelion,
"Apricot":pyx.color.cmyk.Apricot,
"Peach":pyx.color.cmyk.Peach,
"Melon":pyx.color.cmyk.Melon,
"YellowOrange":pyx.color.cmyk.YellowOrange,
"Orange":pyx.color.cmyk.Orange,
"BurntOrange":pyx.color.cmyk.BurntOrange,
"Bittersweet":pyx.color.cmyk.Bittersweet,
"RedOrange":pyx.color.cmyk.RedOrange,
"Mahogany":pyx.color.cmyk.Mahogany,
"Maroon":pyx.color.cmyk.Maroon,
"BrickRed":pyx.color.cmyk.BrickRed,
"Red":pyx.color.cmyk.Red,
"OrangeRed":pyx.color.cmyk.OrangeRed,
"RubineRed":pyx.color.cmyk.RubineRed,
"WildStrawberry":pyx.color.cmyk.WildStrawberry,
"Salmon":pyx.color.cmyk.Salmon,
"CarnationPink":pyx.color.cmyk.CarnationPink,
"Magenta":pyx.color.cmyk.Magenta,
"VioletRed":pyx.color.cmyk.VioletRed,
"Rhodamine":pyx.color.cmyk.Rhodamine,
"Mulberry":pyx.color.cmyk.Mulberry,
"RedViolet":pyx.color.cmyk.RedViolet,
"Fuchsia":pyx.color.cmyk.Fuchsia,
"Lavender":pyx.color.cmyk.Lavender,
"Thistle":pyx.color.cmyk.Thistle,
"Orchid":pyx.color.cmyk.Orchid,
"DarkOrchid":pyx.color.cmyk.DarkOrchid,
"Purple":pyx.color.cmyk.Purple,
"Plum":pyx.color.cmyk.Plum,
"Violet":pyx.color.cmyk.Violet,
"RoyalPurple":pyx.color.cmyk.RoyalPurple,
"BlueViolet":pyx.color.cmyk.BlueViolet,
"Periwinkle":pyx.color.cmyk.Periwinkle,
"CadetBlue":pyx.color.cmyk.CadetBlue,
"CornflowerBlue":pyx.color.cmyk.CornflowerBlue,
"MidnightBlue":pyx.color.cmyk.MidnightBlue,
"NavyBlue":pyx.color.cmyk.NavyBlue,
"RoyalBlue":pyx.color.cmyk.RoyalBlue,
"Blue":pyx.color.cmyk.Blue,
"Cerulean":pyx.color.cmyk.Cerulean,
"Cyan":pyx.color.cmyk.Cyan,
"ProcessBlue":pyx.color.cmyk.ProcessBlue,
"SkyBlue":pyx.color.cmyk.SkyBlue,
"Turquoise":pyx.color.cmyk.Turquoise,
"TealBlue":pyx.color.cmyk.TealBlue,
"Aquamarine":pyx.color.cmyk.Aquamarine,
"BlueGreen":pyx.color.cmyk.BlueGreen,
"Emerald":pyx.color.cmyk.Emerald,
"JungleGreen":pyx.color.cmyk.JungleGreen,
"SeaGreen":pyx.color.cmyk.SeaGreen,
"Green":pyx.color.cmyk.Green,
"ForestGreen":pyx.color.cmyk.ForestGreen,
"PineGreen":pyx.color.cmyk.PineGreen,
"LimeGreen":pyx.color.cmyk.LimeGreen,
"YellowGreen":pyx.color.cmyk.YellowGreen,
"SpringGreen":pyx.color.cmyk.SpringGreen,
"OliveGreen":pyx.color.cmyk.OliveGreen,
"RawSienna":pyx.color.cmyk.RawSienna,
"Sepia":pyx.color.cmyk.Sepia,
"Brown":pyx.color.cmyk.Brown,
"Tan":pyx.color.cmyk.Tan,
"Gray":pyx.color.cmyk.Gray,
"Grey":pyx.color.cmyk.Grey,
"Black":pyx.color.cmyk.Black,
"White":pyx.color.cmyk.White,
"white":pyx.color.cmyk.white,
"black":pyx.color.cmyk.black,
"Grey10":pyx.color.gray(0.1),
"Grey20":pyx.color.gray(0.2),
"Grey30":pyx.color.gray(0.3),
"Grey40":pyx.color.gray(0.4),
"Grey50":pyx.color.gray(0.5),
"Grey60":pyx.color.gray(0.6),
"Grey70":pyx.color.gray(0.7),
"Grey80":pyx.color.gray(0.8),
"Grey90":pyx.color.gray(0.9)
}

# Available options for different data types

datastyles = ['points','lines','linespoint','xerrorbars','yerrorbars','xyerrorbars','xerrorrange','yerrorrange','xyerrorrange','dots','impulses','boxes','wboxes','steps','fsteps','histeps']
onoff      = ['ON', 'OFF']
termtypes  = ['X11_singlewindow','X11_multiwindow','eps','png','jpg','gif']
keyposes   = ["TOP RIGHT","TOP MIDDLE","TOP LEFT","MIDDLE RIGHT","MIDDLE MIDDLE","MIDDLE LEFT","BOTTOM RIGHT","BOTTOM MIDDLE","BOTTOM LEFT","BELOW","OUTSIDE"]
fontsizes  = [-4, -3, -2, -1, 0, 1, 2, 3, 4, 5]
colours    = pyx_colours.keys()

#
# DEFAULT PALLETTE
#

colour_list_default = ['Black', 'Red', 'Blue', 'Magenta', 'Cyan', 'Brown', 'Salmon', 'Gray', 'Green', 'NavyBlue', 'Periwinkle', 'PineGreen', 'SeaGreen', 'GreenYellow', 'Orange', 'CarnationPink', 'Plum' ]
colour_list = colour_list_default

#
# DEFAULT LINESTYLES AND POINTSTYLES
#

symbol_list = [pyx.graph.style.symbol.cross, pyx.graph.style.symbol.plus, pyx.graph.style.symbol.square, pyx.graph.style.symbol.triangle, pyx.graph.style.symbol.circle, pyx.graph.style.symbol.diamond]

linestyle_list = [pyx.style.linestyle.solid, pyx.style.linestyle.dashed, pyx.style.linestyle.dotted, pyx.style.linestyle.dashdotted, pyx.style.dash((3,2,1,1,1,2),0), pyx.style.dash((3,1,1,3,1,1),0), pyx.style.dash((3,1,3,1,3,1),0), pyx.style.dash((4,4),0)]

# Now set default options, using configuration file settings as overide if present

settings_default = {'ORIGINX'        :config_lookup_float('settings','ORIGINX'        ,0.0                          ) ,
                    'ORIGINY'        :config_lookup_float('settings','ORIGINY'        ,0.0                          ) ,
                    'MULTIPLOT'      :config_lookup_opt  ('settings','MULTIPLOT'      ,'OFF'             ,onoff     ) ,
                    'TITLE'          :config_lookup_str  ('settings','TITLE'          ,''                           ) ,
                    'TIT_XOFF'       :config_lookup_float('settings','TIT_XOFF'       ,0.0                          ) , # x offset of title
                    'TIT_YOFF'       :config_lookup_float('settings','TIT_YOFF'       ,0.0                          ) ,
                    'TERMTYPE'       :config_lookup_opt  ('settings','TERMTYPE'       ,'X11_singlewindow',termtypes ) ,
                    'OUTPUT'         :config_lookup_str  ('settings','OUTPUT'         ,''                           ) ,
                    'ENHANCED'       :config_lookup_opt  ('settings','ENHANCED'       ,'ON'              ,onoff     ) , # Enhanced (encapsulated) ps?
                    'LANDSCAPE'      :config_lookup_opt  ('settings','LANDSCAPE'      ,'OFF'             ,onoff     ) , # Landscape noeps postscript?
                    'TERMINVERT'     :config_lookup_opt  ('settings','TERMINVERT'     ,'OFF'             ,onoff     ) , # Inverted colour image output?
                    'TERMTRANSPARENT':config_lookup_opt  ('settings','TERMTRANSPARENT','OFF'             ,onoff     ) , # Image output transparent?
                    'DPI'            :config_lookup_float('settings','DPI'            ,300.0                        ) , # DPI of bitmap graphics output.
                    'WIDTH'          :config_lookup_float('settings','WIDTH'          ,8.0                          ) , # Width of output / cm
                    'ASPECT'         :config_lookup_float('settings','ASPECT'         ,1.0                          ) , # Aspect ratio of plot
                    'AUTOASPECT'     :config_lookup_opt  ('settings','AUTOASPECT'     ,'ON'              ,onoff     ) , # Use PyX default aspect ratio
                    'POINTSIZE'      :config_lookup_float('settings','POINTSIZE'      ,1.0                          ) , # Default pointsize
                    'POINTLINEWIDTH' :config_lookup_float('settings','POINTLINEWIDTH' ,1.0             ) , # Default linewidth used for drawing points
                    'LINEWIDTH'      :config_lookup_float('settings','LINEWIDTH'      ,1.0                          ) , # Default linewidth
                    'FONTSIZE'       :config_lookup_opt  ('settings','FONTSIZE'       ,0                 ,fontsizes ) , # Font size (-4 < i < 5)
                    'TEXTCOLOUR'     :config_lookup_opt  ('settings','TEXTCOLOUR'     ,'Black'           ,colours   ) ,
                    'AXESCOLOUR'     :config_lookup_opt  ('settings','AXESCOLOUR'     ,'Black'           ,colours   ) ,
                    'GRIDMAJCOLOUR'  :config_lookup_opt  ('settings','GRIDMAJCOLOUR'  ,'Grey60'          ,colours   ) ,
                    'GRIDMINCOLOUR'  :config_lookup_opt  ('settings','GRIDMINCOLOUR'  ,'Grey90'          ,colours   ) ,
                    'DATASTYLE'      :config_lookup_opt  ('settings','DATASTYLE'      ,'points'          ,datastyles) ,
                    'FUNCSTYLE'      :config_lookup_opt  ('settings','FUNCSTYLE'      ,'lines'           ,datastyles) ,
                    'SAMPLES'        :config_lookup_int  ('settings','SAMPLES'        ,250                          ) ,
                    'COLOUR'         :config_lookup_opt  ('settings','COLOUR'         ,'ON'              ,onoff     ) ,
                    'KEY'            :config_lookup_opt  ('settings','KEY'            ,'ON'              ,onoff     ) ,
                    'KEYPOS'         :config_lookup_opt  ('settings','KEYPOS'         ,'TOP RIGHT'       ,keyposes  ) ,
                    'KEY_XOFF'       :config_lookup_float('settings','KEY_XOFF'       ,0.0                          ) ,
                    'KEY_YOFF'       :config_lookup_float('settings','KEY_YOFF'       ,0.0                          ) ,
                    'GRID'           :config_lookup_opt  ('settings','GRID'           ,'OFF'             ,onoff     ) ,
                    'GRIDAXISX'      :[config_lookup_int  ('settings','GRIDAXISX'      ,1                            ) ],
                    'GRIDAXISY'      :[config_lookup_int  ('settings','GRIDAXISY'      ,1                            ) ],
                    'BOXWIDTH'       :config_lookup_float('settings','BOXWIDTH'       ,0.0                          ) ,
                    'BOXFROM'        :config_lookup_float('settings','BOXFROM'        ,0.0                          ) ,
                    }

default_axis = {'LABEL'    :'',
                'MIN'      : None,
                'MAX'      : None,
                'LOG'      :'OFF'}

linestyles = {} # User-defined linestyles
arrows     = {} # Arrows superposed on figure
labels     = {} # Text labels

variables  = {'pi':3.1415928} # User-defined variables
functions  = {}               # User-defined functions

# NOW IMPORT FUNCTIONS FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('functions'):
  try:
    functions[preconfigvar[0]] = preconfigvar[1]
  except:
    print "Warning: Unexpected error importing function %s from configuration file."%(preconfigvar[0])
except:
 pass # Ignore if no functions section 


# NOW IMPORT VARIABLES FROM CONFIGURATION FILE

try:
 for preconfigvar in config_files.items('variables'):
  try:
    variables[preconfigvar[0]] = gp_eval.gp_eval(preconfigvar[1], variables, functions)
  except:
    print "Warning: Expression '%s' for variable %s in configuration file could not be evaluated."%(preconfigvar[0],preconfigvar[1])
except:
 pass # Ignore if no variables section 

# NOW IMPORT COLOURS FROM CONFIGURATION FILE

colours_in  = config_lookup_str('colours','PALLETTE','')
if (colours_in != ""):
 colours_in  = colours_in.split(',')
 colours_new = []
 for colour in colours_in:
  if (colour.strip() in colours): colours_new.append(colour.strip())
  else                          : print "Unrecognised colour '%s' in configuration file pallette; skipping."%colour.strip()
 if (len(colours_new) == 0):
  print "No colours found in configuration file pallette; reverting to default pallette."
 else:
  colour_list = colours_new

# Now that we have default settings, make copy them into initial settings

settings = settings_default.copy()
settings['GRIDAXISX'] = settings_default['GRIDAXISX'][:]
settings['GRIDAXISY'] = settings_default['GRIDAXISY'][:]

# By default, have one of each kind of axis... x1, y1 and z1
axes = {'x':{1:default_axis.copy()},
        'y':{1:default_axis.copy()},
        'z':{1:default_axis.copy()} }

# STORAGE OF DIRECTORY PATHS

# User's cwd, which we store here before setting cwd to a temporary folder for the duration of our activities
cwd = ""

# Make a directory into which we put temporary files
tempdirnumber = 1
file_paths=['foo']
while (len(file_paths) != 0): # Take care not to overright a pre-existing file in /tmp
 tempdirnumber = tempdirnumber + 1
 tempdir = "/tmp/gp+_" + str(os.getpid()) + "_" + str(tempdirnumber)
 file_paths=glob.glob(tempdir)
os.mkdir(tempdir)
if ((not os.path.isdir(tempdir)) or (not (os.stat(tempdir)[stat.ST_UID] == os.getuid()))):
 print "Fatal Error: Security error whilst trying to create temporary directory"
 sys.exit(0)

