# GP_SETTINGS.PY
# Dominic Ford
# 26/02/2006

settings = {'TITLE':'',
            'TERMTYPE':'X11',
            'OUTPUT':'gnuplot.eps',
            'WIDTH':8,             # Width of output / cm
            'POINTSIZE':1,
            'DATASTYLE':'points',
            'FUNCSTYLE':'lines',
            'SAMPLES':250,
            'COLOUR':'ON',
            'KEY':'ON',
            'KEYPOS':'TOP RIGHT',
            'GRID':'OFF'}

default_axis = {'LABEL':'',
                'AUTOSCALE':'ON',
                'MIN':-10.0,
                'MAX':10.0,
                'LOG':'OFF'}

# x,x2,y,y2,z,z2
axes = [default_axis.copy(), default_axis.copy(), default_axis.copy(), default_axis.copy(), default_axis.copy(), default_axis.copy()]

linestyles = {} # User-defined linestyles
arrows     = {} # Arrows superposed on figure
labels     = {} # Text labels

variables  = {'pi':3.1415928} # User-defined variables
functions  = {}               # User-defined functions
