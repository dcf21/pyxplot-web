# GNUPLOT+.PY
# Dominic Ford
# 26/02/2006

VERSION = "0.1.0"
DATE    = "26/02/2006"

exitting = 0

import gp_settings
import gp_eval
import gp_fit
import gp_plot

import os
import sys
import readline
from math import *
import re

# FLOATPRINT(): Prints a float in floating point or exponential format, as appropriate

def floatprint(x):
  if ((fabs(x) < 1e10) and (fabs(x) > 1e-6)): return "%f"%x
  else:                                       return "%e"%x

# READ_COORD_SYST(): Read screen, graph, first or second modifiers

def read_coord_syst(string):
  if  ((string == None) or (len(string) == 0) or
       (re.match(r'^first' ,string) != None)): return 'first'
  elif (re.match(r'^second',string) != None) : return 'second'
  elif (re.match(r'^graph' ,string) != None) : return 'graph'
  elif (re.match(r'^screen',string) != None) : return 'screen'
  else:
    print string
    raise UserIsAFuckwitError

# Directive Show

def directive_show(line,linelist):
  if (len(linelist) > 1):
   if ((linelist[1] == "settings") or (linelist[1] == "all")):
    print "Plot Title:   '%s'"%gp_settings.settings['TITLE']
    print "Terminal type: %s"%gp_settings.settings['TERMTYPE']
    print "Output fname:  %s"%gp_settings.settings['OUTPUT']
    print "Output width:  %s"%gp_settings.settings['WIDTH']
    print "Colour:        %s"%gp_settings.settings['COLOUR']
    print "Key:           %s"%gp_settings.settings['KEY']
    print "Key position:  %s corner"%gp_settings.settings['KEYPOS']
    print "Grid:          %s"%gp_settings.settings['GRID']
    print "Pointsize:     %f"%gp_settings.settings['POINTSIZE']
    print

   if ((linelist[1] == "plotting") or (linelist[1] == "all")):
    print "Data style:    %s"%gp_settings.settings['DATASTYLE']
    print "Function style:%s"%gp_settings.settings['FUNCSTYLE']
    print "Samples        %d (no of samples used when plotting functions)"%gp_settings.settings['SAMPLES']
    print

   if ((linelist[1] == "linestyle") or (linelist[1] == "all")):
    print "Linestyles:\n"
    for i,definition in gp_settings.linestyles.iteritems():
      print "  linestyle %d: %s"%(i,definition)
    print

   if ((linelist[1] == "arrow") or (linelist[1] == "all")):
    print "Arrows:\n"
    for i,definition in gp_settings.arrows.iteritems():
      print "  arrow %d: (%s %s,%s %s) to (%s %s,%s %s) %s"%(i, definition[0], floatprint(definition[1]), definition[2], floatprint(definition[3]), definition[4], floatprint(definition[5]), definition[6], floatprint(definition[7]), definition[8])
    print

   if ((linelist[1] == "label") or (linelist[1] == "all")):
    print "Text labels:\n"
    for i,definition in gp_settings.labels.iteritems():
      print "  label %d: %s at (%s %s,%s %s)"%(i, definition[0], definition[1], floatprint(definition[2]), definition[3], floatprint(definition[4]))
    print

   if ((linelist[1] == "axes") or (linelist[1] == "all")):
    for (i,name) in ((0,'x'),(1,'x2'),(2,'y'),(3,'y2'),(4,'z'),(5,'z2')):
      print "Setting for %s axis:"%name
      print "  Label:     %s"%gp_settings.axes[i]['LABEL']
      print "  Autoscale: %s"%gp_settings.axes[i]['AUTOSCALE']
      print "  Range:    (%s --> %s)"%(floatprint(gp_settings.axes[i]['MIN']), floatprint(gp_settings.axes[i]['MAX']))
      print "  Log:       %s"%gp_settings.axes[i]['LOG']
      print

   if ((linelist[1] == "vars") or (linelist[1] == "variables") or (linelist[1] == "all")):
    print "Variables:"
    for x,y in gp_settings.variables.iteritems():
      print "%s = %s"%(x,floatprint(y))

    print
    print "User-Defined Functions:"
    for x,y in gp_settings.functions.iteritems():
      print "%s = %s"%(x,y)
    print

   if ((linelist[1] == "arrow") or (linelist[1] == "vars") or (linelist[1] == "variables") or (linelist[1] == "all") or (linelist[1] == "axes") or (linelist[1] == "plotting") or (linelist[1] == "label") or (linelist[1] == "linestyle") or (linelist[1] == "settings")):
    return
  os.system("cat %s/txt/show.txt"%PATH)
  return

# Directive Set

def directive_set(line,linelist):
    done = 0
    if (len(linelist) < 2):
      os.system("cat %s/txt/set.txt"%PATH)
      return

    if (re.match(r'^title',linelist[1]) != None): # set title
      test = re.match(r"""^set?\s*title\s*('|")(.*)('|")""",line)
      if (test == None):
        print "Title should be placed in quotes. Defaulting to blank title"
        gp_settings.settings['TITLE']=""
      else:
        gp_settings.settings['TITLE']=test.group(2)
      return

    if (re.match(r'^width',linelist[1]) != None): # set width # EXTENDED API
      test = re.match(r"""^set?\s*width\s*(.*)""",line)
      if (test == None):
        print "Error reading width."
      else:
        try:
          gp_settings.settings['WIDTH']=float(test.group(1))
        except:
          print "Could not read width. Should be a floating point value"
      return

    if (re.match(r'^samples',linelist[1]) != None): # set samples
      test = re.match(r"""^set?\s*samples\s*(.*)""",line)
      if (test == None):
        print "Error reading number of samples."
      else:
        try:
          gp_settings.settings['SAMPLES']=int(test.group(1))
        except:
          print "Could not read number of samples. Should be an integer value"
      return

    if (re.match(r'^pointsize',linelist[1]) != None): # set pointsize
      test = re.match(r"""^set?\s*pointsize\s*(.*)""",line)
      if (test == None):
        print "Error reading pointsize"
      else:
        try:
          gp_settings.settings['POINTSIZE']=float(test.group(1))
        except:
          print "Could not reading pointsize. Should be a floating point value"
      return

    if (re.match(r'^linestyle',linelist[1]) != None): # set linestyle
      test = re.match(r"""^set?\s*linestyle\s*([0-9][0-9]*)\s*(.*)""",line)
      if (test == None):
        print "Error reading linestyle. Use format: set linestyle <number> <linestyle>"
      else:
        try:
          ls_number = int(test.group(1))
        except:
          print "linestyle number must be specified as an integer"
          return
        try:
          gp_settings.linestyles[ls_number] = test.group(2)
        except:
          print "Unexpected error whilst writing linestyle %d"%ls_number
      return

    if (re.match(r'^nolinestyle',linelist[1]) != None): # set nolinestyle
      test = re.match(r"""^set?\s*nolinestyle\s*([0-9][0-9]*)""",line)
      if (test == None):
        print "Error reading nolinestyle. Use format: set nolinestyle <number>"
      else:
        try:
          ls_number = int(test.group(1))
        except:
          print "linestyle number must be specified as an integer."
          return
        try:
          del gp_settings.linestyles[ls_number] # Delete key from linestyle dictionary
        except:
          print "Error removing linestyle %d -- no such linestyle."%ls_number
      return

    if (re.match(r'^arrow',linelist[1]) != None): # set arrow
      try:
        gc=r"(([a-z]*)\s\s*)?([^,\s][^,\s]*)" # get coordinate -- matches, e.g. "first 7.5"
        nc=r"[,\s][,\s]*" # next coordinate -- matches commas and spaces
        test = re.match(r"^set?\s\s*arrow\s\s*([0-9][0-9]*)\s\s*from\s\s*"+gc+nc+gc+"\s\s*to\s\s*"+gc+nc+gc+"\s*(\S*)\s*$""",line)
        arrow_number = int(test.group(1))
        coord0x      = read_coord_syst(test.group(3))
        x0           = float(test.group(4))
        coord0y      = read_coord_syst(test.group(6))
        y0           = float(test.group(7))
        coord1x      = read_coord_syst(test.group(9))
        x1           = float(test.group(10))
        coord1y      = read_coord_syst(test.group(12))
        y1           = float(test.group(13))
        if ((len(test.group(14)) == 0) or
             (re.match(r'head',test.group(14)) != None))   : arrow_style = "head"
        elif (re.match(r'nohead'  ,test.group(14)) != None): arrow_style = "nohead"
        elif (re.match(r'twoway',test.group(14)) != None)  : arrow_style = "twoway"                      
      except:
        print "Error reading arrow. Use format: set arrow from (first|second|screen|graph) x y to (first|second|screen|graph) x y"
        return
      try:
        gp_settings.arrows[arrow_number] = (coord0x, x0, coord0y, y0, coord1x, x1, coord1y, y1, arrow_style)
      except:
        print "Unexpected error whilst writing arrow %d"%arrow_number
      return

    if (re.match(r'^noarrow',linelist[1]) != None): # set noarrow
      test = re.match(r"""^set?\s*noarrow\s*([0-9][0-9]*)""",line)
      if (test == None):
        print "Error reading noarrow. Use format: set noarrow <number>"
      else:
        try:
          arrow_number = int(test.group(1))
        except:
          print "arrow number must be specified as an integer."
          return
        try:
          del gp_settings.arrows[arrow_number] # Delete key from linestyle dictionary
        except:
          print "Error removing arrow %d -- no such arrow."%arrow_number
      return

    if (re.match(r'^grid',linelist[1]) != None):   # set grid
      gp_settings.settings['GRID']='ON'
      return
    if (re.match(r'^nogrid',linelist[1]) != None): # set nogrid
      gp_settings.settings['GRID']='OFF'
      return

    if (re.match(r'^label',linelist[1]) != None):  # set label
      try:
        gc=r"(([a-z]*)\s\s*)?([^,\s][^,\s]*)" # get coordinate -- matches, e.g. "first 7.5"
        nc=r"[,\s][,\s]*" # next coordinate -- matches commas and spaces
        test = re.match(r"""^set?\s\s*label\s\s*([0-9][0-9]*)\s*('|")(.*)('|")\s\s*at\s\s*"""+gc+nc+gc+"\s*$""",line)
        label_number = int(test.group(1))
        text         =     test.group(3)
        coordx       = read_coord_syst(test.group(6))
        x            = float(test.group(7))
        coordy       = read_coord_syst(test.group(9))
        y            = float(test.group(10))
      except:
        print "Error reading label. Use format: set label <number> 'text' at (first|second|screen|graph) x (first|second|screen|graph) y"
        print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
        return
      try:
        gp_settings.labels[label_number] = (text, coordx, x, coordy, y)
      except:
        print "Unexpected error whilst writing label %d"%label_number
      return

    if (re.match(r'^nolabel',linelist[1]) != None): # set nolabel
      test = re.match(r"""^set?\s*nolabel\s*([0-9][0-9]*)""",line)
      if (test == None):
        print "Error reading nolabel. Use format: set nolabel <number>"
      else:
        try:
          label_number = int(test.group(1))
        except:
          print "label number must be specified as an integer."
          return
        try:
          del gp_settings.labels[label_number] # Delete key from label dictionary
        except:
          print "Error removing label %d -- no such label."%label_number
      return

    if (len(linelist) > 2):
      if ((re.match(r'^data',linelist[1]) != None) and (re.match(r'^style',linelist[2]) != None)): # Set data style
        test = re.match(r"""^set?\s*data\s*style\s*(.*)""",line)
        if ((test == None) or (len(test.group(1)) == 0)):
          print "Error reading data style"
        else:
          if ((test.group(1)[0] == 'l')                  and (re.match(test.group(1), "lines")        != None)): gp_settings.settings['DATASTYLE'] = 'lines'      ; return
          if ((test.group(1)[0] == 'p')                  and (re.match(test.group(1), "points")       != None)): gp_settings.settings['DATASTYLE'] = 'points'     ; return
          if ((test.group(1)    == 'lp')                                                                      ): gp_settings.settings['DATASTYLE'] = 'linespoints'; return
          if ((re.match("linesp",test.group(1)) != None) and (re.match(test.group(1), "linespoints")  != None)): gp_settings.settings['DATASTYLE'] = 'linespoints'; return
          if ((re.match("xe"    ,test.group(1)) != None) and (re.match(test.group(1), "xerrorbars")   != None)): gp_settings.settings['DATASTYLE'] = 'xerrorbars' ; return
          if ((re.match("ye"    ,test.group(1)) != None) and (re.match(test.group(1), "yerrorbars")   != None)): gp_settings.settings['DATASTYLE'] = 'yerrorbars' ; return
          if ((re.match("xy"    ,test.group(1)) != None) and (re.match(test.group(1), "xyerrorbars")  != None)): gp_settings.settings['DATASTYLE'] = 'xyerrorbars'; return
          print "Unknown data style '%s'"%test.group(1)
          return
      if ((re.match(r'^function',linelist[1]) != None) and (re.match(r'^style',linelist[2]) != None)): # Set function style
        test = re.match(r"""^set?\s*function\s*style\s*(.*)""",line)
        if ((test == None) or (len(test.group(1)) == 0)):
          print "Error reading function style"
        else:
          if ((test.group(1)[0] == 'l')                  and (re.match(test.group(1), "lines")        != None)): gp_settings.settings['FUNCSTYLE'] = 'lines'      ; return
          if ((test.group(1)[0] == 'p')                  and (re.match(test.group(1), "points")       != None)): gp_settings.settings['FUNCSTYLE'] = 'points'     ; return
          if ((test.group(1)    == 'lp')                                                                      ): gp_settings.settings['FUNCSTYLE'] = 'linespoints'; return
          if ((re.match("linesp",test.group(1)) != None) and (re.match(test.group(1), "linespoints")  != None)): gp_settings.settings['FUNCSTYLE'] = 'linespoints'; return
          if ((re.match("xe"    ,test.group(1)) != None) and (re.match(test.group(1), "xerrorbars")   != None)): gp_settings.settings['FUNCSTYLE'] = 'xerrorbars' ; return
          if ((re.match("ye"    ,test.group(1)) != None) and (re.match(test.group(1), "yerrorbars")   != None)): gp_settings.settings['FUNCSTYLE'] = 'yerrorbars' ; return
          if ((re.match("xy"    ,test.group(1)) != None) and (re.match(test.group(1), "xyerrorbars")  != None)): gp_settings.settings['FUNCSTYLE'] = 'xyerrorbars'; return
          print "Unknown function style '%s'"%test.group(1)
          return

    if (re.match(r'^output',linelist[1]) != None): # set output
      test = re.match(r"""^set?\s*output\s*('|")(.*)('|")""",line)
      if (test == None):
        print "Output filename should be placed in quotes."
      else:
        gp_settings.settings['OUTPUT']=test.group(2)
      return

    if (re.match(r'^key',linelist[1]) != None): # set key
      gp_settings.settings['KEY']='ON'
      for i in range(2,len(linelist),1):
        if (linelist[i] == "top"):    gp_settings.settings['KEYPOS'] = 'TOP '    + gp_settings.settings['KEYPOS'].split()[1] ; continue
        if (linelist[i] == "bottom"): gp_settings.settings['KEYPOS'] = 'BOTTOM ' + gp_settings.settings['KEYPOS'].split()[1] ; continue
        if (linelist[i] == "left"):   gp_settings.settings['KEYPOS'] = gp_settings.settings['KEYPOS'].split()[0] + ' LEFT'   ; continue
        if (linelist[i] == "right"):  gp_settings.settings['KEYPOS'] = gp_settings.settings['KEYPOS'].split()[0] + ' RIGHT'  ; continue
        print "Unrecognised word: %s"%linelist[i]
      return

    if (re.match(r'^nokey',linelist[1]) != None): # set nokey
      gp_settings.settings['KEY']='OFF'
      return

    if (re.match(r'^terminal',linelist[1]) != None): # set terminal
      for i in range(2,len(linelist),1):
        if (linelist[i] == "x11"):        gp_settings.settings['TERMTYPE'] = "X11" ; continue
        if (linelist[i] == "X11"):        gp_settings.settings['TERMTYPE'] = "X11" ; continue
        if (linelist[i] == "postscript"): gp_settings.settings['TERMTYPE'] = "EPS" ; continue
        if (linelist[i] == "eps"):        gp_settings.settings['TERMTYPE'] = "EPS" ; continue
        if (linelist[i] == "color"):      gp_settings.settings['COLOUR']   = "ON"  ; continue
        if (linelist[i] == "colour"):     gp_settings.settings['COLOUR']   = "ON"  ; continue
        if (linelist[i] == "monochrome"): gp_settings.settings['COLOUR']   = "OFF" ; continue
        print "Unrecognised word: %s"%linelist[i]
      return

    for (i,name) in ((0,'x'),(1,'x2'),(2,'y'),(3,'y2'),(4,'z'),(5,'z2')):
      if (re.match('^%slabel'%name,linelist[1]) != None): # set label
        test = re.match("""^set?\s*%slabel\s*('|")(.*)('|")"""%name,line)
        if (test == None):
          print "Label should be placed in quotes. Defaulting to blank title"
          gp_settings.axes[i]['LABEL']=""
        else:
          gp_settings.axes[i]['LABEL']=test.group(2)
        return

      if (re.match('^log',linelist[1]) != None): # set log
        if (len(linelist)>2):
          test = re.search("""%s(2?)"""%name,linelist[2])
          if ((test != None) and (len(test.group(1)) == 0)):
            gp_settings.axes[i]['LOG']="ON"
            done=1

      if (re.match('^nolog',linelist[1]) != None): # set nolog
        if (len(linelist)>2):
          test = re.search("""%s(2?)"""%name,linelist[2])
          if ((test != None) and (len(test.group(1)) == 0)):
            gp_settings.axes[i]['LOG']="OFF"
            done=1

      if (re.match('^autoscale',linelist[1]) != None): # set autoscale (equivalent to 'set arange restore')
        if (len(linelist)>2):
          test = re.search("""%s(2?)"""%name,linelist[2])
          if ((test != None) and (len(test.group(1)) == 0)):
            gp_settings.axes[i]['AUTOSCALE']="ON"
            done=1

      if (re.match('^%srange'%name,linelist[1]) != None): # set range
        test = re.match("""^set?\s*%srange\s*restore"""%name,line)
        if (test != None):
          gp_settings.axes[i]['AUTOSCALE']='ON'
          return
        test = re.match("""^set?\s*%srange\s*\[(.*)((:)|( *to *))(.*)\]"""%name,line)
        if (test == None):
          print "Could not read range. Use format: set xrange [0:1]."
        else:
          try:
            gp_settings.axes[i]['AUTOSCALE']='OFF'
            gp_settings.axes[i]['MIN'] = gp_eval.gp_eval(test.group(1),gp_settings.variables,gp_settings.functions)
            gp_settings.axes[i]['MAX'] = gp_eval.gp_eval(test.group(5),gp_settings.variables,gp_settings.functions)
          except: pass
        return

    if (done == 0): os.system("cat %s/txt/set.txt"%PATH) # Set what??

# Main Directive Processor

def directive(line):
  global exitting

  # Can use ; to pass multiple commmands on one line
  linelist = gp_eval.gp_split(line,';')
  if (len(linelist) > 1):
    for i in range(len(linelist)):
      directive(linelist[i])
    return

  linelist = line.split()
  if (len(linelist) < 1): return

  if   (   re.match(r'^([A-Za-z]\w*\([A-Za-z, ]\w*\))\s*=\s*(.*)',line) != None): # f(x) = ...
    test = re.match(r'^([A-Za-z]\w*\([A-Za-z, ]\w*\))\s*=\s*(.*)',line)
    gp_settings.functions[test.group(1).strip()] = test.group(2).strip()
  elif (   re.match(r'^([A-Za-z]\w*)\s*=(.*)',line) != None): # x = ...
    test = re.match(r'^([A-Za-z]\w*)\s*=(.*)',line)
    try:
      gp_settings.variables[test.group(1).strip()] = gp_eval.gp_eval(test.group(2),gp_settings.variables,gp_settings.functions)
    except: pass

  elif ((re.match(r'^ex',linelist[0]) != None) or  # exit / quit
        (re.match(r'^q', linelist[0]) != None)    ):
           exitting=1; return
  elif ((re.match(r'^h',linelist[0]) != None) or   # help / ?
        (re.match(r'^\?',linelist[0]) != None)    ):
           os.system("fortune")
  elif (re.match(r'^se',linelist[0]) != None):     # set
    directive_set(line,linelist)
  elif (re.match(r'^sh',linelist[0]) != None):     # show
    directive_show(line,linelist)
  elif (re.match(r'^fit',linelist[0]) != None):    # fit
    gp_fit.directive_fit(line,linelist,gp_settings.variables,gp_settings.functions)
  elif (re.match(r'^p[^r]',linelist[0]) != None):  # plot
    gp_plot.directive_plot(line,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,gp_settings.axes,gp_settings.labels,gp_settings.arrows,0)
  elif (re.match(r'^rep',linelist[0]) != None):    # replot
    gp_plot.directive_plot(line,gp_settings.linestyles,gp_settings.variables,gp_settings.functions,gp_settings.settings,gp_settings.axes,gp_settings.labels,gp_settings.arrows,1)

  elif (re.match(r'^pr',linelist[0]) != None):     # print
    test = re.match(r'\s*pri?n?t?\s*(.*)',line)
    if (test != None):
      args = gp_eval.gp_split(test.group(1),",")   # print , separated list
      for arg in args:
        test = re.match(r"""^\s*'(.*)'\s*$""",arg)
        if (test != None): sys.stdout.write(test.group(1)); continue
        test = re.match(r"""^\s*"(.*)"\s*$""",arg)
        if (test != None): sys.stdout.write(test.group(1)); continue
        try:
          sys.stdout.write( floatprint( gp_eval.gp_eval(arg,gp_settings.variables,gp_settings.functions) ) )
        except: pass
        sys.stdout.write(" ")
    print

  else:
    os.system("cat %s/txt/invalid.txt"%PATH)       # invalid cmd

def Interactive():   # Interactive GnuPlot terminal
  global exitting
  exitting=0
  print 
  print "        G N U P L O T +"
  print "        Version %s"%VERSION
  print "        %s"%DATE
  print 
  print "        Copyright (C) 2006"
  print "        Dominic Ford"
  print
  os.system("cat %s/txt/init.txt"%PATH)
  try:
    while (exitting==0):
      directive(raw_input("gnuplot+>"))
  except (KeyboardInterrupt,EOFError): pass
  print "\nGoodbye. Have a nice day."

# MAIN ENTRY POINT

if (len(sys.argv) > 1): # Input files specified on commandline
  for i in range(1,len(sys.argv),1):
    exitting=0
    if (sys.argv[i] == '-'): # A minus on commandline means interactive
      Interactive()
    else:
      try:
        infile = open(sys.argv[i],'r')
      except:
        print "Gnuplot Error: Could not read input file %s"%sys.argv[i]
        print "Skipping on to next input file"
      else:
        for line in infile.readlines():
          directive(line)
          if (exitting==1): break
else: # Otherwise enter interactive mode
  Interactive()
