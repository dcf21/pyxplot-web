# GP_PLOT.PY
# Dominic Ford
# 26/02/2006

# Implementation of plot command

import gp_eval
import gp_datafile

import os
import sys
import re
from pyx import *

# Stores the number of lines on our graph. PyX gets unhappy when this is zero.
no_plottings = [0,0,0,0] # Used to count how many plots are put on x1,x2,y1,y2 axes. Unused axes need not be drawn.
plot_counter = 0 # Used for X11 terminal, to give each plot output an individual name

# Store list of previously plotted items. Used to replot.
plotlist = []

# Passes line/point styles between plotting functions and "with" parser

stylestr  = ""
pointsize = 0
pointtype = 0
linewidth = 0
linestyle = 0
linecount = 0 # Counts how many lines have been plotted; used to cycle line styles.
ptcount   = 0 # As above; used to cycle point styles
colourcnt = 0 # As above; used to cycle colours
withstate = 0 # State parameter used when processing input after the word "with"

# REMATCH(): Safe substitute for re.match

def rematch(str1, str2):
  try:
    return re.match(str1, str2)
  except:
    return None

# DIRECTIVE_PLOT(): Handles the 'plot' command

def directive_plot(line,linestyles,vars,funcs,settings,axes,labels,arrows,replot_stat):
  global no_plottings
  global plot_counter
  global plotlist
  global linecount, ptcount, colourcnt

  # Counts number of lines/pointsets plotted, so that we can cycle styles
  colourcnt = 0
  linecount = 0
  ptcount   = 0

  if (replot_stat == 0): plotlist = [] # If not replotting, wipe plot list

  test = re.match(r"^\s*r?e?p\w*\s*(.*)$",line) # Strip initial "plot" command
  if (test == None):
    print "Syntax Error -- This Should Not Happen!"; return # Error - This Should Not Happen!
  line = test.group(1)

  # Prepare PyX

  text.reset() # It can be unhappy if it threw an exception last time it was used
  text.set(mode="latex")
  text.texrunner.waitfortex=20 # seconds

  # Now read range specifications
  axes_this = [] # Make a local copy of the list 'axes'
  for item in axes: axes_this.append(item.copy())
  state     = 0

  while ((len(line) > 0) and (line[0] == '[')):
    test = re.match("""^\s*\[([^:\]]*)((:)|( *to *))([^:\]]*)\]\s*(.*)$""",line)
    if (test == None):
      print "Could not read range. Use format: [0:1]."
      return # Error
    else:
      try: 
        if (state == 0): # set x-axis range
          axes_this[0]['MIN']       = gp_eval.gp_eval(test.group(1),vars,funcs)
          axes_this[0]['MAX']       = gp_eval.gp_eval(test.group(5),vars,funcs)
          axes_this[0]['AUTOSCALE'] = "OFF"
          state = 1 ; line = test.group(6) ; continue
        elif (state == 1): # set y-axis range
          axes_this[2]['MIN']       = gp_eval.gp_eval(test.group(1),vars,funcs)
          axes_this[2]['MAX']       = gp_eval.gp_eval(test.group(5),vars,funcs)
          axes_this[2]['AUTOSCALE'] = "OFF"
          state = 2 ; line = test.group(6) ; continue 
        else: 
          print "Too many ranges. Specify a maximum of two ranges, one for x, second for y."
          raise ValueError # User has specified too many ranges
      except:
        return # Error

  # If axes are to autoscale, set them up to do so
  for i in range(4):
    if (axes_this[i]['AUTOSCALE'] == "ON"): # If axes are to autoscale, set them up to do so
      axes_this[i]['MIN'] = None
      axes_this[i]['MAX'] = None

  # Set up key

  if (settings['KEY'] == "ON"):
    if   (settings['KEYPOS'] == "TOP RIGHT"):    pos = "tr"
    elif (settings['KEYPOS'] == "TOP LEFT"):     pos = "tl"
    elif (settings['KEYPOS'] == "BOTTOM RIGHT"): pos = "br"
    elif (settings['KEYPOS'] == "BOTTOM LEFT"):  pos = "bl"
    else:
      print "Internal Error: Cannot work out where key is.... defaulting to top-right"
      pos = "tr"
    key = graph.key.key(pos=pos)
  else:
    key = None

  # Split line into comma-separated things to plot
  for item in gp_eval.gp_split(line,","): plotlist.append(item)
  g = None
  axisobjs = [None,None,None,None,None,None]

  # TWO-PASS PLOTTING
  # Pass 1: Establish ranges of data for axes. Then assign axes
  # Pass 2: PLot data for real

  for plotting in [0==1,0==0]: # plotting is false on first pass, true on second pass

      no_plottings = [0,0,0,0] 

      # Plot datafiles first, to get an idea of the range of the x-axis
      for plotitem in plotlist:
        plotwords = plotitem.strip().split()
        if ((len(plotwords) > 0) and (plotwords[0][0] == "'")):
          plot_datafile(g,axes_this,settings,linestyles,plotwords,vars,funcs,plotting)

      # If we have no datafiles or autoscale to give us a range, we need to make one up...
      for i in [0,1]:
        if (axes_this[i]['MIN'] == None): axes_this[i]['MIN'] = -10.0
        if (axes_this[i]['MAX'] == None): axes_this[i]['MAX'] =  10.0
    
      # Plot functions second, sampling them over the range that we have now determined
      for plotitem in plotlist:
        plotwords = plotitem.strip().split()
        if ((len(plotwords) > 0) and (plotwords[0][0] != "'")):
          plot_function(g,axes_this,settings,linestyles,plotwords,vars,funcs,plotting)

      # First time only: now we're ready to set up plot
      if (not plotting):
          try:
            # Set up axes
            axisassign= ""
            if (settings['GRID'] == 'ON'): gridalloc = ",painter=graph.axis.painter.regular(gridattrs=[attr.changelist([color.gray(0.1),color.gray(0.4)])])"
            else:                          gridalloc = ""
            for [i,name] in [[0,"x"],[1,"x2"],[2,"y"],[3,"y2"]]:
              if (axes_this[i]['LOG'] != "ON"): axistype = "graph.axis.linear"
              else                            : axistype = "graph.axis.log"
              if ( ((i == 0)) or # Conditions under which we display axes: always display x and y
                   ((i == 2)) or # Display x2/y2 if they have labels, or if data has been plotted on them. Note that this differs from GnuPlot.
                   ((i == 1) and ((len(axes_this[1]['LABEL']) > 0) or (no_plottings[1] > 0))) or
                   ((i == 3) and ((len(axes_this[3]['LABEL']) > 0) or (no_plottings[3] > 0)))
                 ):
                     exec "axisobjs[i] ="+axistype+'(title="""'+axes_this[i]['LABEL']+'""", min='+str(axes_this[i]['MIN'])+', max='+str(axes_this[i]['MAX'])+gridalloc+')'
                     axisassign = axisassign+name+"= axisobjs["+str(i)+"],"

            # Set up plot
            exec "g = graph.graphxy(width=settings['WIDTH'],"+axisassign+"key=key)"
          except:
            print "PyX could not make axis objects. Logs of negative/zero numbers happening, perhaps? Specify a more sensible range."
            print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
            return

  # Make sure we have something to plot!
  if (no_plottings == [0,0,0,0]):
    print "Need to specify something to plot!"
    return # Error

  # Print title of plot, if we have one
  if (len(settings['TITLE']) > 0):
    g.text(g.width/2, g.height + 0.2, settings['TITLE'], [text.halign.center, text.valign.bottom])

  # Print text labels
  try:
    for dummy,(txt,systx,x,systy,y) in labels.iteritems():
      if (systx == "first") : x,dummy = g.pos(x=x,y=1,xaxis=axisobjs[0],yaxis=axisobjs[2])
      if (systx == "second"): x,dummy = g.pos(x=x,y=1,xaxis=axisobjs[1],yaxis=axisobjs[2])
      if (systy == "first") : dummy,y = g.pos(x=1,y=y,xaxis=axisobjs[0],yaxis=axisobjs[2])
      if (systy == "second"): dummy,y = g.pos(x=1,y=y,xaxis=axisobjs[0],yaxis=axisobjs[3])
      g.text(x, y, txt)
  except:
    print "Error printing labels:"
    print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"

  # Print arrows
  try:
    for dummy,(systx0,x0,systy0,y0,systx1,x1,systy1,y1,arrow_style) in arrows.iteritems():
     if (systx0 == "first") : x0,dummy = g.pos(x=x0,y=1,xaxis=axisobjs[0],yaxis=axisobjs[2])
     if (systx0 == "second"): x0,dummy = g.pos(x=x0,y=1,xaxis=axisobjs[1],yaxis=axisobjs[2])
     if (systy0 == "first") : dummy,y0 = g.pos(x=1,y=y0,xaxis=axisobjs[0],yaxis=axisobjs[2])
     if (systy0 == "second"): dummy,y0 = g.pos(x=1,y=y0,xaxis=axisobjs[0],yaxis=axisobjs[3])
     if (systx1 == "first") : x1,dummy = g.pos(x=x1,y=1,xaxis=axisobjs[0],yaxis=axisobjs[2])
     if (systx1 == "second"): x1,dummy = g.pos(x=x1,y=1,xaxis=axisobjs[1],yaxis=axisobjs[2])
     if (systy1 == "first") : dummy,y1 = g.pos(x=1,y=y1,xaxis=axisobjs[0],yaxis=axisobjs[2])
     if (systy1 == "second"): dummy,y1 = g.pos(x=1,y=y1,xaxis=axisobjs[0],yaxis=axisobjs[3])
     if (arrow_style == 'head'): arrow_style_list = [deco.earrow.normal]
     if (arrow_style == 'nohead'): arrow_style_list = []
     if (arrow_style == 'twoway'): arrow_style_list = [deco.barrow.normal, deco.earrow.normal]
     g.stroke(path.line(x0,y0,x1,y1),arrow_style_list)
  except:
    print "Error printing arrows:"
    print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"

  # Output plot
  if (settings['TERMTYPE'] == "X11"):
    try:
      plot_counter = plot_counter + 1
      fname = "/tmp/gp+_" + str(os.getpid()) + "_" + str(plot_counter) + ".eps"
      g.writeEPSfile(fname)
    except:
      print "PyX failed while producing eps output:"
      print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
      return # Error
    os.system("gv "+fname+" &")
  else:
    try:
      g.writeEPSfile(settings['OUTPUT'])
    except:
      print "PyX failed while producing eps output:"
      print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
      return # Error

# PLOT_DATAFILE(): Plot datapoints listed in datafile
def plot_datafile(g,axes,settings,linestyles,plotwords,vars,funcs,plotting):
  global stylestr, pointsize, pointtype, linewidth, linestyle

  datafile = ''
  axis_x   = 0
  axis_y   = 0
  using    = ''
  every    = 1
  index    = -1 # GnuPlot API doesn't have an index value for "plot all indices", so I define it to be -1.
  title    = ''
  quotetype= ''
  state    = 0
  stylestr = settings['DATASTYLE']
  pointsize= settings['POINTSIZE']
  pointtype  = -1
  linestyle  = -1
  linewidth  = 1.0
  withstate  = 0

  for i in range(len(plotwords)):
    item = plotwords[i].strip()

    if (state < 2):
     if (rematch(item, "using")   != None): state = 2 ; continue
     if (rematch(item, "every")   != None): state = 3 ; continue
     if (rematch(item, "index")   != None): state = 4 ; continue
     if (rematch(item, "notitle") != None): title = ''; continue
     if (rematch(item, "title")   != None): state = 5 ; continue # also uses state 6
     if (rematch(item, "with")    != None): state = 7 ; continue
     if (rematch(item, "axes")    != None): state = 8 ; continue

    if (state == 4): # set 'index' setting
      try:
        index = int(item)
      except: 
        print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
        print "'index' keyword should be followed by an integer"
        return # Error
      state = 1
      continue

    if (state == 3): # set 'every' setting
      try:
        every = int(item)
      except: 
        print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
        print "'every' keyword should be followed by an integer"
        return # Error
      state = 1
      continue

    if (state == 2): # read 'using' string
      using = item
      state = 1
      continue

    if (state == 5): # read 'title' string
      test = re.match(r"""^('|")(.*)$""",item)
      if (test == None):
        print "Error: title must be in quotes"
      item = test.group(2)
      title = ""
      quote_type = test.group(1)
      state = 6
    if (state == 6): # Multiple word titles supported
      test = re.match("""^(.*)%s$"""%quote_type,item)
      if (test == None):
        title = title + item + " "
      else:
        title = title + test.group(1)
        state=1 # We have hit a closing quote
      continue

    if (state == 7): # read 'with' clauses
      process_with_word(settings, linestyles, item)
      continue

    if (state == 8): # read axes string
      try:
        test = re.match(r"""^x(1|2)y(1|2)$""",item)
        axis_x = int(test.group(1))-1
        axis_y = int(test.group(2))-1
      except:
        print "Error: axes declaration must take the form x{1|2}y{1|2}."
      continue

    if ((state == 0) and (item[0] == "'")):
      test = re.match(r"""^'(.*)'$""",item)
      if (test == None):
        print """Badly formed datafile name "%s"."""%item
        return # Error
      datafile = test.group(1)
      title    = test.group(1)
      state = 1
      continue

    print "Syntax Error: Unrecognised word '%s'"%item
    return # Error

    # We have now read our filename, and operators on the filename

  if (using == ''):
    using = '1:2'
    if ((stylestr == 'xerrorbars') or (stylestr == 'yerrorbars')): using = '1:2:3'
    if  (stylestr == 'xyerrorbars')                              : using = '1:2:3:4'
  columns_req = 2
  if ((stylestr == 'xerrorbars') or (stylestr == 'yerrorbars')): columns_req = 3
  if  (stylestr == 'xyerrorbars')                              : columns_req = 4

  try:
    (rows,columns,datagrid) = gp_datafile.gp_dataread(datafile, index, using, every, vars, funcs)
  except:
    print "Error reading input datafile %s"%datafile
    print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
    return # Error

  if (rows == 0):
    print "Warning: No datapoints found in file '%s'."%datafile
    return

  if (columns < columns_req):
    print "Need at least %d columns to plot data from file '%s'."%(columns_req,datafile)
    return

  # Recalculate data bounding box
  if (not plotting):
    for i in range(rows):
      if (axes[0+axis_x]['AUTOSCALE'] == 'ON'):
        if ((axes[0+axis_x]['MIN'] == None) or (axes[0+axis_x]['MIN'] > datagrid[i][0])): axes[0+axis_x]['MIN'] = datagrid[i][0]
        if ((axes[0+axis_x]['MAX'] == None) or (axes[0+axis_x]['MAX'] < datagrid[i][0])): axes[0+axis_x]['MAX'] = datagrid[i][0]
      if (axes[2+axis_y]['AUTOSCALE'] == 'ON'):
        if ((axes[2+axis_y]['MIN'] == None) or (axes[2+axis_y]['MIN'] > datagrid[i][1])): axes[2+axis_y]['MIN'] = datagrid[i][1]
        if ((axes[2+axis_y]['MAX'] == None) or (axes[2+axis_y]['MAX'] < datagrid[i][1])): axes[2+axis_y]['MAX'] = datagrid[i][1]

  # Plot dataset
  no_plottings[0+axis_x] = no_plottings[0+axis_x] + 1
  no_plottings[2+axis_y] = no_plottings[2+axis_y] + 1
  if (plotting): plot_dataset(g,axes,axis_x,axis_y,settings,title,datagrid,rows,columns,"datafile '%s'"%datafile)

# PLOT_FUNCTION(): Plot a function
def plot_function(g,axes,settings,linestyles,plotwords,vars,funcs,plotting):
  global stylestr, pointsize, pointtype, linewidth, linestyle

  function = ''
  axis_x   = 0
  axis_y   = 0
  xname    = ''
  title    = ''
  quotetype= ''
  state    = 0
  stylestr = settings['FUNCSTYLE']
  pointsize= settings['POINTSIZE']
  pointtype  = -1
  linestyle  = -1
  linewidth  = 1.0
  withstate  = 0

  for i in range(len(plotwords)):
    item = plotwords[i].strip()

    if (state < 2):
     if (rematch(item, "notitle") != None): title = ''; continue
     if (rematch(item, "title")   != None): state = 5 ; continue # also uses state 6
     if (rematch(item, "with")    != None): state = 7 ; continue
     if (rematch(item, "axes")    != None): state = 8 ; continue

    if (state == 5): # read 'title' string
      test = re.match(r"""^('|")(.*)$""",item)
      if (test == None):
        print "Error: title must be in quotes"
      item = test.group(2)
      title = ""
      quote_type = test.group(1)
      state = 6
    if (state == 6): # Multiple word titles supported
      test = re.match("""^(.*)%s$"""%quote_type,item)
      if (test == None):
        title = title + item + " "
      else:
        title = title + test.group(1)
        state=1 # We have hit a closing quote
      continue

    if (state == 7): # read 'with' clauses
      process_with_word(settings, linestyles, item)
      continue

    if (state == 8): # read axes string
      try:
        test = re.match(r"""^x(1|2)y(1|2)$""",item)
        axis_x = int(test.group(1))-1
        axis_y = int(test.group(2))-1
      except:
        print "Error: axes declaration must take the form x{1|2}y{1|2}."
      continue

    if (state == 0): # Receive function
      test = re.match("""^.*\(\s*([A-Za-z]\w*)\s*\).*$""",item)
      if (test == None):
        print "Badly formed function '%s'. Must be a function of only one variable"%item
        return # Error
      function = item
      title    = item
      xname    = test.group(1)
      state = 1
      continue

    print "Syntax Error: Unrecognised word '%s'"%item
    return # Error

  # We have now read our function expression, and operators on it

  if (axes[axis_x]['LOG'] == 'ON'): xrast = lograst(axes[axis_x]['MIN'], axes[axis_x]['MAX'], settings['SAMPLES'])
  else:                             xrast = linrast(axes[axis_x]['MIN'], axes[axis_x]['MAX'], settings['SAMPLES'])

  datagrid = []
  local_vars = vars.copy()
  for x in xrast:
    try:
      local_vars[xname] = x
      val = gp_eval.gp_eval(function,local_vars,funcs)
      datagrid.append([x,val])
      if (not plotting):
        if (axes[2+axis_y]['AUTOSCALE'] == 'ON'):
          if ((axes[2+axis_y]['MIN'] == None) or (axes[2+axis_y]['MIN'] > val)): axes[2+axis_y]['MIN'] = val
          if ((axes[2+axis_y]['MAX'] == None) or (axes[2+axis_y]['MAX'] < val)): axes[2+axis_y]['MAX'] = val
    except:
      print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
      return # Error

  # Plot dataset
  no_plottings[0+axis_x] = no_plottings[0+axis_x] + 1
  no_plottings[2+axis_y] = no_plottings[2+axis_y] + 1
  if (plotting): plot_dataset(g,axes,axis_x,axis_y,settings,title,datagrid,2,settings['SAMPLES'],"function '%s'"%function)

# PROCESS_WITH_WORD(): Process a word after the "with" directive

def process_with_word(settings, linestyles, word, iteration=0):
  global stylestr, pointsize, pointtype, linewidth, linestyle
  global withstate

  if (len(word) == 0): return

  if (withstate == 0):
   if ((word == 'linetype')              or  (word == 'lt')                          ): withstate = 1 ; return
   if ((word == 'linewidth')             or  (word == 'lw')                          ): withstate = 2 ; return
   if ((word == 'pointsize')             or  (word == 'ps')                          ): withstate = 3 ; return
   if ((word == 'pointtype')             or  (word == 'pt')                          ): withstate = 4 ; return
   if ((word == 'linestyle')             or  (word == 'ls')                          ): withstate = 5 ; return

   if ((word[0] == 'l')                  and (re.match(word, "lines")        != None)): stylestr = 'lines'      ; return
   if ((word[0] == 'p')                  and (re.match(word, "points")       != None)): stylestr = 'points'     ; return
   if ((word    == 'lp')                                                             ): stylestr = 'linespoints'; return
   if ((re.match("linesp",word) != None) and (re.match(word, "linespoints")  != None)): stylestr = 'linespoints'; return
   if ((re.match("xe"    ,word) != None) and (re.match(word, "xerrorbars")   != None)): stylestr = 'xerrorbars' ; return
   if ((re.match("ye"    ,word) != None) and (re.match(word, "yerrorbars")   != None)): stylestr = 'yerrorbars' ; return
   if ((re.match("xy"    ,word) != None) and (re.match(word, "xyerrorbars")  != None)): stylestr = 'xyerrorbars'; return

  if (withstate == 1):
   try:
    linestyle = int(word) ; withstate = 0
   except:
    print "Error: linetype should be followed by an integer."
   return

  if (withstate == 2):
   try:
    linewidth = float(word) ; withstate = 0
   except:
    print "Error: linewidth should be followed by a floating point value."
   return

  if (withstate == 3):
   try:
    pointsize = float(word) ; withstate = 0
   except:
    print "Error: pointsize should be followed by a floating point value."
   return

  if (withstate == 4):
   try:
    pointtype = int(word) ; withstate = 0
   except:
    print "Error: pointtype should be followed by an integer."
   return

  if (withstate == 5):
    try:
     number = int(word) ; withstate = 0
    except:
     print "Error: linestyle should be followed by the number of the desired linestyle."

    if (not linestyles.has_key(number)):
     print "Error: linestyle %d is not defined."%number
    else:
     if (iteration > 4):
      print "Iteration ceiling hit whilst processing linestyle %d."%number
     else:
      for word in linestyles[number].split():
        process_with_word(settings,linestyles,word,iteration+1)
    return

  print "Warning: Unrecognised word '%s' in with section"%word
  return

# PLOT_LINEWIDTH(): Turn a numerical linewidth into a PyX style

def plot_linewidth(width):
  output = style.linewidth.THIN
  if (width >= 0.2): output = style.linewidth.THIn
  if (width >= 0.4): output = style.linewidth.THin
  if (width >= 0.6): output = style.linewidth.Thin
  if (width >= 0.8): output = style.linewidth.thin
  if (width >= 1.0): output = style.linewidth.normal
  if (width >= 2.0): output = style.linewidth.thick
  if (width >= 3.0): output = style.linewidth.Thick
  if (width >= 4.0): output = style.linewidth.THick
  if (width >= 5.0): output = style.linewidth.THIck
  if (width >= 6.0): output = style.linewidth.THICk
  if (width >= 7.0): output = style.linewidth.THICK
  return output

# PLOT_DATASET(): Plot a datagrid

def plot_dataset(g,axes,axis_x,axis_y,settings,title,datagrid,rows,columns,description):
  global no_plottings
  global stylestr, pointsize, pointtype, linewidth, linestyle
  global linecount, ptcount, colourcnt

  symbol_list = [graph.style.symbol.cross, graph.style.symbol.plus, graph.style.symbol.square, graph.style.symbol.triangle, graph.style.symbol.circle, graph.style.symbol.diamond]
  linestyle_list = [style.linestyle.solid, style.linestyle.dashed, style.linestyle.dotted, style.linestyle.dashdotted]

  colour_list = [color.grey.black, color.rgb.red, color.rgb.blue, color.cmyk.Magenta, color.cmyk.Cyan, color.cmyk.Brown, color.cmyk.Salmon, color.cmyk.Gray, color.rgb.green, color.cmyk.NavyBlue, color.cmyk.Periwinkle, color.cmyk.PineGreen, color.cmyk.SeaGreen, color.cmyk.GreenYellow, color.cmyk.Orange, color.cmyk.CarnationPink, color.cmyk.Plum ]

  try:
    stylelist = []
    dx = None
    dy = None
    if (re.search('lines'    ,stylestr) != None):
      if (settings['COLOUR'] == 'ON'):
        colour    = colour_list[colourcnt%len(colour_list)]
        colourcnt = colourcnt + 1
        if (linestyle < 0): linestyle = 0
      else:
        colour = color.grey.black
        if (linestyle < 0):
          linestyle = linecount
          linecount = linecount + 1
      stylelist.append(graph.style.line(lineattrs=[ linestyle_list[linestyle%len(linestyle_list)], plot_linewidth(linewidth), colour ]))
    if (re.search('points'   ,stylestr) != None):
      if (settings['COLOUR'] == 'ON'):
        colour    = colour_list[colourcnt%len(colour_list)]
        colourcnt = colourcnt + 1
        if (pointtype < 0): pointtype = 0
      else:
        colour = color.grey.black
        if (pointtype < 0):
          pointtype = ptcount
          ptcount   = ptcount + 1
      stylelist.append(graph.style.symbol(size=0.1*pointsize, symbol=symbol_list[pointtype%len(symbol_list)], symbolattrs=[colour]))
    if (re.search('errorbars',stylestr) != None):
      if (settings['COLOUR'] == 'ON'):
        colour    = colour_list[colourcnt%len(colour_list)]
        colourcnt = colourcnt + 1
        if (linestyle < 0): linestyle = 0
      else:
        colour = color.grey.black
        if (linestyle < 0):
          linestyle = linecount
          linecount = linecount + 1
      stylelist.append(graph.style.errorbar(errorbarattrs=[linestyle_list[linestyle%len(linestyle_list)], plot_linewidth(linewidth), colour]))
      stylelist.append(graph.style.symbol(size=0.1*pointsize, symbol=graph.style.symbol.plus, symbolattrs=[colour]))
      if   ((re.match('xerrorbars' ,stylestr) != None) and (columns > 2)): dx = 3 ; dy = None
      elif ((re.match('yerrorbars' ,stylestr) != None) and (columns > 2)): dy = 3 ; dx = None
      elif ((re.match('xyerrorbars',stylestr) != None) and (columns > 3)): dx = 3 ; dy = 4

    axis_names={0:'',1:'2'}
    x_set = "x"+axis_names[axis_x]+"=1,"
    y_set = "y"+axis_names[axis_y]+"=2,"
    if (dx != None): dx_set = "dx"+axis_names[axis_x]+"=dx,"
    else           : dx_set = ""
    if (dy != None): dy_set = "dy"+axis_names[axis_y]+"=dy,"
    else           : dy_set = ""
    exec "g.plot(graph.data.list(datagrid,"+x_set+y_set+dx_set+dy_set+"title=title),styles=stylelist)"
  except:
    print "PyX failed while plotting %s:"%description
    print "Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")"
    return # Error
  return

# LINRAST()
# LOGRAST(): Linear and log rasters, used for evaluating functions

def linrast( xmin, xmax, steps):
    return [ xmin + i* float(xmax-xmin)/steps for i in range(steps+1) ]
    
def lograst ( xmin , xmax , nsteps):
    return [ xmin * (xmax / xmin ) ** ( float(i)/nsteps ) for i in range(nsteps+1) ]

