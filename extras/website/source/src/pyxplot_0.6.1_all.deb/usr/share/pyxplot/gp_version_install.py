VERSION='0.6.1'
DATE='27/12/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
