# GP_CHILDREN.PY
# Dominic Ford
# 27/12/2006

# Signal handler for calling wait() to eliminate zombies.
# Doesn't use SIGCHLD as this would break os.popen....
# http://twistedmatrix.com/trac/ticket/733
# http://mail.python.org/pipermail/python-dev/2004-November/049987.html

import signal
import os

import gp_settings
import gp_error

ghostviews      = []
ghostview_pid   = None # pid of any running gv process launched under X11_singlewindow
ghostview_fname = None

def sigchld_handle():
 global ghostviews, ghostview_pid
 for ghostview in ghostviews:
  output = os.waitpid(ghostview, os.WNOHANG)
  if (output != (0,0)):
   ghostviews.remove(ghostview)
   if (ghostview == ghostview_pid): ghostview_pid = None

def massacre_children():
 global ghostviews, ghostview_pid
 for ghostview in ghostviews:
  os.kill(ghostview, signal.SIGTERM)
 sigchld_handle()

def kill_latest():
 global ghostview_pid
 if (ghostview_pid != None):
  os.kill(ghostview_pid, signal.SIGTERM) # Kill previous gv session
 sigchld_handle()

def stat_gv_output():
 latest_stat = os.stat("%s/gv_errors"%gp_settings.tempdir)[8:9] # [st_mtime, st_ctime]
 if (latest_stat == gp_settings.gv_errorfile_stat): return
 i=0
 for line in open("%s/gv_errors"%gp_settings.tempdir,"r"):
  if (i>=gp_settings.gv_errorfile_pos) and (len(line.strip())>0): gp_error.gp_error(line.strip())
  i+=1
 gp_settings.gv_errorfile_pos  = i
 gp_settings.gv_errorfile_stat = latest_stat
