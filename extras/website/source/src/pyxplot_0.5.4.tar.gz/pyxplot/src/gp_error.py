# GP_ERROR.PY
# Dominic Ford
# 03/07/2006

# Error handler

import sys

# A fairly minimal error handler, which sends error messages to stderr
# and report messages to stdout

def gp_error(*text):
  for item in text: sys.stderr.write(str(item)+" ")
  sys.stderr.write("\n")

def gp_warning(*text):
  for item in text: sys.stderr.write(str(item)+" ")
  sys.stderr.write("\n")

def gp_report(*text):
  for item in text: sys.stdout.write(str(item)+" ")
  sys.stdout.write("\n")
