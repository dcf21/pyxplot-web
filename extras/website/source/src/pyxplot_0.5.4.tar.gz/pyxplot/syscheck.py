# SYSCHECK.PY
# Dominic Ford
# 03/07/2006

# Checks that system satisfies all dependencies required for pyxplot

status = 0

try:
 import sys
 import os
 import re
 test = re.match(r"(\d*)\.(\d*)",sys.version)
 if not ((int(test.group(1)) > 2) or ((int(test.group(1)) == 2) and (int(test.group(2)) >= 4))): raise ValueError
except:
 print "Installation failure: Default python version is < version 2.4; please install a newer version."
 status = 1

try:
 import scipy
except:
 print "Installation failure: Python scientific library 'scipy' not found. Please install and try again."
 status = 1

try:
 test = os.popen("which bash","r").read()
 if (len(test) < 1): raise ValueError
except:
 print "Installation failure: Required package 'bash' (i.e. the bash shell) could not be found. Please install and try again."
 status = 1

try:
 test = os.popen("which gs","r").read()
 if (len(test) < 1): raise ValueError
except:
 print "Installation failure: Required package 'ghostscript' could not be found. Please install and try again."
 status = 1

try:
 test = os.popen("which latex","r").read()
 if (len(test) < 1): raise ValueError
except:
 print "Installation failure: Required package 'latex' could not be found. Please install and try again."
 status = 1

try:
 test = os.popen("which convert","r").read()
 if (len(test) < 1): raise ValueError
except:
 print "Installation failure: Required package 'convert' (i.e. ImageMagick) could not be found. Please install and try again."
 status = 1

if (status == 0):
 sys.exit(0)
else:
 sys.exit(1)
