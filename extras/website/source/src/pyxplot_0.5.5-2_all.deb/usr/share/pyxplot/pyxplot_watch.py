# PYXPLOT_WATCH.PY
# Dominic Ford
# 25/07/2006

import gp_version
import gp_text
from gp_error import *

import os
import sys
import time
import glob

VERSION = gp_version.VERSION
DATE    = gp_version.DATE

version_string = r"""PyXPlot Watch """+VERSION

help_string = r"""Usage: pyxplot_watch <options> <filelist>
  -h, --help:    Display this help
  -v, --version: Display version number
PyXPlot Watch """+VERSION

watch_files = [] # List of files that we are watching

def do_pyxplot(filename):
  gp_report("[%s] Running %s."%(time.ctime(),filename))
  os.system("pyxplot %s"%filename)
  gp_report("[%s] Completed %s."%(time.ctime(),filename))

# Main Entry Point

try:

# Read filenames from commandline

  for i in range(1,len(sys.argv)):
    if   (sys.argv[i] in ['-h','--help']): gp_report(help_string)
    elif (sys.argv[i] in ['-v','--version']): gp_report(version_string)
    else:
      filelist = glob.glob(os.path.expanduser(sys.argv[i]))
      if (len(filelist) == 0):
        gp_error("ERROR: Cannot find file '%s'."%sys.argv[i])
        sys.exit(1)
      watch_files.extend(filelist)

  if (len(watch_files) == 0):
    if (len(sys.argv) < 2):
      gp_error("ERROR: No files to watch! Please supply a list of PyXPlot scripts on the commandline.")
      sys.exit(1)
    sys.exit(0)

  gp_report(gp_text.init)
  gp_report("This is PyXPlot watcher. Press CTRL-C to exit.\nNow watching the following files:")
  for filename in watch_files: gp_report(filename)
  gp_report("\n--- Activity Log ---")


# PyXPlot each supplied filename straight away

  filelist_stat_vals = []
  for filename in watch_files:
    stat_val = os.stat(filename)[8:9] # [st_mtime, st_ctime]
    filelist_stat_vals.append(stat_val)
    do_pyxplot(filename)

# Then stat files every two seconds to watch for modification

  while(True):
    time.sleep(2)
    for i in range(len(watch_files)):
      filename = watch_files[i]
      stat_val = os.stat(filename)[8:9] # [st_mtime, st_ctime]
      if (stat_val != filelist_stat_vals[i]):
        do_pyxplot(filename)
        filelist_stat_vals[i] = stat_val

except KeyboardInterrupt:
  gp_report("Received keyboard interrupt.")
  gp_report("Quitting.")
