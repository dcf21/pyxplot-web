# GP_SPLINE.PY
# Dominic Ford
# 25/07/2006

import gp_eval
import gp_datafile
import gp_plot
from gp_autocomplete import *
from gp_error import *

import sys
import re
import operator
import scipy.interpolate
from math import *

# DIRECTIVE_SPLINE(): Implements the "spline" directive

def directive_spline(line, vars, funcs):

  # FIRST OF ALL, WE NEED TO READ THE INPUT PARAMETERS FROM THE COMMANDLINE

  pass_ranges = []

  # Ranges comes first...
  errorstring = "Syntax Error: syntax of spline command is:\nspline <[min:max][]...> function() 'datafile' <using a:b...> <every c:d:e:f:g> <index h>"
  test = re.match("\s*[A-Za-z]*\s*(.*)",line)
  if (test == None): gp_error(errorstring) ; return
  line = test.group(1)
  while ((len(line) > 0) and (line[1] == "[")):
    test = re.match("""\[([^:\]]*)((:)|( *to *))([^:\]]*)\]\s*(.*)$""",line)
    if (test == None): gp_error("Could not read range in the spline command. Use format: [min:max].") ; return # Error
    try:
      pass_ranges.append([ gp_eval.gp_eval(test.group(1),vars,funcs),
                           gp_eval.gp_eval(test.group(5),vars,funcs) ] )
    except KeyboardInterrupt: raise
    except: return
    line = test.group(6)

  # Then function name
  test = re.match("([A-Za-z]\w*)\s*\(\s*\)\s*(.*)$",line)
  if (test == None): gp_error(errorstring) ; return
  funcname = test.group(1)
  line = test.group(2)

  datafile = ''
  usingrowcol = "col"
  using    = ''
  every    = ''
  index    = -1 # GnuPlot API doesn't have an index value for "plot all indices", so I define it to be -1.
  xmin     = 0 ; xmax = 0 ; xrange = 0 # Reset range variables
  ymin     = 0 ; ymax = 0 ; yrange = 0
  smoothing= 0.0
  state    = 0 # 0 = datafile not yet read ; 1 = after datafile read, last word was not keyword ; 2 = using read ; 3 = every read ; 4 = via read

  linelist = line.split()
  for i in range(len(linelist)):
    item = linelist[i].strip()

    if (state < 2):
      if autocomplete(item, "using", 1): state = 2 ; continue
      if autocomplete(item, "every", 1): state = 3 ; continue
      if autocomplete(item, "index", 1): state = 4 ; continue
      if autocomplete(item, "smooth",1): state =10 ; continue

    if (state == 2): # read 'using' string
      if   autocomplete(item, "columns",3): usingrowcol="col"
      elif autocomplete(item, "rows"   ,3): usingrowcol="row"
      else:
        using = item
        state = 1
      continue

    if (state == 3): # set 'every' setting
      every = item
      state = 1
      continue

    if (state == 4): # set 'index' setting
      try:
        index = int(item)
      except KeyboardInterrupt: raise
      except:
        gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
        gp_error("'index' keyword should be followed by an integer.")
        return # Error
      state = 1
      continue

    if (state == 10): # set 'smooth' value
      try:
       smoothing = float(item)
      except KeyboardInterrupt: raise
      except:
       gp_error("Error:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
       gp_error("'smooth' keyword should be followed by a floating-point value.")
       return # Error
      state = 1
      continue

    if ((state == 0) and (item[0] == "'")):
      test = re.match(r"""^'(.*)'$""",item)
      if (test == None):
        gp_error("""Badly formed datafile name "%s"."""%item)
        return # Error
      datafile = test.group(1)
      state = 1
      continue

    gp_error("Syntax Error: Unrecognised word '%s'"%item)
    return # Error


  if (len(using) == 0): using = "1:2" # Make up default using string

  # We have now read all of our commandline parameters, and are ready to start spline fitting
  gp_plot.parse_enderrors(state,0)

  try:
   (rows,columns,datagrid) = gp_datafile.gp_dataread(datafile, index, usingrowcol, using, every, vars, funcs, "points")[0]
  except KeyboardInterrupt: raise
  except:
   gp_error("Error reading input datafile:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
   return # Error

  try:
   splineobj = make_spline_object(rows, columns, datagrid, smoothing, pass_ranges)[2]
   funcs[funcname] = [-1, [[line, splineobj]]]
  except KeyboardInterrupt: raise
  except:
   gp_error("Error processing input datafile:" , sys.exc_info()[1], "(" , sys.exc_info()[0] , ")")
  return # Done

# MAKE_SPLINE_OBJECT(): Makes a scipy spline object

def make_spline_object(rows,columns,datagrid,smoothing=0.0,ranges=[]):
 if   (columns == 2): yerrors = 0
 elif (columns == 3): yerrors = 1
 else               : raise ValueError, "spline command needs two or three columns of input data; %d supplied."%columns

 # Sort data points into list
 datagrid.sort(key=operator.itemgetter(0))
 xmin = datagrid[ 0][0]
 xmax = datagrid[-1][0]

 # If we have no errors supplied, work out standard deviation of data, to make smoothing behave sensibly
 if (yerrors != 1):
  sum_n = 0.0 ; sum_y = 0.0 ; sum_y2 = 0.0
  for datapoint in datagrid:
   sum_n  += 1.0
   sum_y  += datapoint[1]
   sum_y2 += datapoint[1] ** 2
  standev = sqrt(sum_y2/sum_n - (sum_y/sum_n)**2)
 else:
  standev = 0.0

 x_list = [] ; y_list = [] ; w_list = []
 datagrid_cpy = [x_list, y_list, w_list]
 xprev = None
 for datapoint in datagrid:
  if (datapoint[0] == xprev): continue # Filter out repeat datapoint
  if ((0 < len(ranges)) and ((ranges[0][0] > datapoint[0]) or (ranges[0][1] < datapoint[0]))): continue
  if ((1 < len(ranges)) and ((ranges[1][0] > datapoint[1]) or (ranges[1][1] < datapoint[1]))): continue
  datagrid_cpy[0].append(datapoint[0])
  datagrid_cpy[1].append(datapoint[1])
  if (yerrors == 1): weight = datapoint[2] # Units of standard deviation ; actually 1/weight
  else             : weight = standev/10
  weight = max(weight,1e-200) # Minimum inverse weight is 1e-200, since we're about to find one over it for weight
  datagrid_cpy[2].append(1.0/weight)
  xprev = datapoint[0]
 return [xmin, xmax, scipy.interpolate.splrep(x=x_list, y=y_list, w=w_list, s=(float(smoothing)*(len(datagrid_cpy[0])-sqrt(2.0*len(datagrid_cpy[0])))), nest=(len(datagrid_cpy[0])+5) )]

# SPLINE_EVALUATE(): Evaluate a spline at point x (This is just a wrapper for scipy)

def spline_evaluate(x, splineobj):
  return scipy.interpolate.splev(x, splineobj, der=0)
