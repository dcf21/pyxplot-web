VERSION='0.5.5'
DATE='25/07/2006'
SRCDIR='/usr/share/pyxplot'
GHOSTVIEW='/usr/bin/gv'
